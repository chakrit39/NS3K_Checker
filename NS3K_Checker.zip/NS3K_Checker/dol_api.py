# -*- coding: utf-8 -*-
"""
DOL iLands API สำหรับ NS3K Checker (ยกจาก Multi-Layer Edit Pro 2.4.1 — ชาคฤตย์ จันทรสุกศรี กองเทคโนโลยีทำแผนที่ กรมที่ดิน)
ค้นหา PARCEL_SEQ จาก "เลขระวาง" (attribute) ผ่าน 2 ขั้น (สาธารณะ ไม่ต้อง login):
  ① ArcGIS : attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ
  ② UDM    : GetMapInformation(centroid) -> strRegParcelSeq (=PARCEL_SEQ) + ข้อมูลแปลง
หลักฐานการรังวัด = servlet EVD (ต้อง login)
ต่างจาก MLEP: ทุกฟังก์ชันรับ zone (47/48) จากชั้นข้อมูล — MLEP ใช้ 47 ตายตัว (ปทุมธานี/นครนายก)
              รหัสจังหวัดของ servlet หลักฐานรังวัดครบทุกจังหวัด (PROVINCE_CODE — อ่านจากระบบกรมจริงแล้ว)
"""

import re
import ssl
import html
import json
import requests
from requests.adapters import HTTPAdapter

# ตรวจใบรับรอง TLS ทุกคำขอ (ห้ามถอยไป verify=False — รหัสผ่าน CAS วิ่งผ่าน session เดียวกัน)
# เชื่อใบรับรองชุดเดียวกับเบราว์เซอร์: ที่เก็บใบรับรองของ Windows (รวมโปรแกรมป้องกันไวรัสที่ตรวจ HTTPS) + certifi
SSL_MSG = ("ตรวจใบรับรองความปลอดภัยของระบบกรมไม่ผ่าน — เครือข่ายหรือโปรแกรมป้องกันไวรัสอาจดักการเชื่อมต่อ "
           "(ยังไม่ได้ส่งข้อมูลใด ๆ) · แจ้งผู้ดูแล")
_LOG_HINT = "รายละเอียดอยู่ในแผง Log Messages แท็บ NS3K Checker"
_SETTINGS = "NS3KChecker/"
_UA = "QGIS-NS3KChecker"


class _TrustAdapter(HTTPAdapter):
    """ส่ง SSLContext ที่โหลดใบรับรองของระบบ + certifi ให้ urllib3 (ทั้งต่อตรงและผ่าน proxy)"""

    def __init__(self, ctx, **kw):
        self._ctx = ctx
        super().__init__(**kw)

    def init_poolmanager(self, *a, **kw):
        kw["ssl_context"] = self._ctx
        return super().init_poolmanager(*a, **kw)

    def proxy_manager_for(self, proxy, **kw):
        kw["ssl_context"] = self._ctx
        return super().proxy_manager_for(proxy, **kw)


def _trust_context():
    ctx = ssl.create_default_context()          # ตรวจชื่อโฮสต์ + CERT_REQUIRED · Windows = โหลดที่เก็บ ROOT/CA ของระบบ
    try:
        import certifi
        ctx.load_verify_locations(certifi.where())
    except Exception:
        pass
    return ctx


def _new_session(user_agent):
    s = requests.Session()
    s.headers.update({"User-Agent": user_agent})
    try:
        s.mount("https://", _TrustAdapter(_trust_context()))
    except Exception:
        pass        # สร้าง context ไม่ได้ ⇒ ค่าตั้งต้นของ requests (certifi) — ยังตรวจใบรับรองอยู่
    return s


BASE = "https://ilands.dol.go.th"
ARCGIS_PARCEL_LAYER = {z: f"{BASE}/arcgis/rest/services/MapDOL_{z}/MapServer/6" for z in (47, 48)}   # MAP_LAND_GIS
# ชั้นอื่นของ ArcGIS สาธารณะ ช่องคีย์ชุดเดียวกับชั้น 6 — รอจด/ชั่วคราว = แปลงใหม่ที่ยังไม่ขึ้นชั้น 6 · ประวัติ = เลขที่ถูกยกเลิกแล้ว
ARCGIS_TEMP_LAYERS = {z: (f"{BASE}/arcgis/rest/services/MapSVA_{z}/MapServer/5",     # MAP_LAND_TEMP
                          f"{BASE}/arcgis/rest/services/MapTEMP_{z}/MapServer/0",    # MAP_LAND_RTK_TEMP
                          f"{BASE}/arcgis/rest/services/MapTEMP_{z}/MapServer/1",    # MAP_LAND_L1_TEMP
                          f"{BASE}/arcgis/rest/services/MapTEMP_{z}/MapServer/3")    # MAP_LAND_TEMP
                      for z in (47, 48)}
ARCGIS_HISTORY_LAYER = {z: f"{BASE}/arcgis/rest/services/MapSVA_{z}/MapServer/11" for z in (47, 48)}   # MAP_LAND_GIS_HISTORY
UDM_MAPINFO_URL = f"{BASE}/UDM_MAP/frmMain.aspx/GetMapInformation"
LOGIN_URL = f"{BASE}/dolauth/login"
EVD_CADASTRAL_URL = f"{BASE}/evd/servlet/EvdPcadastral001Servlet"
# หน้า "สอบถามข้อมูลแปลง" ของ iLands (ต้อง login) — ทางเดียวที่เจอแปลงที่มีทะเบียนแต่ไม่มีรูปบนแผนที่กรม · ช้า ⇒ ทางสุดท้าย
LIS_QDOCPARCEL_URL = f"{BASE}/LIS/Application/QDocParcel.aspx"

# ==================== รหัสจังหวัดของ servlet หลักฐานการรังวัด ====================
# รหัสภายในระบบ DOL (ไม่ใช่รหัสมาตรฐาน) — ★ 1.0.1 อ่านทั้งชุดจากช่องจังหวัดของหน้าทะเบียน iLands (QDocParcel · ต้อง login)
#   วัดจากระบบจริง 19 ต.ค. 69 ด้วยบัญชีของเจ้าของงาน: ค่าในช่องนั้น = รหัสของ servlet หลักฐานรังวัด
#   (ปทุมธานี 4 · ชลบุรี 11 · นครนายก 17 ที่ MLEP วัดไว้ตรงทุกตัว · ชัยนาท 9 และกาฬสินธุ์ 34 ค้นหลักฐานเจอจริง ส่วนรหัสอื่นได้ 0 รายการ)
#   = ลำดับตามรหัสจังหวัดมาตรฐาน โดยบึงกาฬ (ตั้ง 2554) ต่อท้าย · 1.0.0 เดากาฬสินธุ์เป็น 35 ก่อน (ผิด)
PROVINCE_CODE = {
    "กรุงเทพมหานคร": "1", "สมุทรปราการ": "2", "นนทบุรี": "3", "ปทุมธานี": "4", "พระนครศรีอยุธยา": "5",
    "อ่างทอง": "6", "ลพบุรี": "7", "สิงห์บุรี": "8", "ชัยนาท": "9", "สระบุรี": "10", "ชลบุรี": "11", "ระยอง": "12",
    "จันทบุรี": "13", "ตราด": "14", "ฉะเชิงเทรา": "15", "ปราจีนบุรี": "16", "นครนายก": "17", "สระแก้ว": "18",
    "นครราชสีมา": "19", "บุรีรัมย์": "20", "สุรินทร์": "21", "ศรีสะเกษ": "22", "อุบลราชธานี": "23", "ยโสธร": "24",
    "ชัยภูมิ": "25", "อำนาจเจริญ": "26", "หนองบัวลำภู": "27", "ขอนแก่น": "28", "อุดรธานี": "29", "เลย": "30",
    "หนองคาย": "31", "มหาสารคาม": "32", "ร้อยเอ็ด": "33", "กาฬสินธุ์": "34", "สกลนคร": "35", "นครพนม": "36",
    "มุกดาหาร": "37", "เชียงใหม่": "38", "ลำพูน": "39", "ลำปาง": "40", "อุตรดิตถ์": "41", "แพร่": "42", "น่าน": "43",
    "พะเยา": "44", "เชียงราย": "45", "แม่ฮ่องสอน": "46", "นครสวรรค์": "47", "อุทัยธานี": "48", "กำแพงเพชร": "49",
    "ตาก": "50", "สุโขทัย": "51", "พิษณุโลก": "52", "พิจิตร": "53", "เพชรบูรณ์": "54", "ราชบุรี": "55",
    "กาญจนบุรี": "56", "สุพรรณบุรี": "57", "นครปฐม": "58", "สมุทรสาคร": "59", "สมุทรสงคราม": "60", "เพชรบุรี": "61",
    "ประจวบคีรีขันธ์": "62", "นครศรีธรรมราช": "63", "กระบี่": "64", "พังงา": "65", "ภูเก็ต": "66",
    "สุราษฎร์ธานี": "67", "ระนอง": "68", "ชุมพร": "69", "สงขลา": "70", "สตูล": "71", "ตรัง": "72", "พัทลุง": "73",
    "ปัตตานี": "74", "ยะลา": "75", "นราธิวาส": "76", "บึงกาฬ": "77",
}
SCALE_CODE = {"500": "1", "1000": "2", "2000": "3", "4000": "5"}

# timeout แบบ (ต่อ, อ่าน) — ต่อไม่ได้รู้ใน ~6 วิ · คำค้นที่ช้ายังมีเวลาอ่านเท่าเดิม
T_PUBLIC = (6.05, 20)
T_SHEET = (6.05, 25)
_SHEET_PAGE = 3000          # แถวต่อหน้าของรายชื่อเลขในระวาง (= maxRecordCount ของชั้น 6)
_SHEET_MAX_PAGES = 20       # เพดานหน้า (60,000 แปลง/ระวาง — เกินนี้ถือว่าไม่รู้ ไม่สรุป)
T_LOGIN = (6.05, 20)
T_SURVEY = (6.05, 30)
T_LIS = (6.05, 30)

# session ใช้ร่วม (keep-alive) -> ArcGIS + UDM host เดียวกัน
_PUBLIC_SESSION = _new_session(_UA)
# session ที่ login แล้ว (เก็บใน memory เท่านั้น — ปิด QGIS แล้วหาย ไม่บันทึกลงดิสก์)
_AUTH = {"session": None, "credentials": None}
_LIS_PROV = {}              # ชื่อจังหวัด -> ค่าในช่องจังหวัดของหน้า LIS (อ่านครั้งเดียวต่อ session)


class DOLError(Exception):
    """ข้อผิดพลาดของระบบกรม/ข้อมูล — ข้อความ (str) แสดงให้ผู้ใช้ได้ · detail = คำตอบดิบจากระบบกรม (ลง Log ไม่ใส่ในกล่อง)"""

    def __init__(self, msg="", detail=""):
        super().__init__(msg)
        self.detail = detail


def _resp_json(r, what="ระบบแผนที่ของกรม"):
    """r.json() ที่อ่านไม่ได้ (HTML จาก WAF/หน้า error ที่ตอบ HTTP 200) ⇒ DOLError ภาษาไทย + เนื้อคำตอบใน detail"""
    try:
        return r.json()
    except ValueError as e:
        try:
            body = (r.text or "")[:2000]
        except Exception:
            body = ""
        raise DOLError(f"{what}ตอบข้อมูลที่อ่านไม่ได้ (อาจเป็นหน้าเตือนของระบบเครือข่าย) — ลองใหม่ภายหลัง ({_LOG_HINT})",
                       detail=f"{type(e).__name__}: {e} · {body}"[:2500])


class DOLServiceError(DOLError):
    """บริการค้นหลักฐานรังวัดตอบ success:false = ทำรายการไม่สำเร็จ (≠ "ไม่พบข้อมูล")"""


class DOLAuthError(Exception):
    """login ล้มเหลว / token หมดอายุ · ask_again=True = ถามชื่อผู้ใช้/รหัสผ่านใหม่แล้วอาจผ่าน"""

    def __init__(self, msg="", ask_again=False):
        super().__init__(msg)
        self.ask_again = ask_again


def net_reason(e):
    """exception ของ requests ⇒ เหตุภาษาไทยสั้น ๆ · ไม่ใช่ของ requests ⇒ None
    🔑 SSLError และ ConnectTimeout เป็นลูกของ ConnectionError ⇒ ตรวจก่อน"""
    try:
        if isinstance(e, requests.exceptions.SSLError):
            return SSL_MSG
        if isinstance(e, requests.exceptions.Timeout):
            return "ระบบปลายทางตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
        if isinstance(e, requests.exceptions.ConnectionError):
            return "เชื่อมต่อเครือข่ายไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
        if isinstance(e, requests.exceptions.HTTPError):
            code = getattr(getattr(e, "response", None), "status_code", None)
            return f"ระบบปลายทางตอบผิดปกติ (HTTP {code})" if code else "ระบบปลายทางตอบผิดปกติ"
        if isinstance(e, requests.exceptions.RequestException):
            return "การเชื่อมต่อผิดพลาด"
    except Exception:
        pass
    return None


def _as_int(v, what):
    """ค่าตัวเลขจาก attribute/QSettings -> int · รับ '2.0' / 4000.0 · ไม่ใช่ตัวเลข ⇒ DOLError ภาษาไทยที่บอกว่าช่องไหน"""
    s = "" if v is None else str(v).strip()
    try:
        return int(s)
    except ValueError:
        pass
    try:
        f = float(s)
    except ValueError:
        f = None
    if f is not None and f.is_integer():
        return int(f)
    raise DOLError(f"{what} ไม่ใช่ตัวเลข: {v!r}")


def _map2(v):
    """UTMMAP2 เลขโรมัน I–IV → '1'–'4' (ค่าอื่นคืนเดิม) — ชั้น ArcGIS กับหน้าค้นหลักฐานการรังวัดใช้เลข"""
    s = "" if v is None else str(v).strip().upper()
    return str(_ROMAN_NUM[s]) if s in _ROMAN_NUM else v


def scale_code(scale):
    """มาตราส่วนของระวาง -> รหัสที่ servlet ค้นหลักฐานรังวัดใช้ · ไม่รู้จัก ⇒ DOLError ก่อนยิงเน็ต"""
    code = SCALE_CODE.get(str(scale).strip())
    if code is None:
        try:
            code = SCALE_CODE.get(str(_as_int(scale, "มาตราส่วน")))
        except DOLError:
            code = None
    if code is None:
        raise DOLError(f"ยังไม่รองรับมาตราส่วน 1:{str(scale).strip()} สำหรับค้นหลักฐานการรังวัด")
    return code


def doc_url(seq, plate_type="1"):
    """URL หน้าดูภาพลักษณ์ (evdsimgs001) จาก PARCEL_SEQ"""
    if not seq:
        return ""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=1&readOnly=2&dataId={seq}&plateType={plate_type}&page=1")


def _parcel_layer(zone):
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        raise DOLError(f"ไม่รองรับ zone {zone}")
    return layer


def _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                        zone=47, near_xy=None, timeout=None, layer=None, office_seq=None):
    """ArcGIS: attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ (None ถ้าไม่พบ)
    near_xy=(x,y) ใน EPSG:240{zone}: ระวางคร่อมหลายสาขา (LAND_NO ซ้ำข้ามสาขา) ⇒ เลือกแปลงที่ใกล้จุดคลิกที่สุด
    layer: URL ชั้นอื่นที่มีช่องคีย์ชุดเดียวกัน (ชั้นรอจด/ประวัติ) · office_seq: เอาเฉพาะแปลงของสำนักงานนี้ (ล็อกสาขา)"""
    layer = layer or _parcel_layer(zone)

    def _q(v):
        return str(v).replace("'", "''")      # escape ' กัน where-clause พัง/ถูกฉีดเงื่อนไข
    where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(_map2(utmmap2), 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
             f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')} AND LAND_NO='{_q(landno)}'")
    if office_seq:
        where += f" AND LANDOFFICE_SEQ={_as_int(office_seq, 'รหัสสำนักงานที่ดิน')}"
    params = {"where": where, "outFields": "MAP_PARCEL_SEQ,ORIGIN_X,ORIGIN_Y,LANDOFFICE_SEQ,LAND_NO",
              "returnGeometry": "false", "f": "json"}
    try:
        r = _PUBLIC_SESSION.get(f"{layer}/query", params=params, timeout=timeout or T_PUBLIC)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)
    r.raise_for_status()
    j = _resp_json(r)
    if not isinstance(j, dict):
        raise DOLError(f"ระบบแผนที่ของกรมตอบข้อมูลรูปแบบไม่ถูกต้อง — ลองใหม่ภายหลัง ({_LOG_HINT})",
                       detail=f"ArcGIS: {str(j)[:2000]}")
    # ArcGIS ตอบ error เป็น HTTP 200 + {"error": {...}} — ห้ามอ่านเป็น "ไม่พบแปลง" เงียบ ๆ
    if "error" in j:
        err = j["error"]
        if isinstance(err, dict):
            det = err.get("details")
            if isinstance(det, (list, tuple)):
                det = "; ".join(str(d) for d in det)
            msg = err.get("message") or (str(det) if det else "") or str(err)
        else:
            msg = str(err)
        raise DOLError(f"ระบบแผนที่ของกรมตอบข้อผิดพลาด — ค้นแปลงด้วยระวางนี้ไม่ได้ตอนนี้ ลองใหม่ภายหลัง ({_LOG_HINT})",
                       detail=f"ArcGIS error: {msg} · {err}"[:2000])
    _raw = j.get("features") or []
    feats = [f for f in _raw if isinstance(f, dict) and isinstance(f.get("attributes"), dict)]
    if _raw and not feats:
        raise DOLError(f"ระบบแผนที่ของกรมตอบข้อมูลแปลงไม่ครบ — ลองใหม่ภายหลัง ({_LOG_HINT})",
                       detail=f"ArcGIS features: {str(_raw)[:2000]}")
    if not feats:
        return None
    if near_xy and len(feats) > 1:
        nx, ny = near_xy

        def _dist2(f):
            a = f.get("attributes") or {}
            x, y = a.get("ORIGIN_X"), a.get("ORIGIN_Y")
            if x is None or y is None:
                return float("inf")
            try:
                return (float(x) - nx) ** 2 + (float(y) - ny) ** 2
            except (TypeError, ValueError):
                return float("inf")
        feats.sort(key=_dist2)
    att = dict(feats[0]["attributes"])
    att["_match_count"] = len(feats)   # >1 = ระวางกำกวม (เลือกตัวใกล้สุดแล้ว)
    return att


def query_parcels(url, where, zone, fields="MAP_PARCEL_SEQ,LANDOFFICE_SEQ,PARCEL_TYPE", timeout=None):
    """[(attributes, rings)] จากชั้น ArcGIS ของกรม (url) ตามเงื่อนไข where — รูปในพิกัด EPSG:240{zone}
    ถามตรงด้วยเลขแปลง = เร็ว (มีดัชนี) · ส่งเงื่อนไขเดียวกันผ่านชั้นของ QGIS ช้ากว่ามาก (~14 วิ)"""
    try:
        r = _PUBLIC_SESSION.get(f"{url}/query", timeout=timeout or T_PUBLIC, params={
            "where": where, "outFields": fields, "returnGeometry": "true", "outSR": 24000 + int(zone), "f": "json"})
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)
    r.raise_for_status()
    j = _resp_json(r)
    if not isinstance(j, dict) or "error" in j:
        raise DOLError(f"ระบบแผนที่ของกรมตอบข้อผิดพลาด — ลองใหม่ภายหลัง ({_LOG_HINT})", detail=str(j)[:2000])
    out = []
    for f in j.get("features") or []:
        rings = ((f or {}).get("geometry") or {}).get("rings")
        if rings:
            out.append((f.get("attributes") or {}, rings))
    return out


def fetch_parcels_by_seq(seqs, zone=47, first_url=None, timeout=None):
    """รูปแปลงจากแผนที่กรมตามเลขแปลง (MAP_PARCEL_SEQ) — ระบายโฉนดที่จับคู่
    ลำดับชั้นที่ถาม: first_url (ชั้น UTM ของโปรเจกต์) → ชั้นที่ pipeline ใช้จับคู่ (MapTEMP ชั้น 3) → ชั้นแปลงปัจจุบัน (ชั้น 6)
    (โฉนดบางแปลงเป็นของสำนักงานอื่น / อยู่คนละชั้นของกรม) · ไม่กรองสำนักงาน
    คืน {seq: {"rings", "office", "parcel_type", "src": url ของชั้นที่เจอ}} ในพิกัด EPSG:240{zone} · ถามไม่ได้ = ข้ามชั้นนั้น"""
    want = [s for s in (_seq_txt(x) for x in seqs) if s.isdigit()]
    out = {}
    layers = []
    for u in (first_url, f"{BASE}/arcgis/rest/services/MapTEMP_{int(zone)}/MapServer/3", _parcel_layer(zone)):
        if u and u.rstrip("/") not in layers:
            layers.append(u.rstrip("/"))
    for layer in layers:
        todo = [s for s in want if s not in out]
        if not todo:
            break
        for i in range(0, len(todo), 100):
            chunk = todo[i:i + 100]
            try:
                rows = query_parcels(layer, "MAP_PARCEL_SEQ IN (%s)" % ",".join(chunk), zone, timeout=timeout)
            except Exception:
                continue
            for a, rings in rows:
                s = _seq_txt(a.get("MAP_PARCEL_SEQ"))
                if s and s not in out:
                    out[s] = {"rings": rings, "office": a.get("LANDOFFICE_SEQ"), "parcel_type": a.get("PARCEL_TYPE"),
                              "src": layer}
    return out


def esri_rings_wkt(rings):
    """วงของ polygon แบบ Esri JSON -> WKT MULTIPOLYGON (วงตามเข็ม = ขอบนอก · ทวนเข็ม = รูของขอบนอกก่อนหน้า)"""
    polys = []
    for ring in rings or []:
        if len(ring) < 4:
            continue
        a2 = sum(ring[k][0] * ring[k + 1][1] - ring[k + 1][0] * ring[k][1] for k in range(len(ring) - 1))
        txt = "(" + ",".join("%.3f %.3f" % (p[0], p[1]) for p in ring) + ")"
        if a2 < 0 or not polys:            # ตามเข็ม (พื้นที่ติดลบ) = ขอบนอก
            polys.append([txt])
        else:
            polys[-1].append(txt)
    if not polys:
        return ""
    return "MULTIPOLYGON(" + ",".join("(" + ",".join(p) + ")" for p in polys) + ")"


def get_map_information(x, y, zone=47, parcel_type=1, timeout=None):
    try:
        return _get_map_information(x, y, zone, parcel_type, timeout or T_PUBLIC)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)


def _get_map_information(x, y, zone=47, parcel_type=1, timeout=20):
    """UDM GetMapInformation: พิกัด (X,Y EPSG:240{zone}) -> ข้อมูลแปลง (dict)"""
    payload = {"Zone": str(zone), "X": str(x), "Y": str(y),
               "PARCEL_TYPE": str(parcel_type), "pid": "", "pr_Sys": "udm"}
    headers = {"Content-Type": "application/json; charset=utf-8",
               "X-Requested-With": "XMLHttpRequest"}
    r = _PUBLIC_SESSION.post(UDM_MAPINFO_URL, data=json.dumps(payload), headers=headers, timeout=timeout)
    r.raise_for_status()
    j = _resp_json(r, "ระบบ UDM ของกรม")
    try:
        return json.loads(j["d"])
    except (KeyError, TypeError, ValueError) as e:
        raise DOLError(f"ระบบ UDM ของกรมตอบข้อมูลรูปแบบไม่ถูกต้อง — ลองใหม่ภายหลัง ({_LOG_HINT})",
                       detail=f"UDM: {type(e).__name__}: {e} · {str(j)[:2000]}")


def sheet_land_numbers(utmmap1, utmmap2, utmmap3, utmmap4, scale, zone=47, timeout=None, office_seq=None):
    """ชุดเลขที่ดินที่ระบบ DOL มีอยู่จริงในระวางนั้น (set ของสตริง) — ใช้ตอบให้ตรงว่า "หาไม่เจอเพราะอะไร"
    แบ่งหน้าจนครบ · ถามไม่ได้ (หน้าใดหน้าหนึ่ง) = None (ผู้เรียกต้องแยกจาก set ว่าง)"""
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        return None

    def _q(v):
        return str(v).replace("'", "''")
    where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(_map2(utmmap2), 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
             f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')}")
    if office_seq:
        where += f" AND LANDOFFICE_SEQ={_as_int(office_seq, 'รหัสสำนักงานที่ดิน')}"
    out, offset = set(), 0
    try:
        for _page in range(_SHEET_MAX_PAGES):
            r = _PUBLIC_SESSION.get(f"{layer}/query", timeout=timeout or T_SHEET, params={
                "where": where, "outFields": "LAND_NO", "returnGeometry": "false", "f": "json",
                "orderByFields": "OBJECTID", "resultOffset": offset, "resultRecordCount": _SHEET_PAGE})
            r.raise_for_status()
            j = r.json()
            if not isinstance(j, dict) or "error" in j:
                return None
            feats = j.get("features") or []
            out |= {str((f.get("attributes") or {}).get("LAND_NO")).strip() for f in feats}
            if not feats or not (j.get("exceededTransferLimit") or len(feats) >= _SHEET_PAGE):
                return out
            offset += len(feats)
        return None
    except Exception:
        return None


def lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                            zone=47, parcel_type=1, near_xy=None, timeout=None, probe_xy=None, office_seq=None):
    """ค้นแปลงด้วยระวาง (รายละเอียดที่ _lookup_parcel_by_rawang) · ค้นแบบล็อกสาขา ⇒ ผลทุกแบบมี 'branch_office'"""
    r = _lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone=zone, parcel_type=parcel_type,
                                 near_xy=near_xy, timeout=timeout, probe_xy=probe_xy, office_seq=office_seq)
    if office_seq and isinstance(r, dict):
        r.setdefault("branch_office", str(office_seq).strip())
    return r


def _lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                             zone=47, parcel_type=1, near_xy=None, timeout=None, probe_xy=None, office_seq=None):
    """ระวาง(attribute) -> PARCEL_SEQ + ข้อมูลแปลง (public)
    near_xy / probe_xy = (x,y) EPSG:240{zone} ของจุดกลาง / จุดในแปลงที่คลิก
    ทางสำรองเมื่อ ArcGIS ไม่มีคีย์ (ลำดับ): ชั้นรอจด → UDM ที่ตำแหน่งแปลง → ชั้นประวัติ → รายชื่อเลขในระวาง → ทะเบียน iLands (login)
    คืน dict (มี 'verified' กันแปลงผิด, 'match_count' บอกความกำกวม) หรือ {'not_found': True, ...}"""
    arc = _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                              zone, near_xy=near_xy, timeout=timeout, office_seq=office_seq)
    # แผนที่ ArcGIS (ชั้น 6) มีคีย์นี้ แต่ใช้จุดกลางของมันถาม UDM ไม่ได้ ⇒ ไปทางสำรองแบบ "ไม่พบ" ต่อ แล้วติด arc_miss
    # 🔴 ห้ามสรุปว่า "ยกเลิกแล้ว" จากกรณีนี้ — ชั้น 6 ยังมีเลขอยู่
    arc_miss, d = None, None
    if arc:
        if arc.get("ORIGIN_X") is None or arc.get("ORIGIN_Y") is None:
            arc_miss = "no_origin"
        else:
            d = get_map_information(arc["ORIGIN_X"], arc["ORIGIN_Y"], zone, parcel_type, timeout=timeout)
            if not d:
                arc_miss = "udm_empty"
    if not arc or arc_miss:
        key = (utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
        # ② ชั้นแปลงรอจด/ชั่วคราว (คีย์) → จุดกลางของกรม → UDM ยืนยันคีย์ตรงทุกท่อน
        temp = None
        for L in ARCGIS_TEMP_LAYERS.get(int(zone), ()):
            t = _arcgis_try(*key, zone, near_xy, timeout, L, office_seq=office_seq)
            if not t or t.get("ORIGIN_X") is None or t.get("ORIGIN_Y") is None:
                continue
            hit, _h = _udm_point_lookup((t["ORIGIN_X"], t["ORIGIN_Y"]), *key, zone, parcel_type, timeout,
                                        office_seq=office_seq)
            if hit is not None:
                hit["via"] = "arcgis_temp"
                _remember_office(hit.get("office_seq"))
                return hit
            temp = temp or {"layer": L.split("/services/")[-1]}
        # ③ ตำแหน่งแปลงของเรา — รับเฉพาะแปลงที่คีย์ตรงทุกท่อน
        here = None
        xy = probe_xy or near_xy
        if xy:
            hit, here = _udm_point_lookup(xy, *key, zone, parcel_type, timeout, office_seq=office_seq)
            if hit is not None:
                if arc_miss:
                    hit["arc_miss"] = arc_miss
                _remember_office(hit.get("office_seq"))
                return hit
        # ④ ชั้นประวัติ (คีย์) — เลขนี้ถูกยกเลิกแล้ว · ตอนนี้ที่จุดเดิมเป็นแปลงอะไร
        history = None
        h = _arcgis_try(*key, zone, near_xy, timeout, ARCGIS_HISTORY_LAYER.get(int(zone)), office_seq=office_seq)
        if h:
            now = None
            if h.get("ORIGIN_X") is not None and h.get("ORIGIN_Y") is not None:
                hit, now = _udm_point_lookup((h["ORIGIN_X"], h["ORIGIN_Y"]), *key, zone, parcel_type, timeout,
                                             office_seq=office_seq)
                if hit is not None:
                    hit["via"] = "arcgis_history"
                    _remember_office(hit.get("office_seq"))
                    return hit
            history = {"now": now}
        # หาไม่เจอ: "ระวางมี แต่ไม่มีเลขนี้" หรือ "ไม่มีระวางนี้เลย"
        เลข = sheet_land_numbers(utmmap1, utmmap2, utmmap3, utmmap4, scale, zone, timeout=timeout, office_seq=office_seq)
        out = {"not_found": True,
               "sheet_exists": (None if เลข is None else bool(เลข)),
               "sheet_land_count": (None if เลข is None else len(เลข)),
               "asked_land_no": str(landno).strip()}
        if here:
            out["udm_here"] = here
        if arc_miss:
            out["arc_miss"] = arc_miss
        if office_seq:
            out["branch_office"] = str(office_seq).strip()
        if temp:
            out["temp"] = temp
        if history:
            out["history"] = history
        if office_seq:
            อื่น = _arcgis_try(*key, zone, near_xy, timeout, ARCGIS_PARCEL_LAYER.get(int(zone)))
            oo = str((อื่น or {}).get("LANDOFFICE_SEQ") or "").strip()
            if อื่น and oo and oo != str(office_seq).strip():
                out["other_office"] = {"office_seq": oo, "match_count": อื่น.get("_match_count", 1)}
        # ⑤ ทางสุดท้าย: ทะเบียน iLands (หน้า LIS · ต้อง login · ช้า) — ไม่ถามเมื่อรู้แล้วว่ายกเลิก/รอจด
        if not history and not temp:
            if is_logged_in():
                try:
                    lis = lookup_parcel_lis(*key, zone=zone, near_xy=near_xy, here=here, timeout=timeout,
                                            office_seq=office_seq)
                except DOLAuthError:
                    out["lis"] = "login"
                except DOLError as e:
                    out["lis"], out["lis_error"] = "error", str(e)
                except Exception as e:
                    out["lis"], out["lis_error"] = "error", f"หน้าทะเบียน iLands ตอบผิดรูปแบบ ({type(e).__name__})"
                else:
                    if not lis.get("not_found"):
                        return lis
                    out["lis"] = "none"
            else:
                out["lis"] = "login"              # UI ถามว่าจะเข้าสู่ระบบแล้วค้นในทะเบียนต่อไหม
        return out
    # ArcGIS มีคีย์ + มีจุดกลาง + UDM ตอบข้อมูลที่จุดนั้น — ยืนยันว่าเป็นแปลงเดียวกัน
    map_seq = _seq_txt(arc.get("MAP_PARCEL_SEQ"))
    idx = -1
    _seqs = d.get("strMapParcelSeqs")
    if isinstance(_seqs, (list, tuple)) and _seqs:
        try:
            idx = [_seq_txt(_x) for _x in _seqs].index(map_seq)
        except ValueError:
            pass
    # เลขแปลงในแผนที่ไม่ตรง ⇒ ยืนยันด้วยคีย์ 6 ท่อน (+ สำนักงานเมื่อล็อกสาขา) — ต้องตรงรายการเดียวเท่านั้น
    verify_by = None
    if idx < 0 and _seq_txt(d.get("strMapParcelSeq")) != map_seq:
        want = _key6(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
        hits = [e for e in _udm_entries(d) if want is not None and e[1] == want
                and (not office_seq or not e[5] or e[5] == str(office_seq).strip())]
        if len(hits) == 1:
            idx, verify_by = hits[0][0], "key"
    res = _udm_result(d, idx, arc.get("_match_count", 1))
    res["verified"] = _seq_txt(res.get("map_parcel_seq")) == map_seq or verify_by == "key"
    if verify_by:
        res["verify_by"] = verify_by
    if res["verified"]:
        _remember_office(res.get("office_seq"))
    return res


def _seq_txt(v):
    """เลขแปลงจากคำตอบระบบกรม (สตริง/int/float) -> สตริงตัวเลขเทียบได้ ('960000038062173.0' = '960000038062173')"""
    s = "" if v is None else str(v).strip()
    try:
        f = float(s)
        if f.is_integer():
            return str(int(f))
    except ValueError:
        pass
    return s


def _udm_result(d, idx, match_count=1):
    """คำตอบ UDM GetMapInformation -> dict ผลค้นแปลง (ค่าของรายการที่ idx · idx<0 = ค่าเดี่ยว)"""
    def get_v(singular, plural):
        if idx >= 0 and isinstance(d.get(plural), (list, tuple)) and idx < len(d[plural]):
            return d[plural][idx]
        return d.get(singular)

    parcel_seq = get_v("strRegParcelSeq", "strRegParcelSeqs")
    # แปลงที่ "ไม่มีทะเบียน" ในระบบ DOL: UDM ตอบ strDisplayNotRegData='1' และไม่ส่ง PARCEL_SEQ
    not_reg = (str(get_v("strDisplayNotRegData", "strDisplayNotRegDatas")) == "1") or not parcel_seq
    return {
        "not_registered": not_reg,
        "match_count": match_count,
        "parcel_seq": parcel_seq,
        "map_parcel_seq": get_v("strMapParcelSeq", "strMapParcelSeqs"),
        "parcel_no": get_v("strParcelNo", "strParcelNos"),
        "land_no": get_v("strLandNo", "strLandNos"),
        "survey_no": get_v("strSurveyNo", "strSurveyNos"),
        "rawang": get_v("strRawang", "strRawangs"),
        "area": get_v("strArea", "strAreas"),
        "owner": get_v("strOwner", "strOwners"),
        "city": get_v("strCity", "strCitys"),
        "office": get_v("strOfficeSname", "strOfficeSnames"),
        "office_seq": get_v("strOfficeSeq", "strOfficeSeqs"),
        "parcel_type": get_v("strParcel_Type", "strParcel_Types"),
        "verified": False,
        "doc_url": doc_url(parcel_seq, "1"),
    }


# ระวางในคำตอบ UDM เช่น "5137 III 7456 - 08(1:1000)" · 1:4000 ส่งแค่ "5642 IV 1272" (ไม่มีท่อนท้าย = แผ่น 00 มาตราส่วน 1:4000)
_UDM_RAWANG_RE = re.compile(r"(\d{4})\s+([IVX]+|\d)\s+(\d{4})(?:\s*-\s*(\d+)\s*\(\s*1\s*:\s*(\d+)\s*\))?")
_ROMAN_NUM = {"I": 1, "II": 2, "III": 3, "IV": 4}


def _key6(m1, m2, m3, m4, scale, landno):
    """คีย์ 6 ท่อนแบบเทียบได้ (ตัดศูนย์นำหน้า · โรมัน → เลข) · อ่านไม่ได้ = None"""
    try:
        s2 = str(m2).strip().upper()
        n2 = _ROMAN_NUM[s2] if s2 in _ROMAN_NUM else int(float(s2))
        return (str(m1).strip(), n2, str(m3).strip(), int(float(str(m4).strip())),
                int(float(str(scale).strip())), int(float(str(landno).strip())))
    except (KeyError, TypeError, ValueError):
        return None


def _udm_entries(d):
    """[(idx, key6, rawang, land_no, parcel_type, office_seq)] ของทุกแปลงในคำตอบ UDM (idx<0 = คำตอบแบบค่าเดี่ยว)"""
    out = []
    seqs = d.get("strMapParcelSeqs")
    n = len(seqs) if isinstance(seqs, (list, tuple)) else 0
    rng = range(n) if n else [-1]
    for i in rng:
        def _v(s, pl):
            v = d.get(pl)
            if i >= 0 and isinstance(v, (list, tuple)) and i < len(v):
                return v[i]
            return d.get(s)
        rw, ln = _v("strRawang", "strRawangs"), _v("strLandNo", "strLandNos")
        m = _UDM_RAWANG_RE.search(str(rw or ""))
        k = (_key6(m.group(1), m.group(2), m.group(3), m.group(4) if m.group(4) is not None else "00",
                   m.group(5) if m.group(5) is not None else "4000", ln) if m else None)
        out.append((i, k, str(rw or "").strip(), str(ln or "").strip(),
                    str(_v("strParcel_Type", "strParcel_Types") or "").strip(),
                    str(_v("strOfficeSeq", "strOfficeSeqs") or "").strip()))
    return out


def _udm_point_lookup(xy, utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone=47, parcel_type=1, timeout=None,
                      office_seq=None):
    """ทางสำรองเมื่อ ArcGIS ไม่มีคีย์นี้: ถาม UDM (iLands) ที่จุด xy ในแปลงของเรา
    คืน (ผล, None) ถ้ามีแปลงของกรมที่จุดนั้นคีย์ตรงทุกท่อนเพียงแปลงเดียว · (None, ที่นี่) ถ้ามีแปลงแต่คีย์ไม่ตรง ·
    (None, None) ถ้าถามไม่ได้ / จุดนั้นไม่มีข้อมูล (ไม่โยนข้อผิดพลาด)"""
    want = _key6(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
    try:
        d = get_map_information(xy[0], xy[1], zone, parcel_type, timeout=timeout)
    except Exception:
        return None, None
    if not d or not isinstance(d, dict):
        return None, None
    ent = _udm_entries(d)
    hits = [e for e in ent if want is not None and e[1] == want
            and (not office_seq or not e[5] or e[5] == str(office_seq).strip())]
    if len(hits) == 1:
        res = _udm_result(d, hits[0][0], 1)
        res["verified"] = True                     # คีย์ตรงทุกท่อน + อยู่ในแปลงที่คลิก
        res["via"] = "udm_point"
        return res, None
    same = ([e for e in ent if want is not None and e[1] == want and e[5] and e[5] != str(office_seq).strip()]
            if office_seq and not hits else [])
    first = same[0] if same else next((e for e in ent if e[2] or e[3]), None)
    if first is None:
        return None, None
    _r = _udm_result(d, first[0], 1)
    here = {"rawang": first[2], "land_no": first[3], "parcel_type": first[4],
            "office_seq": str(_r.get("office_seq") or "").strip(), "city": str(_r.get("city") or "").strip()}
    if same:
        here["same_key"] = True
    return None, here


def _arcgis_try(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone, near_xy, timeout, layer, office_seq=None):
    """_arcgis_find_parcel ของชั้นเสริม — ชั้นเสริมล่ม/ตอบผิดรูป ไม่ทำให้ทั้งการค้นล้ม (None = ไม่พบในชั้นนั้น)"""
    if not layer:
        return None
    try:
        return _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                                   zone, near_xy=near_xy, timeout=timeout, layer=layer, office_seq=office_seq)
    except Exception:
        return None


def _sheet_offices(utmmap1, utmmap2, utmmap3, utmmap4, scale, near_xy=None, zone=47, timeout=None):
    """รหัสสำนักงาน (LANDOFFICE_SEQ) ของแปลงในระวางนี้บน ArcGIS ชั้น 6 — เรียงจากใกล้ near_xy ก่อน · ถามไม่ได้ = []"""
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        return []

    def _q(v):
        return str(v).replace("'", "''")
    try:
        where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(_map2(utmmap2), 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
                 f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')}")
        r = _PUBLIC_SESSION.get(f"{layer}/query", timeout=timeout or T_SHEET, params={
            "where": where, "outFields": "LANDOFFICE_SEQ,ORIGIN_X,ORIGIN_Y", "returnGeometry": "false",
            "f": "json", "resultRecordCount": 2000})
        r.raise_for_status()
        feats = (r.json() or {}).get("features") or []
    except Exception:
        return []
    best = {}
    for f in feats:
        a = f.get("attributes") or {}
        o = str(a.get("LANDOFFICE_SEQ") or "").strip()
        if not o:
            continue
        dd = 0.0
        if near_xy:
            try:
                dd = (float(a.get("ORIGIN_X")) - near_xy[0]) ** 2 + (float(a.get("ORIGIN_Y")) - near_xy[1]) ** 2
            except (TypeError, ValueError):
                dd = float("inf")
        best[o] = min(best.get(o, float("inf")), dd)
    return sorted(best, key=lambda o: best[o])


def _settings():
    from qgis.PyQt import QtCore
    return QtCore.QSettings()


def _last_office():
    """รหัสสำนักงานที่ค้นสำเร็จครั้งล่าสุด · ไม่มี = ''"""
    try:
        return str(_settings().value(_SETTINGS + "DOL/LastOfficeSeq", "", str) or "").strip()
    except Exception:
        return ""


def _remember_office(seq):
    seq = str(seq or "").strip()
    if not seq.isdigit():
        return
    try:
        _settings().setValue(_SETTINGS + "DOL/LastOfficeSeq", seq)
    except Exception:
        pass


# ==================== ทางสุดท้าย: ค้นทะเบียน iLands ด้วยคีย์ (หน้า LIS · ต้อง login · ช้า) ====================
_LIS_ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV"}
_LIS_RAWANG_RE = re.compile(r"(\d{4})\s+([IVX]+|\d)\s+(\d{4})\s*-\s*(\d+)")
# 🔐 หน้า LIS มีคอลัมน์ผู้ถือกรรมสิทธิ์ — ไม่อ่านคอลัมน์ที่หัวเข้ารูปแบบนี้เลย (ไม่เก็บ ไม่ส่งต่อ ไม่ลง Log)
_LIS_SKIP = re.compile("ชื่อ|ผู้ถือ|เจ้าของ|ผู้รับ|ผู้ขอ")
_LIS_COLS = {"ลำดับที่เอกสารสิทธิ": "parcel_seq", "PIN Code": "pin", "เลขโฉนดที่ดิน": "parcel_no",
             "เลขหน้าสำรวจ": "survey_no", "ระวาง ยู ที เอ็ม": "rawang", "มาตรา ส่วน": "scale",
             "เลขที่ดิน ยู ที เอ็ม": "land_no", "ตำบล": "tambol", "อำเภอ": "amphur", "จังหวัด": "province",
             "สำนักงานที่ดินที่ที่ดินตั้งอยู่": "office", "LANDOFFICE_SEQ": "office_seq"}


def _lis_form(t):
    """ค่าทุกช่องในฟอร์ม ASP.NET (hidden + select ที่เลือกอยู่) เหมือนเบราว์เซอร์ส่ง"""
    d = {}
    for m in re.finditer(r"<input\b([^>]*)>", t, re.I):
        a = m.group(1)
        n = re.search(r'name="([^"]*)"', a)
        if not n:
            continue
        ty = (re.search(r'type="([^"]*)"', a, re.I) or [None, "text"])[1].lower()
        if ty in ("submit", "button", "image", "checkbox", "radio"):
            continue
        v = re.search(r'value="([^"]*)"', a)
        d[n.group(1)] = html.unescape(v.group(1)) if v else ""
    for m in re.finditer(r'<select\b[^>]*name="([^"]*)"[^>]*>(.*?)</select>', t, re.I | re.S):
        sel = (re.search(r'<option[^>]*selected="selected"[^>]*value="([^"]*)"', m.group(2))
               or re.search(r'<option[^>]*value="([^"]*)"', m.group(2)))
        d[m.group(1)] = html.unescape(sel.group(1)) if sel else ""
    return d


def _lis_options(t, name):
    m = re.search(r'<select\b[^>]*name="%s"[^>]*>(.*?)</select>' % re.escape(name), t, re.I | re.S)
    if not m:
        return []
    return [(html.unescape(v), html.unescape(re.sub(r"<[^>]+>", "", x)).strip())
            for v, x in re.findall(r'<option[^>]*value="([^"]*)"[^>]*>(.*?)</option>', m.group(1), re.I | re.S)]


def _lis_check(r):
    """หน้าที่ได้ต้องเป็นหน้า QDocParcel (ไม่ใช่หน้า login) — เซสชันหมด = DOLAuthError ให้ถามรหัสใหม่"""
    if "dolauth/login" in str(getattr(r, "url", "")) or "ddlLandOffice" not in (r.text or ""):
        raise DOLAuthError("เซสชันของระบบกรมหมดอายุหรือบัญชีนี้ใช้หน้าทะเบียนไม่ได้ — เข้าสู่ระบบใหม่", ask_again=True)


def _lis_post(s, t, target, timeout, **vals):
    d = _lis_form(t)
    d.update(vals)
    d["__EVENTTARGET"], d["__EVENTARGUMENT"] = target, ""
    r = s.post(LIS_QDOCPARCEL_URL, data=d, timeout=timeout)
    r.raise_for_status()
    _lis_check(r)
    return r.text


def _lis_province_of_office(t, office_seq):
    """ค่าตัวเลือกจังหวัดของสำนักงานนี้ — ชื่อสำนักงานมีชื่อจังหวัดอยู่ ("สำนักงานที่ดินจังหวัดกาฬสินธุ์ สาขาหนองกุงศรี")"""
    name = dict(_lis_options(t, "ddlLandOffice")).get(str(office_seq), "")
    best = None
    for v, x in _lis_options(t, "ddlProvince"):
        if v and x and "เลือก" not in x and x in name and (best is None or len(x) > len(best[1])):
            best = (v, x)
    return best[0] if best else None


def _lis_rows(t):
    """ตารางผลของหน้า LIS -> [dict] เฉพาะคอลัมน์ที่ใช้ · 🔐 คอลัมน์ชื่อบุคคลไม่ถูกอ่านเลย · "ไม่พบข้อมูล" = []"""
    m = re.search(r'<table[^>]*id="gvwSearchResultList"[^>]*>(.*?)</table>', t, re.S | re.I)
    if not m:
        return []
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", m.group(1), re.S | re.I)
    if len(rows) < 2:
        return []

    def _cell(c):
        return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", c))).strip()
    head = [_cell(c) for c in re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", rows[0], re.S | re.I)]
    idx = {}
    for i, h in enumerate(head):
        if _LIS_SKIP.search(h):
            continue
        k = _LIS_COLS.get(h)
        if k:
            idx[k] = i
    out = []
    for r in rows[1:]:
        cs = re.findall(r"<td[^>]*>(.*?)</td>", r, re.S | re.I)
        if len(cs) < len(head) or "parcel_seq" not in idx:
            continue
        d = {k: _cell(cs[i]) for k, i in idx.items()}
        mm = _LIS_RAWANG_RE.search(d.get("rawang", ""))
        d["_key"] = (_key6(mm.group(1), mm.group(2), mm.group(3), mm.group(4), d.get("scale"), d.get("land_no"))
                     if mm else None)
        out.append(d)
    return out


def lis_search_by_key(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, office_seq, timeout=None):
    """ค้นทะเบียนด้วยคีย์ในหน้า iLands LIS QDocParcel ของสำนักงาน office_seq (ต้อง login)
    ทำแบบคนกด: จังหวัด → สำนักงาน → โหมด "ระวาง ยู ที เอ็ม" → มาตราส่วน → แผ่น + เลขที่ดิน → ค้นหา (5 รอบ · ช้า)
    🔑 ช่องระวางของหน้านี้รับโรมันติดกันไม่เว้นวรรค ("5642IV1272") · คืนเฉพาะแถวที่คีย์ตรงทุกท่อน (ไม่มีชื่อบุคคล)"""
    s = _AUTH["session"]
    if not s:
        raise DOLAuthError("ยังไม่ได้เข้าสู่ระบบ DOL", ask_again=True)
    want = _key6(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
    if want is None or want[1] not in _LIS_ROMAN:
        raise DOLError("คีย์ของแปลงไม่ครบ/ไม่ถูกรูปแบบ — ค้นในทะเบียน iLands ไม่ได้")
    timeout = timeout or T_LIS
    crit = {"SelectCriteria": "radParcelLandUTMMap"}
    rw = "%s%s%s" % (want[0], _LIS_ROMAN[want[1]], want[2])
    try:
        r = s.get(LIS_QDOCPARCEL_URL, timeout=timeout)
        r.raise_for_status()
        _lis_check(r)
        t = r.text
        _lis_remember_provinces(t)
        prov = _lis_province_of_office(t, office_seq)
        if not prov:
            raise DOLError(f"หน้าทะเบียน iLands ไม่มีสำนักงานรหัส {office_seq}")
        t = _lis_post(s, t, "ddlProvince", timeout, ddlProvince=prov)
        t = _lis_post(s, t, "ddlLandOffice", timeout, ddlLandOffice=str(office_seq))
        t = _lis_post(s, t, "radParcelLandUTMMap", timeout, **crit)
        sc = next((v for v, x in _lis_options(t, "ddlUTMScale") if x == str(want[4])), None)
        if not sc:
            raise DOLError(f"หน้าทะเบียน iLands ไม่มีมาตราส่วน 1:{want[4]}")
        t = _lis_post(s, t, "ddlUTMScale", timeout, txtUTMMap=rw, ddlUTMScale=sc, **crit)
        pg = next((v for v, x in _lis_options(t, "ddlUTMPage") if x == "%02d" % want[3]), None)
        if pg is None:
            raise DOLError(f"หน้าทะเบียน iLands ไม่มีแผ่นที่ {want[3]:02d} ของมาตราส่วน 1:{want[4]}")
        t = _lis_post(s, t, "btnSearch", timeout, txtUTMMap=rw, ddlUTMScale=sc, ddlUTMPage=pg,
                      txtUTMLandNo=str(want[5]), txtUTMLandNoTo="", **crit)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)
    except requests.RequestException as e:
        raise DOLError(f"ต่อหน้าทะเบียน iLands ไม่ได้: {net_reason(e)}")
    return [x for x in _lis_rows(t) if x.get("_key") == want]


def lookup_parcel_lis(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone=47, near_xy=None, here=None,
                      timeout=None, office_seq=None):
    """ทางสุดท้ายของการค้นแปลง: ทะเบียน iLands ด้วยคีย์ (ต้อง login) → dict แบบเดียวกับ lookup_parcel_by_rawang
    (via='lis' · verified) หรือ {'not_found': True} · ล็อกสาขา ⇒ ค้นเฉพาะสำนักงานนั้น"""
    offices = []
    cand = [office_seq] if office_seq else ([(here or {}).get("office_seq")] + _sheet_offices(
        utmmap1, utmmap2, utmmap3, utmmap4, scale, near_xy, zone, timeout) + [_last_office()])
    for o in cand:
        o = str(o or "").strip()
        if o.isdigit() and o not in offices:
            offices.append(o)
    if not offices:
        raise DOLError("ไม่รู้ว่าแปลงนี้อยู่สำนักงานที่ดินไหน — ค้นในทะเบียน iLands ไม่ได้")
    for o in offices[:2]:
        rows = lis_search_by_key(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, o, timeout=timeout)
        if rows:
            x = rows[0]
            _remember_office(x.get("office_seq") or o)
            return {"not_registered": False, "match_count": len(rows), "parcel_seq": x.get("parcel_seq"),
                    "map_parcel_seq": None, "parcel_no": x.get("parcel_no"), "land_no": x.get("land_no"),
                    "survey_no": x.get("survey_no"), "rawang": x.get("rawang"), "area": "", "owner": None,
                    "city": "จ.%s อ.%s ต.%s" % (x.get("province", ""), x.get("amphur", ""), x.get("tambol", "")),
                    "office": x.get("office"), "office_seq": x.get("office_seq") or o, "parcel_type": "โฉนดที่ดิน",
                    "pin": x.get("pin"), "verified": True, "via": "lis", "doc_url": doc_url(x.get("parcel_seq"), "1")}
    return {"not_found": True}


# ====================================================================
#  หลักฐานการรังวัด (ต้อง login — EvdPcadastral001Servlet)
# ====================================================================
def login(username, password, timeout=None):
    """login CAS -> เก็บ session (มี DOL-TOKEN) ใน memory · ไม่สำเร็จ = DOLAuthError"""
    timeout = timeout or T_LOGIN
    s = _new_session("Mozilla/5.0 " + _UA)
    try:
        r = s.get(LOGIN_URL, timeout=timeout)
        r.raise_for_status()
        m = re.search(r'name="lt"\s+value="([^"]*)"', r.text)
        lt = m.group(1) if m else ""
        r = s.post(LOGIN_URL, data={"username": username, "password": password,
                                    "lt": lt, "_eventId": "submit", "warn": "true"},
                   timeout=timeout, allow_redirects=True)
        r.raise_for_status()
    except requests.exceptions.SSLError:
        raise DOLAuthError(SSL_MSG)
    except requests.RequestException as e:
        raise DOLAuthError(f"เชื่อมต่อระบบเข้าใช้งานของกรมไม่ได้: {net_reason(e)}")
    if not s.cookies.get("DOL-TOKEN", ""):
        raise DOLAuthError("เข้าสู่ระบบกรมไม่สำเร็จ — ตรวจชื่อผู้ใช้/รหัสผ่าน หรือมีการเข้าระบบซ้อนอยู่", ask_again=True)
    _old = _AUTH.get("session")
    _AUTH["session"] = s
    _AUTH["credentials"] = (username, password)
    _close_session(_old, keep=s)
    return s


def _close_session(old, keep=None):
    if old is None or old is keep:
        return
    try:
        old.close()
    except Exception:
        pass


def is_logged_in():
    s = _AUTH["session"]
    return bool(s and s.cookies.get("DOL-TOKEN", ""))


def logout():
    _old = _AUTH.get("session")
    _AUTH["session"] = None
    _AUTH["credentials"] = None
    _LIS_PROV.clear()
    _close_session(_old)


def province_name_from_city(city):
    """ชื่อจังหวัดจากข้อความ strCity ('จ.กาฬสินธุ์ อ.ท่าคันโท ต.นาตาล' -> 'กาฬสินธุ์') · ไม่มีคำ "จ." ⇒ ค้นชื่อยาวก่อน · ไม่รู้ = ''"""
    city = str(city or "")
    m = re.search(r"จ\.\s*([^\s,;()]+)", city)
    if m:
        return m.group(1).strip()
    names = list(PROVINCE_CODE) + list(_settings_province_codes())
    for name in sorted(set(names), key=len, reverse=True):
        if name and name in city:
            return name
    return ""


def _settings_province_codes():
    """รหัสจังหวัดที่ตั้ง/จำไว้ใน QSettings: NS3KChecker/ProvinceCode/<ชื่อ> (ชนะ) + MultiLayerEditPro/ProvinceCode/<ชื่อ>"""
    out = {}
    try:
        s = _settings()
        for grp in ("MultiLayerEditPro/ProvinceCode", _SETTINGS + "ProvinceCode"):
            s.beginGroup(grp)
            try:
                for name in s.childKeys():
                    code = str(s.value(name, "", str) or "").strip()
                    if str(name).strip() and code.isdigit():
                        out[str(name).strip()] = code
            finally:
                s.endGroup()
    except Exception:
        pass
    return out


def province_code_candidates(city):
    """(ชื่อจังหวัด, [รหัสจังหวัดของ servlet หลักฐานรังวัด], อยู่ในตารางไหม) — ที่ตั้งไว้ใน QSettings ชนะตาราง PROVINCE_CODE
    ชื่อที่ไม่อยู่ในตาราง ⇒ [] (search_cadastral_any ถามช่องจังหวัดของหน้าทะเบียน iLands ต่อ)"""
    name = province_name_from_city(city)
    if not name:
        return "", [], False
    known = _settings_province_codes().get(name) or PROVINCE_CODE.get(name)
    return name, ([known] if known else []), bool(known)


def province_code_from_city(city):
    """(เข้ากันได้กับ MLEP) รหัสตัวแรกที่จะลอง · ไม่รู้จังหวัด = None"""
    _n, cands, _ok = province_code_candidates(city)
    return cands[0] if cands else None


def remember_province_code(name, code):
    """จำรหัสจังหวัดที่ค้นหลักฐานรังวัดเจอจริง (ครั้งต่อไปลองตัวนี้ก่อน)"""
    name, code = str(name or "").strip(), str(code or "").strip()
    if not name or not code.isdigit():
        return
    try:
        _settings().setValue(_SETTINGS + "ProvinceCode/" + name, code)
    except Exception:
        pass


def known_provinces():
    """ชื่อจังหวัดที่ยืนยันรหัสแล้ว (ในโค้ด ∪ QSettings)"""
    return sorted(set(PROVINCE_CODE) | set(_settings_province_codes()))


def _lis_remember_provinces(t):
    for v, x in _lis_options(t, "ddlProvince"):
        if v and x and "เลือก" not in x:
            _LIS_PROV[x.strip()] = v.strip()


def lis_province_value(name, timeout=None):
    """ค่าในช่องจังหวัดของหน้าทะเบียน iLands (ต้อง login) — ใช้เป็นรหัสสำรองตัวสุดท้ายของ servlet หลักฐานรังวัด
    (ระบบเดียวกันของกรม อาจใช้รหัสชุดเดียวกัน) · อ่านไม่ได้ = None (ไม่โยนข้อผิดพลาด)"""
    if name in _LIS_PROV:
        return _LIS_PROV[name]
    s = _AUTH["session"]
    if not s:
        return None
    try:
        r = s.get(LIS_QDOCPARCEL_URL, timeout=timeout or T_LIS)
        r.raise_for_status()
        _lis_check(r)
        _lis_remember_provinces(r.text)
    except Exception:
        return None
    v = _LIS_PROV.get(name)
    return v if v and str(v).isdigit() else None


def survey_doc_url(cadastral_seq, plate_type="1"):
    """URL หน้าหลักฐานการรังวัด (evdsimgs001 id=2) จาก CADASTRAL_SEQ"""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=2&readOnly=2&dataId={cadastral_seq}&plateType={plate_type}&page=1")


def _collect_cadastral(obj, out):
    """ไล่หา record ที่มี CADASTRAL_SEQ ใน response (dict/list ซ้อนกัน)"""
    if isinstance(obj, dict):
        if obj.get("CADASTRAL_SEQ"):
            out.append(obj)
        for v in obj.values():
            _collect_cadastral(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _collect_cadastral(v, out)


def _service_reason(j):
    """เหตุผลจากคำตอบ success:false ที่แสดงได้ = เฉพาะ "ข้อความ" (ไม่เกิน 3 ข้อความ · 300 ตัวอักษร)"""
    found = []

    def _walk(v, depth=0):
        if len(found) >= 3 or depth > 3:
            return
        if isinstance(v, str):
            s = " ".join(v.split())
            if s:
                found.append(s)
        elif isinstance(v, dict):
            for x in v.values():
                _walk(x, depth + 1)
        elif isinstance(v, (list, tuple)):
            for x in v:
                _walk(x, depth + 1)
    for k in ("errors", "message", "msg"):
        _v = j.get(k) if isinstance(j, dict) else None
        if isinstance(_v, (int, float)) and not isinstance(_v, bool):
            found.append(str(int(_v)) if isinstance(_v, float) and _v.is_integer() else str(_v))
        else:
            _walk(_v)
        if found:
            break
    return " · ".join(found)[:300] or "ไม่ระบุเหตุผล"


def search_cadastral(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                     province_code, office_seq, zone=47, timeout=None):
    """ค้นหลักฐานรังวัด -> list ของ record (มี CADASTRAL_SEQ); ต้อง login ก่อน · หลายรายการต่อแปลงได้"""
    s = _AUTH["session"]
    if not s:
        raise DOLAuthError("ยังไม่ได้เข้าสู่ระบบ DOL", ask_again=True)
    timeout = timeout or T_SURVEY
    sc = scale_code(scale)
    ln = int(landno) if str(landno).strip().lstrip("-").isdigit() else landno
    crit = {
        "boxnoValue": "", "sheetcodeValue": "", "cadastralnoValue": "",
        "numofsurveyqtyValue": "", "provinceValue": _as_int(province_code, "รหัสจังหวัดของระบบ DOL"),
        "landofficeValue": str(office_seq), "amphurValue": "", "tambolValue": "",
        "surveynoValue": "", "sheettypeValue": 1, "zonelandValue": str(zone),
        "scaleValue": int(sc), "utmmap1Value": str(utmmap1), "utmmap2Value": str(_map2(utmmap2)),
        "utmmap3Value": str(utmmap3), "utmmap4Value": str(utmmap4),
        "origionmap1Value": None, "origionmap2Value": None, "origionmap3Value": None,
        "airphotomapnameValue": "", "airphotomap1Value": None,
        "airphotomap2Value": None, "airphotomap3Value": None, "landnoValue": ln,
        "typeofsurveyValue": "", "titleValue": "", "surveyorfnameValue": "",
        "surveyorlnameValue": "", "surveyfdateValue": None, "surveyedateValue": None,
    }

    def _do_search(session):
        return session.post(EVD_CADASTRAL_URL,
                            data={"action": "load", "func": "search", "data": json.dumps([crit])},
                            headers={"X-Requested-With": "XMLHttpRequest",
                                     "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                            timeout=timeout, allow_redirects=False)

    def _parse_json(text):
        try:
            return json.loads(text)
        except ValueError:
            # ระบบ DOL ตอบแบบ ExtJS (key ไม่มีเครื่องหมายคำพูด) {success:true,results:1,data:[...]}
            fixed = re.sub(r'(^\{|,)(success|results|data|errors):', r'\1"\2":', text)
            return json.loads(fixed)

    def _classify(resp):
        """จัดประเภทคำตอบ -> ("expired", None) หรือ ("ok", json) · ระบบกรมล่ม (5xx/4xx) ≠ token หมดอายุ"""
        code = resp.status_code
        if 300 <= code < 400 or "/dolauth/login" in (resp.headers.get("Location", "") or ""):
            return "expired", None
        if code in (401, 403):
            return "expired", None
        body = resp.text or ""
        if code >= 500:
            raise DOLError(f"ระบบ DOL ไม่ตอบ (HTTP {code}) — ลองใหม่ภายหลัง", detail=body[:2000])
        if code >= 400:
            raise DOLError(f"ระบบ DOL ตอบผิดปกติ (HTTP {code}) — ลองใหม่ภายหลัง", detail=body[:2000])
        try:
            return "ok", _parse_json(body)
        except ValueError:
            pass
        if 'name="lt"' in body:
            return "expired", None
        raise DOLError("รูปแบบข้อมูลจากระบบ DOL เปลี่ยน — ค้นหลักฐานการรังวัดไม่ได้ · แจ้งผู้ดูแล", detail=body[:2000])

    def _search(session):
        try:
            resp = _do_search(session)
        except requests.exceptions.SSLError:
            raise DOLError(SSL_MSG)
        except requests.RequestException as e:
            raise DOLError(f"ค้นหารังวัดไม่สำเร็จ: {net_reason(e)}", detail=str(e))
        return _classify(resp)

    kind, j = _search(s)
    if kind == "expired":
        creds = _AUTH.get("credentials")
        if not creds:
            _AUTH["session"] = None
            raise DOLAuthError("การเข้าระบบหมดอายุ — ต้องเข้าสู่ระบบใหม่", ask_again=True)
        s = login(creds[0], creds[1])
        kind, j = _search(s)
        if kind == "expired":
            _AUTH["session"] = None
            raise DOLAuthError("ระบบ DOL ไม่ยอมรับการเข้าสู่ระบบ แม้เพิ่งเข้าสู่ระบบใหม่ — บัญชีนี้อาจไม่มีสิทธิ์"
                               "ค้นหลักฐานการรังวัด หรือระบบ DOL ขัดข้อง (ลองใหม่ภายหลัง)")
    if isinstance(j, dict) and str(j.get("success")).strip().lower() == "false":
        raise DOLServiceError(f"ระบบ DOL ตอบว่าค้นหาไม่สำเร็จ: {_service_reason(j)}", detail=str(j)[:2000])
    recs = []
    _collect_cadastral(j["data"] if isinstance(j, dict) and "data" in j else j, recs)
    seen, uniq = set(), []
    for rec in recs:
        cs = str(rec.get("CADASTRAL_SEQ"))
        if cs not in seen:
            seen.add(cs)
            uniq.append(rec)
    return uniq


def _same_office(recs, office_seq):
    """ตัดรายการที่ระบบกรมบอกว่าเป็นของสำนักงานอื่นทิ้ง (รายการของ servlet มีช่อง LANDOFFICE_SEQ)"""
    o = str(office_seq or "").strip()
    if not o:
        return list(recs)
    out = []
    for rec in recs:
        v = None
        for k in ("LANDOFFICE_SEQ", "LANDOFFICESEQ", "LANDOFFICE"):
            if rec.get(k) not in (None, "", "null"):
                v = str(rec.get(k)).strip()
                break
        if v is None or not v.isdigit() or v == o:
            out.append(rec)
    return out


def search_cadastral_any(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, city, office_seq, zone=47, timeout=None):
    """ค้นหลักฐานรังวัดด้วยรหัสจังหวัดของแปลง (ตาราง PROVINCE_CODE) · ชื่อจังหวัดที่ไม่อยู่ในตาราง ⇒ อ่านจากช่องจังหวัด
    ของหน้าทะเบียน iLands (ระบบเดียวกัน รหัสชุดเดียวกัน) แล้วจำไว้ · คืน dict {recs, code, name}
    DOLAuthError ส่งต่อให้หน้าจอถามรหัสผ่าน"""
    name, cands, _known = province_code_candidates(city)
    if not name:
        raise DOLError(f"ไม่รู้จังหวัดของแปลงนี้ ({city or 'ระบบ DOL ไม่ส่งชื่อจังหวัดมา'}) — ค้นหลักฐานการรังวัดไม่ได้")
    if not cands:
        lv = lis_province_value(name, timeout=timeout)
        if not lv:
            raise DOLError(f"ไม่รู้รหัสจังหวัด{name}ของระบบหลักฐานการรังวัด — ค้นไม่ได้ · แจ้งผู้ดูแล")
        remember_province_code(name, lv)
        cands = [lv]
    recs = search_cadastral(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, cands[0], office_seq,
                            zone=zone, timeout=timeout)
    return {"recs": _same_office(recs, office_seq), "code": cands[0], "name": name}
