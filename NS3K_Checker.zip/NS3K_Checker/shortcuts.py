# -*- coding: utf-8 -*-
"""คีย์ลัดของ NS3K Checker (แบบเดียวกับ MLEP / GPKG Editor) — ทำงานทั้งแอป (กดบนแผนที่ได้) · ตั้งเองได้ที่ ⌨ ตั้งค่า Shortcut
ค่าตั้งต้น Alt+1–4 (QGIS ไม่ได้ใช้) ตั้งให้ครั้งแรกครั้งเดียว — ผู้ใช้ล้างทิ้งแล้วไม่ใส่กลับ
ShortcutsMixin = เมธอดที่คลาส NS3KChecker สืบทอดไปใช้ · ต้องมี: iface · dlg · _alive · _shortcuts · _qgis_ready ·
_shortcut_actions() (รายการ (id, ป้าย, callable)) · _sc_fired(callable) · _apply_sc_hints()"""
import os
from qgis.PyQt.QtCore import Qt, QSettings, QCoreApplication
from qgis.PyQt.QtWidgets import (QAction, QApplication, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout,
                                 QKeySequenceEdit, QLabel, QMenu, QMessageBox, QPushButton, QScrollArea, QShortcut,
                                 QToolBar, QVBoxLayout, QWidget)
from qgis.PyQt.QtGui import QKeySequence
from qgis.core import Qgis
from .updater import _OWN_PROP, _qobj_dispose
from .util import _log_exc, _log_info

DEFAULT_KEYS = {"match": "Alt+1", "image": "Alt+2", "survey": "Alt+3", "clear": "Alt+4"}


class ShortcutsMixin:
    _SC_KEY = "NS3KChecker/Shortcut/"
    _SC_DEFAULTS_DONE = "NS3KChecker/ShortcutDefaultsSet"
    _RIVAL_PROP = "_ns3k_sc_rival_warned"     # ป้ายบน QApplication = เตือนคีย์ชนแล้วใน session นี้ (อยู่ข้ามการโหลดใหม่)

    def _own_tok(self):
        t = getattr(self, "_own_token", None)
        if not t:
            t = self._own_token = "ns3k-%x" % id(self)
        return t

    def _tag_own(self, obj):
        try:
            obj.setProperty(_OWN_PROP, self._own_tok())
        except Exception:
            pass

    def _sc_value(self, aid):
        """คีย์ที่ตั้งไว้ของปุ่ม aid (รูปแบบ QKeySequence.toString() เช่น 'Alt+1') · ไม่ได้ตั้ง = ''"""
        try:
            k = QSettings().value(self._SC_KEY + aid, "", str) or ""
            return QKeySequence(k).toString() if k else ""
        except Exception:
            return ""

    def _apply_default_shortcuts(self):
        """ตั้งคีย์ตั้งต้นครั้งแรกครั้งเดียว (ช่องที่ผู้ใช้เคยตั้ง/ล้างแล้วไม่แตะ)"""
        s = QSettings()
        if s.value(self._SC_DEFAULTS_DONE, False, bool):
            return
        for aid, seq in DEFAULT_KEYS.items():
            if not s.contains(self._SC_KEY + aid):
                s.setValue(self._SC_KEY + aid, seq)
        s.setValue(self._SC_DEFAULTS_DONE, True)

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับหน้าต่างหลัก (ทั้งแอป) · เรียกซ้ำได้ (initGui · QGIS เปิดเสร็จ · บันทึกคีย์ใหม่)"""
        for sc in self._shortcuts:
            _qobj_dispose(sc)
        self._shortcuts = []
        mw = self.iface.mainWindow()
        for aid, label, slot in self._shortcut_actions():
            seq = self._sc_value(aid)
            if not seq:
                continue
            sc = QShortcut(QKeySequence(seq), mw)
            # ชื่อเฉพาะต่อปุ่ม: QShortcut ไม่มีชื่อที่ QGIS ลงทะเบียนตอนเปิดโปรแกรม ใช้คีย์โปรไฟล์ '/shortcuts/' ร่วมกันทุกตัว
            sc.setObjectName("NS3KChecker_sc_" + aid)
            self._tag_own(sc)
            sc.setContext(Qt.ApplicationShortcut)
            sc.setAutoRepeat(False)
            sc.activated.connect(lambda _s=slot: self._sc_fired(_s))
            sc.activatedAmbiguously.connect(lambda _k=seq: self._sc_ambiguous(_k))
            self._shortcuts.append(sc)
        try:
            self._apply_sc_hints()
        except Exception:
            _log_exc("_load_shortcuts: อัปเดตป้ายคีย์ลัดไม่สำเร็จ", once_key="_apply_sc_hints")

    def _on_qgis_ready(self, *_a):
        """iface.initializationCompleted — QGIS ลงทะเบียน + ตั้งคีย์ลัดจากโปรไฟล์แล้ว ⇒ สร้างคีย์ลัดใหม่
        (ตัวที่สร้างตอน initGui ถูก QGIS ลงทะเบียนไปด้วย = ค่าในโปรไฟล์ตั้งคีย์ทับได้) แล้วตรวจคีย์ชนกับปลั๊กอินอื่น"""
        if not self._alive:
            return
        self._qgis_ready = True
        try:
            self._load_shortcuts()
        except Exception:
            _log_exc("_on_qgis_ready: สร้างคีย์ลัดใหม่ไม่สำเร็จ", once_key="_on_qgis_ready_sc")
        try:
            self._sc_rival_warn()
        except Exception:
            _log_exc("_on_qgis_ready: ตรวจคีย์ลัดชนไม่สำเร็จ", once_key="_on_qgis_ready_rival")

    def _sc_ambiguous(self, key):
        """Qt เจอคีย์เดียวกันสองที่ = ไม่ยิงทั้งคู่ ⇒ บอกผู้ใช้ว่าชนกับอะไร (ครั้งเดียวต่อ session)"""
        if not self._alive:
            return
        try:
            if not self._sc_rival_warn():
                self.iface.messageBar().pushMessage(
                    "NS3K Checker", f"คีย์ลัด {key} ชนกับคีย์ของโปรแกรม/ปลั๊กอินอื่น — กดแล้วจึงไม่ทำงาน "
                                    "· เปลี่ยนคีย์ได้ที่ ⌨ ตั้งค่า Shortcut", level=1, duration=8)
        except Exception:
            _log_exc("_sc_ambiguous", once_key="_sc_ambiguous")

    def _key_rivals(self, key):
        """QShortcut/QAction ที่ไม่ใช่ของปลั๊กอินนี้ ซึ่งใช้คีย์ key แบบชนกันจริง: ทั้งแอป (ApplicationShortcut)
        หรือทั้งหน้าต่างหลัก (WindowShortcut ใต้หน้าต่างหลัก · รวมเมนู/แถบเครื่องมือ) · ไม่นับของที่ติดป้ายของเรา/QShortcut ที่ปิดอยู่"""
        mw = self.iface.mainWindow()
        if not key or mw is None:
            return []
        ks = QKeySequence(key)
        from qgis.PyQt import sip as _sip

        def _p(o):
            try:
                return _sip.unwrapinstance(o)
            except Exception:
                return None
        mwp = _p(mw)

        def _in_mw(w):
            n = 0
            while w is not None and n < 50:
                if _p(w) == mwp:
                    return True
                w = w.parentWidget()
                n += 1
            return False
        A, W = Qt.ApplicationShortcut, Qt.WindowShortcut
        tops = [mw] + [w for w in QApplication.topLevelWidgets() if _p(w) != mwp]
        out, seen = [], set()
        for top in tops:
            own = _p(top) == mwp
            objs = top.findChildren(QShortcut) + top.findChildren(QAction)
            if own:
                try:
                    objs += list(top.actions())
                    for w in top.findChildren(QToolBar) + top.findChildren(QMenu):
                        objs += list(w.actions())
                except Exception:
                    pass
            for o in objs:
                try:
                    po = _p(o)
                    if po in seen:
                        continue
                    seen.add(po)
                    if o.property(_OWN_PROP):
                        continue
                    if isinstance(o, QShortcut):
                        if not o.isEnabled() or o.key() != ks:
                            continue
                        ctx, ws = o.context(), [o.parentWidget()]
                    else:
                        if not any(q == ks for q in o.shortcuts()):
                            continue
                        ctx, ws = o.shortcutContext(), list(o.associatedWidgets())
                    if ctx == A or (own and ctx == W and any(_in_mw(w) for w in ws)):
                        out.append(o)
                except Exception:
                    continue
        return out

    def _rival_names(self, objs):
        """ป้ายที่บอกผู้ใช้ได้: "ปลั๊กอิน 'ชื่อ'" (หาวัตถุในตัวแปรของปลั๊กอินใน qgis.utils.plugins) · ไม่เจอ ⇒ "คำสั่ง 'ข้อความ'" """
        from qgis.PyQt import sip as _sip

        def _p(o):
            try:
                return _sip.unwrapinstance(o)
            except Exception:
                return None
        try:
            import qgis.utils as _qu
            plugins = dict(getattr(_qu, "plugins", None) or {})
        except Exception:
            _qu, plugins = None, {}
        me = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
        names = []
        for o in objs:
            po, nm = _p(o), ""
            for pkg, inst in plugins.items():
                if pkg == me or nm:
                    continue
                try:
                    vals = list(vars(inst).values())
                except Exception:
                    continue
                for v in vals:
                    cand = (list(v.values()) if isinstance(v, dict)
                            else (list(v) if isinstance(v, (list, tuple, set)) else [v]))
                    if any(isinstance(c, (QShortcut, QAction)) and _p(c) == po for c in cand):
                        nm = pkg
                        try:
                            md = _qu.pluginMetadata(pkg, "name")
                            if md and md != "__error__":
                                nm = md
                        except Exception:
                            pass
                        nm = f"ปลั๊กอิน '{nm}'"
                        break
            if not nm:
                try:
                    nm = ((o.text() if isinstance(o, QAction) else "") or o.objectName() or "").replace("&", "")
                except Exception:
                    nm = ""
                nm = f"คำสั่ง '{nm}'" if nm else ""
            if nm and nm not in names:
                names.append(nm)
        return names

    def _sc_rival_warn(self):
        """คีย์ลัดของเราชนกับคีย์ทั้งแอปของปลั๊กอินอื่น/QGIS ⇒ บอกผู้ใช้ครั้งเดียวต่อ session (แถบเหลือง) · คืน True = เตือนแล้ว"""
        if not self._alive:
            return False
        app = QCoreApplication.instance()
        try:
            if app is not None and app.property(self._RIVAL_PROP):
                return False
        except Exception:
            pass
        labels = {aid: label for aid, label, _s in self._shortcut_actions()}
        found = []
        for aid in labels:
            key = self._sc_value(aid)
            if not key:
                continue
            rv = self._key_rivals(key)
            if rv:
                names = self._rival_names(rv)
                found.append(f"{key} ({labels[aid]}) ชนกับ {', '.join(names[:2]) if names else 'ปลั๊กอิน/คำสั่งอื่น'}")
        if not found:
            return False
        try:
            if app is not None:
                app.setProperty(self._RIVAL_PROP, True)
        except Exception:
            pass
        _log_info("คีย์ลัดของ NS3K Checker ชนกัน: " + " · ".join(found), Qgis.Warning)
        try:
            self.iface.messageBar().pushMessage(
                "คีย์ลัดชนกัน", "คีย์ลัดของ NS3K Checker ที่จะไม่ทำงาน: " + " · ".join(found)
                + " — ใช้ปุ่มในหน้าต่างแทน หรือเปลี่ยนคีย์ที่ ⌨ ตั้งค่า Shortcut", level=1, duration=0)
        except Exception:
            pass
        return True

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม — ตรวจคีย์ซ้ำก่อนบันทึก (ไม่ผ่าน = ไม่ปิดกล่อง)"""
        parent = self.dlg if self.dlg is not None else self.iface.mainWindow()
        dlg = QDialog(parent)
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(400)
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel("คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\n"
                           "ทำงานทั้งแอป (กดบนแผนที่ได้) · ยังไม่เปิดหน้าต่างปลั๊กอินก็กดได้"))
        s = QSettings()
        form = QFormLayout()
        editors, labels = {}, {}
        for aid, label, _slot in self._shortcut_actions():
            ed = QKeySequenceEdit(QKeySequence(s.value(self._SC_KEY + aid, "", str)))
            editors[aid] = ed
            labels[aid] = label
            btn_clr = QPushButton("✖")
            btn_clr.setFixedWidth(28)
            btn_clr.setToolTip("ล้างปุ่มลัดของบรรทัดนี้ให้ว่าง")
            btn_clr.clicked.connect(ed.clear)
            row = QHBoxLayout()
            row.addWidget(ed, 1)
            row.addWidget(btn_clr, 0)
            w = QWidget()
            w.setLayout(row)
            form.addRow(label + ":", w)
        inner = QWidget()
        inner.setLayout(form)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(inner)
        v.addWidget(scroll)
        btn_def = QPushButton("คืนค่าตั้งต้น (Alt+1 – Alt+4)")
        btn_def.setAutoDefault(False)

        def _defaults():
            for aid, ed in editors.items():
                ed.setKeySequence(QKeySequence(DEFAULT_KEYS.get(aid, "")))
        btn_def.clicked.connect(_defaults)
        v.addWidget(btn_def)
        warn = QLabel("")
        warn.setWordWrap(True)
        warn.setStyleSheet("color:#b71c1c; font-weight:bold;")
        warn.setVisible(False)
        v.addWidget(warn)
        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        v.addWidget(btns)

        def _validate():
            use = {}
            for aid, ed in editors.items():
                seq = ed.keySequence().toString()
                if seq:
                    use.setdefault(seq, []).append(aid)
            dup = {q: a for q, a in use.items() if len(a) > 1}
            for aid, ed in editors.items():
                seq = ed.keySequence().toString()
                ed.setStyleSheet("border:2px solid #d32f2f;" if seq and seq in dup else "")
            if dup:
                warn.setText("⚠️ คีย์ซ้ำกัน (1 คีย์ใช้ได้กับปุ่มเดียว): " + " · ".join(
                    f"{q} = {' / '.join(labels.get(a, a) for a in aids)}" for q, aids in sorted(dup.items()))
                    + "\n(ยังไม่ได้บันทึก — แก้ช่องที่ขีดแดงแล้วกด Save อีกครั้ง)")
                warn.setVisible(True)
                return
            dlg.accept()
        btns.accepted.connect(_validate)
        btns.rejected.connect(dlg.reject)
        try:
            accepted = dlg.exec_() == QDialog.Accepted
            vals = {aid: ed.keySequence().toString() for aid, ed in editors.items()}
        finally:
            dlg.deleteLater()
        if not accepted or not self._alive:
            return
        for aid, seq in vals.items():
            s.setValue(self._SC_KEY + aid, seq)
        s.setValue(self._SC_DEFAULTS_DONE, True)
        self._load_shortcuts()
        qgis_keys = self._qgis_shortcut_keys()
        conflict = {seq for seq in vals.values() if seq and seq in qgis_keys}
        msg = "บันทึก shortcut แล้ว ✅"
        if conflict:
            ck = ", ".join(sorted(conflict))
            ans = QMessageBox.question(
                parent, "คีย์ชนกับ QGIS",
                f"คีย์เหล่านี้ QGIS ใช้อยู่: {ck}\n"
                "ถ้าปล่อยไว้ Qt จะถือว่ากำกวม → ปุ่มลัดอาจไม่ทำงาน\n\n"
                "ต้องการให้ปลดคีย์เดิมของ QGIS ออกเพื่อให้ปลั๊กอินใช้คีย์นี้ได้ไหม?\n"
                "(เปลี่ยนคีย์ลัด QGIS ถาวร — ย้อนคืนได้ที่ Settings → Keyboard Shortcuts)",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ans == QMessageBox.Yes:
                released = self._release_qgis_shortcuts(conflict)
                self._load_shortcuts()
                if released:
                    msg += f"\n✅ ปลดคีย์ QGIS แล้ว: {', '.join(sorted(released))}"
                left = conflict - released
                if left:
                    msg += f"\n⚠️ ปลดไม่ได้: {', '.join(sorted(left))} (แก้เองที่ Settings → Keyboard Shortcuts)"
            else:
                msg += f"\n⚠️ ยังชนกับ QGIS: {ck} (ปุ่มลัดอาจไม่ทำงาน)"
        rv = []
        for seq in sorted({x for x in vals.values() if x}):
            objs = [o for o in self._key_rivals(seq) if isinstance(o, QShortcut)]
            if objs:
                names = self._rival_names(objs)
                rv.append(f"{seq} ({', '.join(names[:2]) if names else 'ปลั๊กอินอื่น'})")
        if rv:
            msg += ("\n⚠️ ชนกับคีย์ลัดของปลั๊กอินอื่น: " + " · ".join(rv)
                    + "\n    คีย์เหล่านี้จะไม่ทำงาน — ถ้าใช้บ่อยให้เปลี่ยนเป็นคีย์อื่น")
        QMessageBox.information(parent, "Shortcut", msg)

    def _release_qgis_shortcuts(self, keys):
        """ปลดคีย์เดิมของ QGIS ที่ชน ผ่าน QgsShortcutsManager (บันทึกถาวร) -> set คีย์ที่ปลดได้
        ข้าม QShortcut (คีย์ลัดของปลั๊กอินอื่น) — ปลดผ่าน manager = เขียนทับคีย์โปรไฟล์ที่อาจใช้ร่วมกันทุกตัว"""
        released = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            return released
        for key in keys:
            seq = QKeySequence(key)
            obj = None
            for getter in ("objectForSequence", "actionForSequence", "shortcutForSequence"):
                if hasattr(mgr, getter):
                    try:
                        obj = getattr(mgr, getter)(seq)
                    except Exception:
                        obj = None
                    if obj is not None:
                        break
            if obj is not None and not isinstance(obj, QShortcut):
                try:
                    if mgr.setKeySequence(obj, ""):
                        released.add(key)
                except Exception:
                    pass
        return released

    def _qgis_shortcut_keys(self):
        """คีย์ลัดที่ QGIS ใช้อยู่ (รวมคีย์รองของ action) — ไว้เตือนเมื่อตั้งคีย์ชนจน Qt ถือว่ากำกวม"""
        keys = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
            for a in mgr.listActions():
                for _q in (a.shortcuts() or [a.shortcut()]):
                    t = _q.toString()
                    if t:
                        keys.add(t)
            for sc in mgr.listShortcuts():
                if sc.property(_OWN_PROP):
                    continue
                t = sc.key().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        try:
            for a in self.iface.mainWindow().findChildren(QAction):
                for _q in (a.shortcuts() or [a.shortcut()]):
                    t = _q.toString()
                    if t:
                        keys.add(t)
        except Exception:
            pass
        return keys
