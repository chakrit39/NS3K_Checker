# -*- coding: utf-8 -*-
"""ตัวช่วยร่วมของ NS3K Checker — Log · เหตุภาษาไทย · อ่านช่องระวางจากฟีเจอร์ · zone/พิกัด · ข้อความประกอบผลค้น DOL
ยกจาก Multi-Layer Edit Pro (core/util.py) — เปลี่ยนเฉพาะที่ต้องรองรับ zone 47/48 และชื่อช่องของชั้นแปลงกรม (LAND_NO)"""
import re
from qgis.core import (Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsMessageLog, QgsProject)

LOG_TAG = "NS3K Checker"            # แท็บในแผง Log Messages
LOG_HINT = "รายละเอียดอยู่ในแผง Log Messages แท็บ NS3K Checker"
PROJ_SCOPE = "NS3KChecker"          # custom property ของโปรเจกต์ (zone / office / variant) ที่ make_ns3k_checker_projects.py เขียนไว้


# ==================== ค่าจาก provider ====================
def _txt(v):
    """ค่าข้อความจาก provider -> str · NULL/None = ว่าง (QVariant NULL ⇒ str() ได้คำว่า 'NULL')
    ตัวเลขทศนิยมที่เป็นจำนวนเต็ม (ชั้นแปลงของกรมผ่าน ArcGIS ส่ง MAP_PARCEL_SEQ/UTMSCALE เป็น double) ⇒ ไม่มี .0"""
    if v is None:
        return ""
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else str(v)
    s = str(v).strip()
    return "" if s.upper() == "NULL" else s


def _fld_idx(fields, name):
    """ตำแหน่งคอลัมน์จากชื่อ — ตรงตัวก่อน แล้วค่อยไม่สนตัวพิมพ์ · ไม่มี = -1 (ไม่ใช้ lookupField เพราะจับ alias ด้วย)"""
    i = fields.indexOf(name)
    if i >= 0:
        return i
    low = str(name).lower()
    for k in range(fields.count()):
        if fields.at(k).name().lower() == low:
            return k
    return -1


def _sheet_str(feat, *names):
    """อ่านช่อง (UTMMAP1-4 / UTMSCALE / เลขที่ดิน ...) จากฟีเจอร์เป็นสตริง trim แล้ว — ชื่อแรกที่มีค่าชนะ
    (ชั้นของ MLEP ใช้ LANDNO · ชั้นแปลงของกรม/ไฟล์ pipeline ใช้ LAND_NO)"""
    for name in names:
        try:
            i = _fld_idx(feat.fields(), name)
            if i < 0:
                continue
            s = _txt(feat[i])
            if s:
                return s
        except Exception:
            continue
    return ""


def _seq_str(v):
    """เลขแปลงในแผนที่ (MAP_SEQ / MAP_PARCEL_SEQ) -> สตริงตัวเลขล้วน · อ่านไม่ได้ = ''"""
    s = _txt(v)
    if not s:
        return ""
    try:
        f = float(s)
        if f.is_integer():
            return str(int(f))
    except ValueError:
        pass
    return s


# ==================== Log ====================
_LOG_ONCE = set()


def _log_exc(ctx, level=None, once_key=None):
    """traceback ของ exception ที่กำลังจัดการอยู่ (เรียกในบล็อก except เท่านั้น) · ตัวมันเองห้ามโยน exception"""
    try:
        if once_key is not None:
            if once_key in _LOG_ONCE:
                return
            _LOG_ONCE.add(once_key)
        import traceback
        QgsMessageLog.logMessage(f"{ctx}\n{traceback.format_exc()}", LOG_TAG, Qgis.Warning if level is None else level)
    except Exception:
        pass


def _log_err(ctx, e, level=None):
    """แบบ _log_exc แต่รับตัว exception ที่ส่งมาจาก worker thread"""
    try:
        import traceback
        if isinstance(e, BaseException):
            tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
        else:
            tb = str(e)
        QgsMessageLog.logMessage(f"{ctx}\n{tb}", LOG_TAG, Qgis.Warning if level is None else level)
    except Exception:
        pass


def _log_info(text, level=None):
    try:
        QgsMessageLog.logMessage(text, LOG_TAG, Qgis.Info if level is None else level)
    except Exception:
        pass


_TH_RE = re.compile(r"[฀-๿]")


def _reason_text(e):
    """เหตุที่แสดงให้ผู้ใช้ได้: ข้อความไทยที่ปลั๊กอินเขียนเองใช้ตามเดิม · ข้อความดิบภาษาอังกฤษ ⇒ ข้อความกลาง (ตัวจริงอยู่ใน Log)"""
    try:
        s = str(e).strip()
    except Exception:
        s = ""
    return s if s and _TH_RE.search(s) else "เกิดข้อผิดพลาดที่ไม่คาดคิด"


def _net_err_text(e):
    """exception ของงานเครือข่าย ⇒ เหตุภาษาไทยสั้น ๆ (หมดเวลา · ใบรับรอง · ต่อไม่ได้ · HTTP) · อื่น ๆ = _reason_text"""
    try:
        from . import dol_api
        r = dol_api.net_reason(e)
        if r:
            return r
    except Exception:
        pass
    if isinstance(e, TimeoutError):
        return "ระบบปลายทางตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
    if isinstance(e, ConnectionError):
        return "เชื่อมต่อเครือข่ายไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
    return _reason_text(e)


# ==================== zone / พิกัด ====================
_ZONE_RE = re.compile(r"^EPSG:(?:240|326|327)(4[78])$")


def _proj_entry(key):
    try:
        v, ok = QgsProject.instance().readEntry(PROJ_SCOPE, key, "")
        return str(v or "").strip() if ok else ""
    except Exception:
        return ""


def _zone_of(layer, geom=None):
    """UTM zone ของแปลง (47/48) สำหรับค้นระบบกรม — CRS ของชั้น (Indian 1975 / WGS 84 UTM) → ค่าที่โปรเจกต์บันทึกไว้ →
    ลองจิจูดของแปลง (zone 47 = 96°–102°E · 48 = 102°–108°E) → 47"""
    try:
        m = _ZONE_RE.match(layer.crs().authid() or "")
        if m:
            return int(m.group(1))
    except Exception:
        pass
    z = _proj_entry("zone")
    if z in ("47", "48"):
        return int(z)
    if geom is not None:
        try:
            c = geom.centroid().asPoint()
            tr = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
            return 47 if tr.transform(c).x() < 102.0 else 48
        except Exception:
            pass
    return 47


def _zone_crs(zone):
    return QgsCoordinateReferenceSystem("EPSG:%d" % (24000 + int(zone)))


def _xy_in_zone(pt, crs, zone):
    """จุด (QgsPointXY ใน crs) -> (x, y) ในพิกัดของระบบกรม EPSG:240{zone} · ทำไม่ได้ = None"""
    try:
        dst = _zone_crs(zone)
        if crs != dst:
            pt = QgsCoordinateTransform(crs, dst, QgsProject.instance()).transform(pt)
        return (pt.x(), pt.y())
    except Exception:
        return None


def _probe_xy(geom, crs, zone):
    """จุดที่อยู่ "ใน" แปลงแน่นอน (pointOnSurface — centroid ของแปลงเว้าอาจตกนอกแปลง) ใน EPSG:240{zone}
    ใช้ถาม iLands (UDM) ที่ตำแหน่งแปลงเมื่อ ArcGIS ไม่มีคีย์นี้ · ทำไม่ได้ = None"""
    try:
        return _xy_in_zone(geom.pointOnSurface().asPoint(), crs, zone)
    except Exception:
        return None


def _office_of(feat, layer=None):
    """รหัสสำนักงานที่ดินของแปลง (ล็อกการค้นให้อยู่สาขาเดียวกับแปลงที่คลิก — กันเปิดภาพลักษณ์ของสาขาอื่นเมื่อระวางคร่อมสาขา)
    ช่อง LANDOFFICE_SEQ ของแปลง (ชั้นแปลงของกรม) → ค่าที่โปรเจกต์บันทึกไว้ → None (ค้นทุกสาขาแบบเดิม)"""
    s = _sheet_str(feat, "LANDOFFICE_SEQ") if feat is not None else ""
    if s.isdigit():
        return s
    s = _proj_entry("office")
    return s if s.isdigit() else None


# ==================== ข้อความประกอบผลค้น DOL (ยกจาก MLEP ตรงตัว) ====================
def _dol_here_hint(res):
    """ข้อความบอก "ที่ตำแหน่งแปลงนี้ระบบกรมมีแปลงอะไร" (ทางสำรอง iLands เมื่อคีย์ไม่ตรง) · ไม่มี = '' · ไม่แสดงชื่อเจ้าของ"""
    here = (res or {}).get("udm_here") or {}
    if not (here.get("rawang") or here.get("land_no")):
        return ""
    if (res or {}).get("history"):
        return ""
    _bo, _ho = str((res or {}).get("branch_office") or ""), str(here.get("office_seq") or "")
    _ต่าง = " · เป็นแปลงของสำนักงานที่ดินอื่น (รหัส %s)" % _ho if (_bo and _ho and _ho != _bo) else ""
    if here.get("same_key") and _ho:
        return ("\n\nที่ตำแหน่งแปลงนี้ ระบบกรม (iLands) มีแปลงเลขเดียวกันนี้ (ระวาง %s ที่ดิน %s%s) แต่เป็นแปลงของสำนักงานที่ดินอื่น"
                " (รหัส %s) — คีย์ของแปลงนี้ไม่ได้ผิด"
                % (here.get("rawang") or "-", here.get("land_no") or "-",
                   (" (%s)" % here["parcel_type"]) if here.get("parcel_type") else "", _ho))
    return ("\n\nที่ตำแหน่งแปลงนี้ ระบบกรม (iLands) มีแปลง ระวาง %s ที่ดิน %s%s%s — ถ้าเป็นแปลงเดียวกัน คีย์ของแปลงนี้อาจผิด"
            % (here.get("rawang") or "-", here.get("land_no") or "-",
               (" (%s)" % here["parcel_type"]) if here.get("parcel_type") else "", _ต่าง))


def _dol_more_hint(res, skip_other=False):
    """ข้อความเพิ่มเมื่อหาไม่เจอ: เลขถูกยกเลิก (ชั้นประวัติ) · รอจด (ชั้นชั่วคราว) · ผลของทะเบียน iLands"""
    res = res or {}
    out = []
    oo = res.get("other_office") or {}
    if oo.get("office_seq") and not skip_other:
        out.append("\n\nℹ️ ระวาง/เลขที่ดินนี้มีบนแผนที่กรมของสำนักงานที่ดินอื่น (รหัส %s) — ปลั๊กอินค้นเฉพาะแปลงของสาขาเดียวกับแปลงที่คลิก"
                   % oo["office_seq"])
    if res.get("history"):
        now = (res.get("history") or {}).get("now") or {}
        s = ("\n\nℹ️ เลขที่ดินนี้มีในประวัติแผนที่กรมด้วย (แผนที่ปัจจุบันยังมีเลขนี้ — สรุปไม่ได้ว่าถูกยกเลิก)"
             if res.get("arc_miss") else "\n\nℹ️ เลขที่ดินนี้ถูกยกเลิกแล้ว (มีในประวัติแผนที่กรม)")
        if now.get("rawang") or now.get("land_no"):
            s += (" — ตำแหน่งตามประวัติ ตอนนี้เป็นแปลง ระวาง %s ที่ดิน %s%s" if res.get("arc_miss")
                  else " — ตอนนี้ที่ตำแหน่งเดิมเป็นแปลง ระวาง %s ที่ดิน %s%s") % (
                now.get("rawang") or "-", now.get("land_no") or "-",
                (" (%s)" % now["parcel_type"]) if now.get("parcel_type") else "")
        here = res.get("udm_here") or {}
        if (here.get("rawang") or here.get("land_no")) and \
                (str(here.get("rawang") or "").strip(), str(here.get("land_no") or "").strip()) != \
                (str(now.get("rawang") or "").strip(), str(now.get("land_no") or "").strip()):
            s += " · ที่ตำแหน่งแปลงนี้เป็นแปลง ระวาง %s ที่ดิน %s%s" % (
                here.get("rawang") or "-", here.get("land_no") or "-",
                (" (%s)" % here["parcel_type"]) if here.get("parcel_type") else "")
            _bo, _ho = str(res.get("branch_office") or "").strip(), str(here.get("office_seq") or "").strip()
            if _bo and _ho and _ho != _bo:
                s += " ของสำนักงานที่ดินอื่น (รหัส %s)" % _ho
        out.append(s)
    if res.get("temp"):
        out.append("\n\nℹ️ พบในชั้นแปลงรอจดทะเบียนของกรม — ยังไม่มีข้อมูลทะเบียน")
    if res.get("lis") == "none":
        out.append("\n\nทะเบียนของ iLands ก็ไม่มีเลขนี้")
    elif res.get("lis") == "error":
        out.append("\n\nค้นในทะเบียน iLands ไม่สำเร็จ: %s" % (res.get("lis_error") or "-"))
    return "".join(out)


def _dol_via_note(res):
    """ที่มาของผลที่ไม่ได้มาจากแผนที่ปัจจุบันของกรม (ต่อท้ายแถบข้อความ)"""
    if not (res or {}).get("via") and (res or {}).get("verify_by") == "key":
        return "ยืนยันด้วยระวาง+เลขที่ดิน (เลขแปลงในแผนที่ของระบบกรมไม่ตรงกัน)"
    if (res or {}).get("via") == "udm_point" and (res or {}).get("arc_miss"):
        return ("พบจาก iLands ที่ตำแหน่งแปลง (แผนที่ ArcGIS ของกรมมีคีย์นี้ แต่"
                + ("ไม่มีข้อมูลทะเบียนที่จุดกลางของแปลง)" if res.get("arc_miss") == "udm_empty" else "ไม่มีพิกัดจุดกลางของแปลง)"))
    return {"udm_point": "พบจาก iLands ที่ตำแหน่งแปลง (แผนที่ ArcGIS ของกรมไม่มีคีย์นี้)",
            "arcgis_temp": "พบจากชั้นแปลงรอจดทะเบียนของกรม",
            "arcgis_history": "พบจากชั้นประวัติของแผนที่กรม (ตำแหน่งเดิมยังเป็นเลขนี้)",
            "lis": "พบในทะเบียน iLands — แปลงนี้ไม่มีรูปบนแผนที่กรม"}.get((res or {}).get("via"), "")
