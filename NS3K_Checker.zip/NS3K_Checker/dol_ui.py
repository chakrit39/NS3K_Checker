# -*- coding: utf-8 -*-
"""ค้นภาพลักษณ์ / หลักฐานการรังวัดจากระบบกรมที่ดิน (DOL iLands) — คลิกแปลงในชั้น UTM
ยกจาก Multi-Layer Edit Pro 2.4.1 (features/dol.py) — ต่างเฉพาะ: zone 47/48 ตามชั้นข้อมูล · ล็อกสาขาจาก LANDOFFICE_SEQ ของแปลง ·
หลักฐานการรังวัดใช้ตารางรหัสจังหวัดครบทุกจังหวัด (dol_api.PROVINCE_CODE) แทนตารางที่ต้องเติมทีละจังหวัด"""
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsGeometry, QgsMessageLog, QgsWkbTypes
from qgis.gui import QgsRubberBand
from .map_tools import PickTool
from .util import (LOG_HINT, LOG_TAG, _dol_here_hint, _dol_more_hint, _dol_via_note, _log_err, _log_exc,
                   _net_err_text, _office_of, _probe_xy, _sheet_str, _txt, _xy_in_zone, _zone_of)


class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)"""
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone):
        super().__init__()
        self.attrs = attrs
        self.zone = zone

    def run(self):
        from . import dol_api
        try:
            a = self.attrs
            res = dol_api.lookup_parcel_by_rawang(
                a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                zone=self.zone, near_xy=a.get("near_xy"), probe_xy=a.get("probe_xy"), office_seq=a.get("office_seq"))
            self.done.emit(res)
        except Exception as e:
            if not isinstance(e, dol_api.DOLError):
                _log_exc("ค้นแปลงจากระบบกรม (ระวาง → PARCEL_SEQ) ล้ม")
            elif getattr(e, "detail", ""):
                try:
                    QgsMessageLog.logMessage("ค้นแปลงจากระบบกรม (ระวาง → PARCEL_SEQ) ไม่สำเร็จ: %s — คำตอบจากระบบกรม: %s"
                                             % (e, str(e.detail)[:2000]), LOG_TAG, Qgis.Warning)
                except Exception:
                    pass
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {_net_err_text(e)}")


class DolMixin:
    """ค้นภาพลักษณ์/หลักฐานรังวัดจากระบบกรมที่ดิน — คลาสที่สืบทอดต้องมี: iface · dlg · _alive · _net_workers ·
    _sel_utm() · _ask() · _run_net() · _set_status()"""

    # ============ เริ่มเครื่องมือ: คลิกแปลงในชั้น UTM ============
    def start_dol_search(self, mode='image'):
        """mode 'image' = ภาพลักษณ์ (public) · 'survey' = หลักฐานรังวัด (ต้องเข้าสู่ระบบกรม)"""
        if self._dol_refuse_if_busy():          # ด่าน "กำลังค้นอยู่" ต้องมาก่อนแตะสถานะใด ๆ
            return
        lyr = self._sel_utm()
        if lyr is None:
            self._ask(QtWidgets.QMessageBox.Warning, "ไม่พบชั้น UTM",
                      "ไม่พบชั้นแปลงโฉนด (ชั้น UTM) ที่มีช่อง UTMMAP1–4 / UTMSCALE / เลขที่ดิน\n"
                      "เลือกชั้นที่ช่อง \"UTM\" ในหน้าต่าง NS3K Checker ก่อน")
            return
        if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
            return
        self._dol_mode = mode
        self._dol_clear_highlight()
        self.tool = PickTool(self.iface, lyr, self._on_polygon_picked, self._dol_on_hover, self._net_workers)
        self.iface.mapCanvas().setMapTool(self.tool)
        what = "ภาพลักษณ์" if mode == 'image' else "หลักฐานการรังวัด"
        self.tool.push_hint(f"คลิกบนแปลงในชั้น '{lyr.name()}' เพื่อค้นหา{what} (Esc เพื่อยกเลิก)")
        self._set_status(f"{'🔍' if mode == 'image' else '📐'} คลิกแปลงในชั้น '{lyr.name()}' เพื่อค้นหา{what}")

    def _on_polygon_picked(self, feat, layer):
        """อ่านช่องระวางของแปลงที่คลิก แล้วยิงค้นหา (ใน thread แยก)"""
        def gv(*names):
            return _sheet_str(feat, *names)
        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO", "LAND_NO")
        self.iface.actionSelect().trigger()     # คืน cursor ปกติ
        if self._dol_refuse_if_busy():
            return
        req = self._dol_new_req(getattr(self, "_dol_mode", "image"), None)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass
        req["rb"] = getattr(self, "_dol_highlight", None)
        if not m1 or not m2 or not m3 or not scale or not landno or landno in ("0", "-1"):
            try:
                self._ask(QtWidgets.QMessageBox.Warning, "ข้อมูลแปลงไม่ครบ",
                          "แปลงนี้ไม่มีช่องระวาง/เลขที่ดินครบ (หรือเลขที่ดินเป็น 0) — ค้นจากระบบกรมไม่ได้\n"
                          f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | เลขที่ดิน={landno or '-'}")
            finally:
                self._dol_end(req)
            return
        zone = _zone_of(layer, feat.geometry())
        near_xy = None
        try:
            near_xy = _xy_in_zone(feat.geometry().centroid().asPoint(), layer.crs(), zone)
        except Exception:
            near_xy = None
        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4, "scale": scale, "landno": landno, "zone": zone,
                 "near_xy": near_xy, "probe_xy": _probe_xy(feat.geometry(), layer.crs(), zone),
                 "office_seq": _office_of(feat, layer)}
        self._dol_attrs = attrs
        req["attrs"] = attrs
        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno} (zone {zone})",
            None, 0, 0, self.dlg if self.dlg is not None else self.iface.mainWindow())
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_wait_arm(self._dol_busy, req, own=True)
        self._dol_busy.show()
        self._set_status(f"กำลังค้นหา... ระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}")
        # worker ทุกตัว (รวมตัวที่ถูกกดยกเลิก) ถูกถือไว้ใน _net_workers จนถึง finished — ห้ามให้ QThread ที่ยังวิ่งเหลือ ref 0
        w = ParcelLookupWorker(attrs, zone)
        self._dol_worker = w
        self._net_workers.append(w)

        def _drop_worker(_w=w):
            try:
                self._net_workers.remove(_w)
            except Exception:
                pass
            try:
                _w.deleteLater()
            except Exception:
                pass
        w.finished.connect(_drop_worker)
        w.done.connect(lambda res, _r=req: self._on_dol_done(res, _r))
        w.fail.connect(lambda msg, _r=req: self._on_dol_fail(msg, _r))
        w.start()

    def _on_dol_done(self, res, req=None):
        req = self._dol_result_req(req)
        if req is None:
            return
        _cont = False
        try:
            _cont = bool(self._dol_show_result(res, req))
        finally:
            if not _cont:
                self._dol_end(req)

    def _dol_show_result(self, res, req):
        """แสดง/เปิดผลค้น PARCEL_SEQ ตามโหมดของคำขอ · คืน True = flow ยังไม่จบ (ไปขั้นหลักฐานรังวัด / ทะเบียน iLands)"""
        a = req.get("attrs") or {}
        ระวาง = self._dol_rawang_text(a)
        if isinstance(res, dict) and res.get("not_found"):
            if res.get("lis") == "login" and not req.get("lis_tried") and self._dol_offer_lis(res, req, ระวาง):
                return True
            self._set_status(f"ไม่พบเอกสารของแปลง ระวาง {ระวาง}")
            มีระวาง = res.get("sheet_exists")
            n = res.get("sheet_land_count")
            bo = str(res.get("branch_office") or a.get("office_seq") or "").strip()
            oo = str((res.get("other_office") or {}).get("office_seq") or "").strip()
            ที่นี่ = _dol_here_hint(res) + _dol_more_hint(res, skip_other=bool(oo))
            if oo:
                self._ask(QtWidgets.QMessageBox.Information, "เป็นแปลงของสำนักงานที่ดินอื่น",
                          "ระวาง/เลขที่ดินนี้ไม่มีในสำนักงานที่ดินเดียวกับแปลงที่คลิก" + (f" (รหัส {bo})" if bo else "") + "\n"
                          f"แต่บนแผนที่กรมเป็นแปลงของสำนักงานที่ดินอื่น (รหัส {oo})\nระวาง {ระวาง}\n\n"
                          "ปลั๊กอินค้นเฉพาะแปลงของสาขาเดียวกับแปลงที่คลิก จึงไม่เปิดเอกสารของสำนักงานอื่น" + ที่นี่)
            elif res.get("arc_miss"):
                self._ask(QtWidgets.QMessageBox.Information, "ระบบทะเบียนไม่มีข้อมูลแปลงนี้",
                          f"แผนที่ของกรม (ArcGIS) มีระวาง/เลขที่ดินนี้{'ของสาขานี้' if bo else ''} แต่"
                          + ("ระบบทะเบียน (iLands) ไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น" if res.get("arc_miss") == "udm_empty"
                             else "ไม่มีพิกัดจุดกลางของแปลง จึงถามระบบทะเบียน (iLands) ไม่ได้")
                          + f"\nระวาง {ระวาง}\n\n"
                          "สาเหตุที่เป็นไปได้: ข้อมูลแผนที่กับทะเบียนของกรมยังไม่ตรงกัน หรือแปลงถูกแบ่งแยก/ยกเลิกแล้วแต่แผนที่ยังไม่อัปเดต\n"
                          "จึงเปิดภาพลักษณ์/หลักฐานการรังวัดจากปลั๊กอินไม่ได้" + ที่นี่)
            elif มีระวาง is True:
                self._ask(QtWidgets.QMessageBox.Information, "แปลงไม่มีทะเบียน",
                          f"แปลงนี้ไม่มีทะเบียนในระบบของกรมที่ดิน (DOL)\nระวาง {ระวาง}\n\n"
                          f"ระวางนี้มีอยู่ในระบบ (มีที่ดิน{'ของสาขานี้' if bo else ''} {n:,} เลข) แต่ไม่มีเลขที่ดินนี้\n"
                          "จึงเปิดภาพลักษณ์/หลักฐานการรังวัดจากปลั๊กอินไม่ได้" + ที่นี่)
            elif มีระวาง is False:
                self._ask(QtWidgets.QMessageBox.Information, "ไม่พบระวางในสาขานี้" if bo else "ไม่พบระวาง",
                          ("ระวางนี้ไม่มีแปลงของสำนักงานที่ดินของสาขานี้\n" if bo else "ระบบกรมที่ดิน (DOL) ไม่มีระวางนี้เลย\n")
                          + f"ระวาง {ระวาง}\n\nตรวจเลขระวาง / มาตราส่วน / zone UTM ของแปลงนี้อีกครั้ง" + ที่นี่)
            else:
                self._ask(QtWidgets.QMessageBox.Information, "ไม่พบแปลง",
                          f"ไม่พบแปลง{'ของสาขานี้' if bo else ''}ในระบบ DOL\nระวาง {ระวาง}\n\n"
                          "ตรวจสอบสาเหตุเพิ่มไม่ได้ (ต่อระบบ DOL ไม่ได้ชั่วคราว)" + ที่นี่)
            return
        if not res:
            self._set_status(f"ไม่พบแปลงในระบบ DOL · ระวาง {ระวาง}")
            self._ask(QtWidgets.QMessageBox.Information, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return
        if res.get("not_registered"):
            what = "หลักฐานการรังวัด" if req.get("mode") == "survey" else "ภาพลักษณ์"
            if res.get("via") == "arcgis_temp":
                self._set_status(f"ℹ แปลงรอจดทะเบียน (รังวัดแล้ว ยังไม่จดทะเบียน) — ยังไม่มี{what} · ระวาง {ระวาง}")
                self._ask(QtWidgets.QMessageBox.Information, "แปลงรอจดทะเบียน",
                          "แปลงนี้อยู่ในชั้นแปลงรอจดทะเบียนของกรมที่ดิน (รังวัดแล้ว ยังไม่จดทะเบียน)\n"
                          f"จึงยังค้นหา{what}จากปลั๊กอินไม่ได้\n\n"
                          f"ระวาง {res.get('rawang') or ''} • ที่ดิน {res.get('land_no') or ''}\n{res.get('office') or ''}")
                return
            self._set_status(f"ℹ แปลงไม่มีทะเบียนในระบบกรม — ค้น{what}ไม่ได้ · ระวาง {ระวาง}")
            self._ask(QtWidgets.QMessageBox.Information, "แปลงไม่มีทะเบียน",
                      f"แปลงนี้ไม่มีทะเบียนในระบบของกรมที่ดิน (DOL)\nจึงค้นหา{what}จากปลั๊กอินไม่ได้\n\n"
                      f"ระวาง {res.get('rawang') or ''} • ที่ดิน {res.get('land_no') or ''}\n{res.get('office') or ''}")
            return
        if req.get("mode") == "survey":
            self._open_survey(res, req)
            return True
        # ภาพลักษณ์ -> เปิดทันทีเฉพาะผลที่ยืนยันได้ว่าเป็นแปลงที่คลิก · ยืนยันไม่ได้ ⇒ ถามก่อน (ปุ่มตั้งต้น "ไม่")
        n_match = res.get("match_count") or 1
        near = a.get("near_xy") is not None
        locked = bool(res.get("branch_office") or a.get("office_seq"))
        lis_many = res.get("via") == "lis"
        sure = bool(res.get("verified")) and (n_match <= 1 or (near and not lis_many))
        if not sure:
            why = ("ระบบกรมตอบข้อมูลที่ยืนยันไม่ได้ว่าเป็นแปลงที่คลิก (เลขแปลงในแผนที่ของระบบไม่ตรงกัน)"
                   if not res.get("verified") else
                   f"ทะเบียนของ iLands มีเลขนี้ {n_match} รายการ (ทะเบียนไม่มีพิกัด จึงเลือกรายการที่ตรงกับแปลงที่คลิกไม่ได้)"
                   if lis_many else
                   f"ระวางนี้มีเลขที่ดินนี้ {n_match} แปลงในสาขานี้ และหาตำแหน่งแปลงที่คลิกไม่ได้" if locked else
                   f"ระวางนี้มีเลขที่ดินนี้ {n_match} แปลง (คร่อมสาขา) และหาตำแหน่งแปลงที่คลิกไม่ได้")
            ans = self._ask(QtWidgets.QMessageBox.Warning, "ยืนยันแปลงไม่ได้",
                            f"{why}\nภาพลักษณ์ที่จะเปิดอาจเป็นของแปลงอื่น\n\n"
                            f"แปลงที่คลิก: ระวาง {ระวาง}\n"
                            f"ระบบกรมตอบ: โฉนด {res.get('parcel_no') or '-'} • ระวาง {res.get('rawang') or '-'} • "
                            f"ที่ดิน {res.get('land_no') or '-'} • {res.get('office') or ''}\n\nเปิดภาพลักษณ์นี้หรือไม่?",
                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                self.iface.messageBar().pushMessage(
                    "DOL", f"ไม่ได้เปิดภาพลักษณ์ — ยืนยันไม่ได้ว่าเป็นแปลงที่คลิก (ระวาง {ระวาง})", level=1, duration=8)
                return
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ ยืนยันไม่ได้ว่าเป็นแปลงที่คลิก"
        if _dol_via_note(res):
            warn += "  ℹ️ " + _dol_via_note(res)
        if n_match > 1:
            _ที่ = "(เลือกใกล้จุดคลิกสุด)" if near else "(หาตำแหน่งแปลงที่คลิกไม่ได้ — ใช้รายการแรกที่ระบบตอบ)"
            if lis_many:
                warn += f"  🔀 ทะเบียนของ iLands มีเลขนี้ {n_match} รายการ (ใช้รายการแรก)"
            elif locked:
                warn += f"  🔀 พบเลขนี้ {n_match} แปลงในสาขานี้ " + _ที่
            else:
                warn += f"  🔀 ระวางคร่อม {n_match} สาขา " + _ที่
        self.iface.messageBar().pushMessage(
            "DOL", f"โฉนด {res.get('parcel_no')} | {res.get('office', '')} ({res.get('city', '')}) — "
                   f"เปิดภาพลักษณ์แล้ว (ระวาง {ระวาง}){warn}", level=3 if sure else 1, duration=8)
        self._set_status(f"🔍 เปิดภาพลักษณ์: โฉนด {res.get('parcel_no')} เลขที่ดิน {res.get('land_no')}\n"
                         f"{res.get('office', '')} · {res.get('city', '')}")

    # ---------- หลักฐานการรังวัด (ต้อง login) ----------
    def _dol_ask_credentials(self, user="", err=""):
        """popup ขอ user/pass (UI อย่างเดียว — network ไปทำใน thread แยก) -> (user, pass) หรือ None
        ไม่เก็บรหัสผ่าน (ชื่อผู้ใช้จำไว้ในหน่วยความจำของปลั๊กอินเท่านั้น)"""
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("เข้าสู่ระบบ DOL iLands")
        dlg.setMinimumWidth(320)
        form = QtWidgets.QFormLayout(dlg)
        if err:
            _lbl_err = QtWidgets.QLabel(str(err))
            _lbl_err.setWordWrap(True)
            _lbl_err.setStyleSheet("color:#c62828;")
            form.addRow(_lbl_err)
        ed_user = QtWidgets.QLineEdit()
        if user:
            ed_user.setText(str(user))
        ed_pass = QtWidgets.QLineEdit()
        ed_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        form.addRow("ผู้ใช้:", ed_user)
        form.addRow("รหัสผ่าน:", ed_pass)
        note = QtWidgets.QLabel("🔒 ไม่เก็บรหัสถาวร — ปิด QGIS แล้วต้องเข้าสู่ระบบใหม่")
        note.setStyleSheet("color:#666; font-size:11px;")
        form.addRow(note)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        form.addRow(bb)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        _okb = bb.button(QtWidgets.QDialogButtonBox.Ok)

        def _can_ok(*_a):
            _okb.setEnabled(bool(ed_user.text().strip()) and bool(ed_pass.text()))
        ed_user.textChanged.connect(_can_ok)
        ed_pass.textChanged.connect(_can_ok)
        _can_ok()
        (ed_pass if ed_user.text().strip() else ed_user).setFocus()
        _ok = dlg.exec_() == QtWidgets.QDialog.Accepted
        u, p = ed_user.text().strip(), ed_pass.text()
        ed_pass.clear()
        dlg.deleteLater()
        if not _ok or not u or not p:
            return None
        return (u, p)

    # ช่องของรายการหลักฐานรังวัดที่ servlet ส่งมาจริง (วัดจากระบบ 19 ต.ค. 69) -> ป้ายภาษาไทย · ช่องชื่อแบบ MLEP เผื่อระบบรุ่นอื่น
    _CAD_FIELDS = (("TYPEOFSURVEY_NAME", "ประเภท"), ("SURVEY_TH_DATE", "วันที่รังวัด"), ("CADASTRAL_NO", "เลขที่"),
                   ("CADASTRAL_LAND_NO", "ที่ดิน"), ("SHEETCODE", "ระวาง"), ("SHEETNO", "แผ่น"),
                   ("TYPEOFSURVEY", "ประเภท"), ("TYPE_OF_SURVEY", "ประเภท"), ("SURVEY_DATE", "วันที่รังวัด"),
                   ("SURVEY_NO", "เลขที่รังวัด"), ("SURVEYNO", "เลขที่รังวัด"))

    def _cadastral_label(self, rec, i):
        parts, used = [], set()
        for k, label in self._CAD_FIELDS:
            v = rec.get(k)
            if v not in (None, "", "null") and label not in used:
                parts.append(f"{label} {v}")
                used.add(label)
        text = " | ".join(parts) if parts else "(ไม่มีรายละเอียด)"
        return f"{i + 1}. {text}  [seq {rec.get('CADASTRAL_SEQ')}]"

    def _choose_cadastral(self, recs):
        items = [self._cadastral_label(rec, i) for i, rec in enumerate(recs)]
        item, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "เลือกหลักฐานการรังวัด",
            f"แปลงนี้มี {len(recs)} รายการ — เลือกที่ต้องการเปิด:", items, 0, False)
        if not ok:
            return None
        return recs[items.index(item)]

    def _open_survey(self, res, req):
        """ค้นหลักฐานรังวัดจากแปลงที่คลิก (login ถ้าจำเป็น) แล้วเปิด viewer; หลายรายการ -> ให้เลือก"""
        from . import dol_api
        attrs = req.get("attrs") or {}
        office = _txt(res.get("office_seq"))
        name, _cands, _ok = dol_api.province_code_candidates(res.get("city", ""))
        stop = ""
        if not name:
            stop = (f"ไม่รู้จังหวัดของแปลงนี้ ({res.get('city') or 'ระบบ DOL ไม่ส่งชื่อจังหวัดมา'}) — "
                    "ค้นหลักฐานการรังวัดจากปลั๊กอินไม่ได้")
        elif not office:
            stop = ("ระบบ DOL ไม่ส่งรหัสสำนักงานของแปลงนี้มา — ค้นหลักฐานการรังวัดจากปลั๊กอินไม่ได้\n"
                    f"(ระวาง {self._dol_rawang_text(attrs)} • {res.get('office') or ''} {res.get('city') or ''})")
        else:
            try:
                dol_api.scale_code(attrs.get("scale"))
            except dol_api.DOLError as e:
                stop = f"{e}\n(ระวาง {self._dol_rawang_text(attrs)})"
        if stop:
            try:
                self._ask(QtWidgets.QMessageBox.Warning, "หลักฐานการรังวัด", stop)
            finally:
                self._dol_end(req)
            return
        req.update(city=res.get("city", ""), office=office, verified=bool(res.get("verified", True)))
        self._survey_step(req)

    def _survey_step(self, ctx):
        """ขั้น login: ยังไม่ login -> ขอรหัส (UI) แล้ว login ใน thread แยก จากนั้นค่อยค้นหา · ยกเลิก = จบ flow"""
        from . import dol_api
        if dol_api.is_logged_in():
            self._survey_search(ctx)
            return
        creds = self._dol_ask_credentials(user=getattr(self, "_dol_user", "") or "", err=ctx.pop("login_err", ""))
        if not creds:
            self._dol_end(ctx)
            return
        u, p = creds
        self._dol_user = u
        ctx["tries"] = ctx.get("tries", 0) + 1
        self._run_net("กำลังเข้าสู่ระบบ DOL...", lambda: dol_api.login(u, p),
                      lambda _s, c=ctx: self._survey_search(c),
                      lambda e, c=ctx: self._survey_login_failed(e, c), req=ctx)

    def _survey_login_failed(self, e, ctx):
        from . import dol_api
        tries = ctx.get("tries", 0)
        if isinstance(e, dol_api.DOLAuthError) and getattr(e, "ask_again", False) and tries < 3:
            ctx["login_err"] = f"{e}\n(ลองแล้ว {tries} จาก 3 ครั้ง)"
            self._survey_step(ctx)
            return
        try:
            if isinstance(e, dol_api.DOLAuthError):
                more = ("\n\nลองครบ 3 ครั้งแล้ว — เริ่มใหม่ได้ที่ปุ่ม 📐 หลักฐานการรังวัด"
                        if getattr(e, "ask_again", False) else "")
                if not getattr(e, "ask_again", False):
                    _log_err("DOL: เข้าสู่ระบบไม่สำเร็จ", e)
                self._ask(QtWidgets.QMessageBox.Warning, "เข้าสู่ระบบไม่สำเร็จ", str(e) + more)
            else:
                _log_err("DOL: เข้าสู่ระบบผิดพลาด", e, Qgis.Critical)
                self._ask(QtWidgets.QMessageBox.Critical, "เข้าสู่ระบบผิดพลาด",
                          f"เข้าสู่ระบบ DOL ไม่สำเร็จ — {_net_err_text(e)}\nลองใหม่อีกครั้ง ({LOG_HINT})")
        finally:
            self._dol_end(ctx)

    def _survey_search(self, ctx):
        from . import dol_api
        a = ctx["attrs"]
        self._run_net(
            "กำลังค้นหาหลักฐานการรังวัด...",
            lambda: dol_api.search_cadastral_any(
                a.get("m1"), a.get("m2"), a.get("m3"), a.get("m4"), a.get("scale"), a.get("landno"),
                ctx.get("city"), ctx["office"], zone=a.get("zone", 47)),
            lambda out, c=ctx: self._survey_show(out, c),
            lambda e, c=ctx: self._survey_failed(e, c), req=ctx)

    def _survey_failed(self, e, ctx):
        from . import dol_api
        if isinstance(e, dol_api.DOLAuthError):
            dol_api.logout()
            if getattr(e, "ask_again", False) and ctx.get("tries", 0) < 3:
                ctx["login_err"] = str(e)
                self._survey_step(ctx)
                return
        try:
            if isinstance(e, dol_api.DOLAuthError):
                more = ("\n\nลองครบ 3 ครั้งแล้ว — เริ่มใหม่ได้ที่ปุ่ม 📐 หลักฐานการรังวัด"
                        if getattr(e, "ask_again", False) else "")
                self._ask(QtWidgets.QMessageBox.Warning, "หลักฐานการรังวัด", str(e) + more)
            else:
                _d = getattr(e, "detail", "")
                if _d:
                    QgsMessageLog.logMessage(f"ค้นหลักฐานการรังวัดไม่สำเร็จ: {e} — คำตอบจากระบบกรม: {str(_d)[:2000]}",
                                             LOG_TAG, Qgis.Warning)
                elif not isinstance(e, dol_api.DOLError):
                    _log_err("ค้นหลักฐานการรังวัดไม่สำเร็จ", e, Qgis.Critical)
                self._ask(QtWidgets.QMessageBox.Critical, "ค้นหารังวัดผิดพลาด",
                          f"{_net_err_text(e)}\n(ค้นด้วยระวาง {self._dol_rawang_text(ctx.get('attrs'))} • สนง.{ctx.get('office')})")
        finally:
            self._dol_end(ctx)

    def _survey_show(self, out, ctx):
        from . import dol_api
        a = ctx.get("attrs") or {}
        recs = (out or {}).get("recs") or []
        try:
            if not recs:
                self._ask(QtWidgets.QMessageBox.Information, "ไม่พบหลักฐานการรังวัด",
                          "ไม่พบหลักฐานการรังวัดของแปลงนี้\n"
                          f"(ค้นด้วยระวาง {self._dol_rawang_text(a)} • สนง.{ctx.get('office')})"
                          + ("" if ctx.get("verified", True) else
                             "\n⚠️ รหัสสำนักงานมาจากผลค้นที่ระบบกรมยืนยันไม่ได้ว่าเป็นแปลงนี้"))
                self._set_status("ไม่พบหลักฐานการรังวัดของแปลงนี้")
                return
            rec = recs[0] if len(recs) == 1 else self._choose_cadastral(recs)
            if rec is None:
                return
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(dol_api.survey_doc_url(rec.get("CADASTRAL_SEQ"), "1")))
            self.iface.messageBar().pushMessage(
                "DOL", f"เปิดหลักฐานการรังวัด (พบ {len(recs)} รายการ) — CADASTRAL_SEQ {rec.get('CADASTRAL_SEQ')} · "
                       f"ระวาง {self._dol_rawang_text(a)}", level=3, duration=8)
            self._set_status(f"📐 เปิดหลักฐานการรังวัด (พบ {len(recs)} รายการ) · ระวาง {self._dol_rawang_text(a)}")
        finally:
            self._dol_end(ctx)

    # ---------- ทางสุดท้าย: ค้นทะเบียน iLands ด้วยคีย์ (หน้า LIS · ต้อง login · ช้า) ----------
    def _dol_offer_lis(self, res, req, ระวาง):
        """แผนที่กรมทุกชั้นไม่มีคีย์นี้ + ยังไม่ได้เข้าสู่ระบบ ⇒ ถามว่าจะค้นต่อในทะเบียน iLands ไหม · True = ไปต่อ"""
        bo = str((res or {}).get("branch_office") or ((req or {}).get("attrs") or {}).get("office_seq") or "").strip()
        oo = str(((res or {}).get("other_office") or {}).get("office_seq") or "").strip()
        head = "แผนที่ของกรมไม่มีแปลงของสาขานี้ตามระวาง/เลขที่ดินนี้" if bo else "แผนที่ของกรมไม่มีแปลงตามระวาง/เลขที่ดินนี้"
        if (res or {}).get("arc_miss"):
            head = ("แผนที่ของกรมมีระวาง/เลขที่ดินนี้ แต่ระบบทะเบียนไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น"
                    if res.get("arc_miss") == "udm_empty" else "แผนที่ของกรมมีระวาง/เลขที่ดินนี้ แต่ไม่มีพิกัดจุดกลางของแปลง")
        if oo:
            head += f"\n(บนแผนที่กรม เลขนี้เป็นแปลงของสำนักงานที่ดินอื่น รหัส {oo})"
        ans = self._ask(QtWidgets.QMessageBox.Question, "ค้นในทะเบียน iLands",
                        f"{head}\nระวาง {ระวาง}\n\n"
                        "บางแปลงมีทะเบียนแต่ยังไม่มีรูปบนแผนที่กรม — ค้นต่อในทะเบียนของ iLands"
                        + (" (เฉพาะสำนักงานที่ดินของสาขานี้)" if bo else "") + " ไหม?\n"
                        "(ต้องเข้าสู่ระบบด้วยบัญชีกรมที่ดิน · ใช้เวลาราว 5–10 วินาที)",
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.Yes)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        req["lis_tried"] = True
        req["lis_base"] = res
        self._dol_lis_step(req)
        return True

    def _dol_lis_step(self, req):
        from . import dol_api
        if dol_api.is_logged_in():
            self._dol_lis_search(req)
            return
        creds = self._dol_ask_credentials(user=getattr(self, "_dol_user", "") or "", err=req.pop("login_err", ""))
        if not creds:
            self._dol_lis_done(dict(req.get("lis_base") or {"not_found": True}, lis=None), req, final=True)
            return
        u, p = creds
        self._dol_user = u
        req["tries"] = req.get("tries", 0) + 1
        self._run_net("กำลังเข้าสู่ระบบ DOL...", lambda: dol_api.login(u, p),
                      lambda _s, r=req: self._dol_step_done(r) and self._dol_lis_search(r),
                      lambda e, r=req: self._dol_lis_failed(e, r), req=req)

    def _dol_lis_search(self, req):
        from . import dol_api
        a = req.get("attrs") or {}
        here = (req.get("lis_base") or {}).get("udm_here")
        self._run_net("กำลังค้นในทะเบียน iLands... (ทางสุดท้าย ใช้เวลาสักครู่)",
                      lambda: dol_api.lookup_parcel_lis(a.get("m1"), a.get("m2"), a.get("m3"), a.get("m4"),
                                                        a.get("scale"), a.get("landno"), zone=a.get("zone", 47),
                                                        near_xy=a.get("near_xy"), here=here,
                                                        office_seq=a.get("office_seq")),
                      lambda r, q=req: self._dol_step_done(q) and self._dol_lis_done(r, q),
                      lambda e, q=req: self._dol_lis_failed(e, q), req=req)

    def _dol_lis_failed(self, e, req):
        from . import dol_api
        if not self._dol_step_done(req):
            return
        if isinstance(e, dol_api.DOLAuthError) and getattr(e, "ask_again", False) and req.get("tries", 0) < 3:
            dol_api.logout()
            req["login_err"] = f"{e}\n(ลองแล้ว {req.get('tries', 0)} จาก 3 ครั้ง)"
            self._dol_lis_step(req)
            return
        _log_err("DOL: ค้นในทะเบียน iLands ไม่สำเร็จ", e)
        base = dict(req.get("lis_base") or {"not_found": True})
        base["lis"], base["lis_error"] = "error", (str(e) if isinstance(e, dol_api.DOLError) else _net_err_text(e))
        self._dol_lis_done(base, req, final=True)

    def _dol_lis_done(self, r, req, final=False):
        if final or not isinstance(r, dict) or not r.get("not_found"):
            res = r
        else:
            res = dict(req.get("lis_base") or {"not_found": True}, lis="none")
        _cont = False
        try:
            _cont = bool(self._dol_show_result(res, req))
        finally:
            if not _cont:
                self._dol_end(req)
        return _cont

    def _on_dol_fail(self, msg, req=None):
        req = self._dol_result_req(req)
        if req is None:
            return
        try:
            self._ask(QtWidgets.QMessageBox.Critical, "DOL ผิดพลาด", msg)
            self._set_status("⚠ " + msg)
        finally:
            self._dol_end(req)

    # ---------- คำขอ DOL หนึ่งครั้ง = บริบทที่ผูกกับผลของมันเอง (ผลที่มาช้าห้ามถูกตีความด้วยแปลง/โหมดของคำขอใหม่) ----------
    #   req = {seq, mode, attrs, wait, abandoned, ended, tries, rb (ไฮไลต์), busy/dlg (กล่องรอ), city/office/verified}
    def _dol_new_req(self, mode, attrs):
        self._dol_seq = getattr(self, "_dol_seq", 0) + 1
        req = {"seq": self._dol_seq, "mode": mode or "image", "attrs": attrs if attrs is not None else {}, "wait": False,
               "abandoned": False, "ended": False, "tries": 0}
        self._dol_req = req
        return req

    def _dol_live(self, req):
        return bool(req) and not req.get("abandoned") and not req.get("ended") \
            and req is getattr(self, "_dol_req", None)

    def _dol_busy_now(self):
        req = getattr(self, "_dol_req", None)
        return bool(req and req.get("wait") and self._dol_live(req))

    def _dol_refuse_if_busy(self):
        """มีคำขอ DOL รอผลอยู่ (ยังไม่กดยกเลิก) ⇒ แจ้งแล้วคืน True — ต้องเรียกก่อนแตะสถานะใด ๆ"""
        req = getattr(self, "_dol_req", None)
        if not (req and req.get("wait") and self._dol_live(req)):
            return False
        try:
            _shown = req.get("dlg") is not None and req["dlg"].isVisible()
        except Exception:
            _shown = False
        if not _shown:
            req["abandoned"] = True
            self._dol_end(req)
            return False
        self.iface.messageBar().pushMessage(
            "DOL", "กำลังค้นหาอยู่ — รอผลก่อนแล้วค่อยค้นใหม่ (หรือกด ยกเลิก ที่กล่องรอ)", level=1, duration=5)
        return True

    def _dol_wait_arm(self, busy, req, own=False):
        """กล่องรอมีปุ่ม "ยกเลิก" จริง — ยกเลิก / Esc / กากบาท ⇒ ทิ้งผลของคำขอนี้แล้วค้นใหม่ได้ทันที
        (worker วิ่งต่อจนจบเอง: ห้าม terminate QThread)"""
        busy.setCancelButtonText("ยกเลิก")
        busy.canceled.connect(lambda _r=req: self._dol_cancel(_r))
        busy.rejected.connect(lambda _r=req: self._dol_cancel(_r))
        req["wait"] = True
        req["dlg"] = busy
        if own:
            req["busy"] = busy

    def _dol_cancel(self, req):
        if not req or not req.get("wait") or req.get("abandoned") or req.get("ended"):
            return
        req["abandoned"] = True
        self._dol_end(req)
        try:
            self.iface.messageBar().pushMessage(
                "DOL", "ยกเลิกการค้นหาแล้ว — ผลที่ระบบกรมตอบกลับมาทีหลังจะไม่ถูกเปิด", level=0, duration=5)
        except Exception:
            pass

    def _dol_drop_busy(self, req):
        b = req.pop("busy", None) if req else None
        if b is None:
            return
        if getattr(self, "_dol_busy", None) is b:
            self._dol_busy = None
        try:
            b.hide()                    # hide ไม่ยิง canceled (close() ยิง)
            b.deleteLater()
        except Exception:
            pass

    def _dol_end(self, req):
        """จบ flow ของคำขอนี้จริง: ไม่รอผลแล้ว + ปิดกล่องรอ + ล้างไฮไลต์ของคำขอนี้ · เรียกซ้ำได้"""
        if not req or req.get("ended"):
            return
        req["ended"] = True
        req["wait"] = False
        self._dol_drop_busy(req)
        rb = req.get("rb")
        if "rb" not in req or (rb is not None and getattr(self, "_dol_highlight", None) is rb):
            self._dol_clear_highlight()

    def _dol_result_req(self, req):
        """ผลของงานค้น PARCEL_SEQ มาถึง ⇒ คำขอที่จะใช้ต่อ หรือ None = ทิ้งผล (ถูกยกเลิก/เก่า/ปลั๊กอินถูกปิด)"""
        if not getattr(self, "_alive", True) or not self._dol_live(req):
            return None
        req["wait"] = False             # ก่อนปิดกล่อง (close() ยิง canceled)
        self._dol_drop_busy(req)
        return req

    def _dol_step_done(self, req):
        """ขั้นเน็ตของ flow (_run_net) ได้ผล ⇒ True = ใช้ผลต่อ · False = ทิ้ง (ยกเลิก/เก่า)"""
        if not self._dol_live(req):
            return False
        req["wait"] = False
        return True

    @staticmethod
    def _dol_rawang_text(a):
        a = a or {}
        return "%s %s %s-%s ที่ดิน %s" % (a.get("m1", "?"), a.get("m2", "?"), a.get("m3", "?"),
                                         a.get("m4", "?"), a.get("landno", "?"))

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        rb = QgsRubberBand(self.iface.mapCanvas(), QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass
