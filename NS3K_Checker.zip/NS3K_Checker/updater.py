# -*- coding: utf-8 -*-
"""ระบบอัปเดตตัวเองของ NS3K Checker (พอร์ตจาก MLEP 2.4.1 / GPKG Editor 1.6.1) — ตรวจ/ติดตั้ง zip · คืนรุ่นเดิม · โหลดใหม่เอง
แหล่งอัปเดต = GitHub chakrit39/NS3K_Checker (version.txt + NS3K_Checker.zip) · เพิ่ม mirror สำรองได้ที่ QSettings
UpdateMixin = เมธอดฝั่งปลั๊กอิน (ปุ่ม 🚀 · ตรวจอัตโนมัติครั้งเดียวต่อ session · ดาวน์โหลด · ติดตั้ง · โหลดใหม่)"""
import os
import re
import time
import shutil
import zipfile
import tempfile
import requests
from qgis.PyQt.QtCore import Qt, QSettings, QThread, pyqtSignal, QTimer
from qgis.PyQt.QtWidgets import QAction, QApplication, QMessageBox, QProgressDialog, QShortcut
from qgis.core import Qgis
from .util import LOG_HINT, _log_err, _log_exc, _log_info, _reason_text

PRIMARY_VERSION_URL = "https://raw.githubusercontent.com/chakrit39/NS3K_Checker/refs/heads/main/version.txt"
PRIMARY_ZIP_URL = "https://github.com/chakrit39/NS3K_Checker/raw/refs/heads/main/NS3K_Checker.zip"
# สำเนารุ่นก่อนหน้าตอนอัปเดต: <โปรไฟล์>/python/ns3k_checker_backup/<ชื่อ>_prev (คืนได้ถ้ารุ่นใหม่โหลดไม่ขึ้น)
# ⚠️ ต้องอยู่นอก plugins/ (QGIS เห็นโฟลเดอร์สำเนาใน plugins/ เป็นปลั๊กอินตัวที่สอง) และห้ามตั้งชื่อเป็นชื่อแพ็กเกจตรง ๆ ใต้ python/
_UPD_BACKUP = "ns3k_checker_backup"
_OWN_PROP = "_ns3k_owner"       # ป้าย (dynamic property) บน QAction/QShortcut ที่ปลั๊กอินสร้างบนหน้าต่างหลัก
MENU = "&NS3K Checker"

_VER_RE = re.compile(r"\d+(?:\.\d+)*")


def _parse_version(text):
    """'1.0.10' -> (1, 0, 10) เพื่อเทียบเชิงตัวเลข (string เทียบแล้ว '1.0.10' < '1.0.9') · ทน BOM / 'v1.0.0' · อ่านไม่ได้ = ()"""
    if text is None:
        return ()
    if isinstance(text, (bytes, bytearray)):
        text = bytes(text).decode("utf-8-sig", "replace")
    s = str(text).replace("﻿", "").strip()
    if s[:1] in ("v", "V"):
        s = s[1:].strip()
    m = _VER_RE.match(s)
    if not m:
        return ()
    parts = [int(x) for x in m.group(0).split(".")]
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _new_session(user_agent):
    """session ที่ตรวจใบรับรองแบบเดียวกับเบราว์เซอร์ (ที่เก็บของ Windows + certifi) — ใช้ตัวเดียวกับงานระบบกรม"""
    from . import dol_api
    return dol_api._new_session(user_agent)


def _resp_text(res):
    c = getattr(res, "content", None)
    if isinstance(c, (bytes, bytearray)):
        return bytes(c).decode("utf-8-sig", "replace").strip()
    return str(getattr(res, "text", "") or "").replace("﻿", "").strip()


def _fetch_version_text(urls, user_agent, timeout=8):
    """อ่าน version.txt จากแต่ละแหล่งตามลำดับ (หลัก → mirror) · ทุกแหล่งล้ม = โยน error ตัวสุดท้าย · ทำงานใน worker thread"""
    last = None
    for url in urls:
        try:
            s = _new_session(user_agent)
            try:
                res = s.get(url, timeout=timeout)
            finally:
                s.close()
            res.raise_for_status()   # 429/404 มากับ HTML — ไม่เช็คจะแจ้ง 'ล่าสุดแล้ว' ผิด
            txt = _resp_text(res)
            if not _parse_version(txt):
                _log_info("ตรวจอัปเดต: อ่านเลขรุ่นจาก %s ไม่ได้ — เซิร์ฟเวอร์ตอบ %r" % (url, txt[:200]), Qgis.Warning)
                raise RuntimeError("อ่านเลขรุ่นจากเซิร์ฟเวอร์ไม่ได้")
            return txt.splitlines()[0].strip()
        except Exception as e:
            last = e
    raise last if last is not None else RuntimeError("ไม่มีแหล่งตรวจสอบเวอร์ชัน")


def _upd_net_text(e):
    """exception ของงานเครือข่ายของตัวอัปเดต (GitHub) ⇒ เหตุภาษาไทยสั้น ๆ"""
    try:
        if isinstance(e, requests.exceptions.SSLError):
            return "ตรวจใบรับรองของเซิร์ฟเวอร์อัปเดต (GitHub) ไม่ผ่าน — เครือข่ายหรือโปรแกรมป้องกันไวรัสอาจดักการเชื่อมต่อ · แจ้งผู้ดูแล"
        if isinstance(e, requests.exceptions.Timeout):
            return "เซิร์ฟเวอร์อัปเดต (GitHub) ตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
        if isinstance(e, requests.exceptions.ConnectionError):
            return "เชื่อมต่อเซิร์ฟเวอร์อัปเดต (GitHub) ไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
        if isinstance(e, requests.exceptions.HTTPError):
            code = getattr(getattr(e, "response", None), "status_code", None)
            if code == 429:
                return "GitHub จำกัดจำนวนครั้งต่อ IP ชั่วคราว (HTTP 429 — ไม่ใช่ไฟล์หาย) ลองใหม่ภายหลัง หรือตั้ง mirror สำรอง"
            return "เซิร์ฟเวอร์อัปเดต (GitHub) ตอบผิดปกติ" + (f" (HTTP {code})" if code else "")
        if isinstance(e, requests.exceptions.RequestException):
            return "เชื่อมต่อเซิร์ฟเวอร์อัปเดต (GitHub) ผิดพลาด"
        if isinstance(e, OSError):
            return "บันทึกไฟล์ที่ดาวน์โหลดลงเครื่องไม่ได้ — " + _os_reason(e)
    except Exception:
        pass
    return _reason_text(e)


def _meta_value(text, key, strict=False):
    """ค่าใน [general] ของ metadata.txt (ไม่มี = '')
    strict=True — อ่านแบบเดียวกับ QGIS (ConfigParser ปริยาย ไม่ตัด BOM) ⇒ อ่านไม่ได้ = โยน error (ใช้ตรวจ zip อัปเดต)"""
    import configparser
    if strict:
        cp = configparser.ConfigParser()
        cp.read_string(text)
        return cp.get("general", key, fallback="").strip()
    t = str(text).lstrip("﻿")
    try:
        cp = configparser.ConfigParser(interpolation=None, strict=False)
        cp.read_string(t)
        return cp.get("general", key, fallback="").strip()
    except Exception:
        pass
    for line in t.splitlines():
        k, sep, val = line.partition("=")
        if sep and k.strip().lower() == key.lower():
            return val.strip()
    return ""


# =======================================================================
# ตัวติดตั้งอัปเดต — ตรวจครบ "ก่อน" แตะโฟลเดอร์ปลั๊กอิน แล้วสลับโฟลเดอร์ทั้งชุด · 🔑 ทำงานใน worker thread ห้ามแตะ widget
# 🔑 โค้ดชุดนี้ทำงานจาก "รุ่นที่ติดตั้งอยู่" ⇒ รูปแบบ zip/metadata ต้องคงเดิม (NS3K_Checker/metadata.txt + __init__.py)
# =======================================================================
class _UpdateInstallError(RuntimeError):
    """ติดตั้งอัปเดตไม่สำเร็จ (แยกจากดาวน์โหลดไม่สำเร็จ) · intact=True = ยังไม่ได้แตะโฟลเดอร์ปลั๊กอิน
    already=True = ไม่ใช่ความล้มเหลว: มีรุ่นที่ติดตั้งรอไว้แล้ว ⇒ บอกให้ปิด-เปิด QGIS"""

    def __init__(self, msg, intact=True, already=False):
        super().__init__(msg)
        self.intact = intact
        self.already = already


def _rmtree_quiet(path):
    """ลบโฟลเดอร์แบบไม่โยน error · symlink = ลบแค่ตัวลิงก์ · ไฟล์อ่านอย่างเดียวบน Windows ปลดบิตแล้วลองใหม่"""
    import stat
    import sys

    def _ro(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
            func(p)
        except Exception:
            pass
    try:
        if os.path.islink(path):
            os.unlink(path)
        elif os.path.isdir(path):
            if sys.version_info >= (3, 12):
                shutil.rmtree(path, onexc=_ro)
            else:
                shutil.rmtree(path, onerror=_ro)
    except Exception:
        pass


def _rename_retry(src, dst, tries=5, delay=0.5):
    """os.rename แบบลองซ้ำ — บน Windows โปรแกรมป้องกันไวรัส/ตัวทำดัชนีล็อกไฟล์ที่เพิ่งแตกออกมาได้ชั่วครู่"""
    for i in range(tries):
        try:
            os.rename(src, dst)
            return
        except OSError:
            if i == tries - 1:
                raise
            time.sleep(delay)


def _upd_paths(plugins_dir, name):
    pd = os.path.abspath(plugins_dir)
    bak = os.path.join(os.path.dirname(pd), _UPD_BACKUP)
    return {"here": os.path.join(pd, name), "bak": bak,
            "prev": os.path.join(bak, name + "_prev"), "failed": os.path.join(bak, name + "_failed")}


def _disk_version(here):
    try:
        with open(os.path.join(here, "metadata.txt"), encoding="utf-8-sig") as fh:
            return _meta_value(fh.read(), "version")
    except Exception:
        return ""


def _read_version(default="0"):
    """เลขรุ่นของปลั๊กอินที่กำลังรัน — จาก metadata.txt ข้างไฟล์นี้ (แหล่งเดียวกับที่ QGIS และตัวอัปเดตใช้)
    อ่านไม่ได้ = default ("0" = เก่ากว่าทุกรุ่น ⇒ ตัวตรวจอัปเดตเสนอรุ่นใหม่ให้ซ่อมเอง)"""
    v = _disk_version(os.path.dirname(os.path.abspath(__file__)))
    if _parse_version(v):
        return v
    _log_info("อ่านเลขรุ่นจาก metadata.txt ไม่ได้ (%r) — ใช้ %s แทน" % (v, default), Qgis.Warning)
    return default


def _upd_check_disk(here, new_version, cur_version):
    """รุ่นบนดิสก์ ≠ รุ่นที่เปิดอยู่ (ติดตั้งรอไว้แล้ว / QGIS อีกหน้าต่างอัปเดตไปแล้ว) ⇒ ไม่ติดตั้งซ้ำ (already=True)"""
    disk = _disk_version(here)
    dv, rv = _parse_version(disk), _parse_version(cur_version)
    if not dv or not rv or dv == rv:
        return
    nv = _parse_version(new_version)
    if nv and dv >= nv:
        raise _UpdateInstallError(
            f"ติดตั้งรุ่น {disk} ไว้แล้ว — กรุณาบันทึกงาน แล้วปิด QGIS และเปิดใหม่เพื่อใช้รุ่นใหม่", already=True)
    raise _UpdateInstallError(
        f"มีรุ่น {disk} ติดตั้งรอไว้แล้ว (ยังไม่ได้เปิดใช้ · ที่เปิดอยู่คือ {cur_version}) — "
        f"กรุณาปิด QGIS แล้วเปิดใหม่ก่อน แล้วค่อยอัปเดตเป็น {new_version}", already=True)


def _os_reason(e):
    import errno
    no, win = getattr(e, "errno", None), getattr(e, "winerror", None)
    if isinstance(e, PermissionError) or no in (errno.EACCES, errno.EPERM) or win in (5, 32, 33):
        return "ไม่มีสิทธิ์เขียนไฟล์ในโฟลเดอร์ของ QGIS หรือมีไฟล์ถูกโปรแกรมอื่นเปิด/ล็อกอยู่ (เช่นโปรแกรมป้องกันไวรัส)"
    if no == errno.ENOSPC or win == 112:
        return "พื้นที่ดิสก์เต็ม"
    if no == errno.EROFS:
        return "ดิสก์เป็นแบบอ่านอย่างเดียว"
    if no == errno.ENAMETOOLONG or win == 206:
        return "ที่อยู่ไฟล์ยาวเกินที่ระบบรับได้"
    return "เขียนไฟล์ลงเครื่องไม่ได้"


def _qgis_version_tuple(qgis_int=None):
    try:
        v = int(qgis_int if qgis_int is not None else Qgis.QGIS_VERSION_INT)
        return (v // 10000, (v // 100) % 100, v % 100)
    except Exception:
        return None


def _guarded_imports(tree):
    """ImportFrom ที่อยู่ใน try/except ImportError|Exception = ตั้งใจให้ "ไม่มีก็ได้" ⇒ ไม่นับเป็นไฟล์ที่ zip ต้องมี"""
    import ast as _ast
    broad = {"ImportError", "ModuleNotFoundError", "Exception", "BaseException"}
    out = set()
    for node in _ast.walk(tree):
        if not isinstance(node, _ast.Try):
            continue
        catch = False
        for h in node.handlers:
            if h.type is None:
                catch = True
                break
            names = {x.id if isinstance(x, _ast.Name) else getattr(x, "attr", "")
                     for x in (h.type.elts if isinstance(h.type, _ast.Tuple) else [h.type])}
            if names & broad:
                catch = True
                break
        if catch:
            for stmt in node.body:
                out.update(id(sub) for sub in _ast.walk(stmt) if isinstance(sub, _ast.ImportFrom))
    return out


def _missing_relative_imports(trees, files):
    """โมดูลในแพ็กเกจที่โค้ดเรียกใช้ (from .x import … / from . import x) แต่ไม่มีไฟล์ใน zip"""
    import ast as _ast
    have = set(files)
    init_names = set()
    t0 = trees.get("__init__.py")
    if t0 is not None:
        for node in _ast.walk(t0):
            if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef, _ast.ClassDef)):
                init_names.add(node.name)
            elif isinstance(node, _ast.Assign):
                init_names.update(t.id for t in node.targets if isinstance(t, _ast.Name))
            elif isinstance(node, (_ast.Import, _ast.ImportFrom)):
                init_names.update((a.asname or a.name).split(".")[0] for a in node.names)
    missing = set()
    for rel, tree in trees.items():
        pkg = rel.split("/")[:-1]
        opt = _guarded_imports(tree)
        for node in _ast.walk(tree):
            if not isinstance(node, _ast.ImportFrom) or not node.level or id(node) in opt:
                continue
            up = node.level - 1
            if up > len(pkg):
                continue
            base = pkg[:len(pkg) - up]
            if node.module:
                targets = [base + node.module.split(".")]
            elif not base:
                targets = [[a.name] for a in node.names if a.name not in init_names]
            else:
                continue
            for parts in targets:
                p = "/".join(parts)
                if p + ".py" not in have and p + "/__init__.py" not in have:
                    missing.add(p.replace("/", ".") + ".py")
    return missing


def _check_update_zip(z, name, new_version, cur_version, qgis_int=None):
    """ตรวจ zip อัปเดตก่อนแตะโฟลเดอร์ปลั๊กอิน · ไม่ผ่าน = _UpdateInstallError (ข้อความไทย) · ผ่าน = คืนเลขรุ่นใน zip"""
    import ast as _ast
    bad = z.testzip()
    if bad:
        raise _UpdateInstallError(f"ไฟล์ในซิปเสีย: {bad} — ยกเลิกการติดตั้ง กันปลั๊กอินพัง")
    pre = name + "/"
    files = {n[len(pre):]: n for n in z.namelist() if n.startswith(pre) and not n.endswith("/")}
    for need in ("metadata.txt", "__init__.py"):
        if need not in files:
            raise _UpdateInstallError(f"ซิปไม่มี {pre}{need} — โครงไฟล์ไม่ถูกต้อง · ยกเลิกการติดตั้ง")
    try:
        meta = z.read(files["metadata.txt"]).decode("utf-8")
        zver = _meta_value(meta, "version", strict=True)
        qmin = _meta_value(meta, "qgisMinimumVersion", strict=True)
        icon = _meta_value(meta, "icon", strict=True)
    except Exception as e:
        raise _UpdateInstallError(
            f"metadata.txt ในซิปอ่านไม่ได้แบบที่ QGIS อ่าน ({e.__class__.__name__}) — ยกเลิกการติดตั้ง")
    zv, nv = _parse_version(zver), _parse_version(new_version)
    if not zv or not nv:
        raise _UpdateInstallError(f"อ่านเลขรุ่นไม่ได้ (ในซิป {zver!r} · ที่ประกาศ {new_version!r}) — ยกเลิกการติดตั้ง")
    if zv != nv:
        raise _UpdateInstallError(f"ซิปเป็นเวอร์ชัน {zver} แต่เซิร์ฟเวอร์ประกาศไว้ว่า {new_version} — ยกเลิกกันไฟล์ไม่ตรงกัน")
    cv = _parse_version(cur_version)
    if cv and zv <= cv:
        raise _UpdateInstallError(
            f"ซิปเป็นเวอร์ชัน {zver} ซึ่งไม่ใหม่กว่าที่ใช้อยู่ ({cur_version}) — ยกเลิกกันการถอยเวอร์ชัน")
    qv = _parse_version(qmin)
    if not qv:
        raise _UpdateInstallError(f"qgisMinimumVersion ในซิปอ่านไม่ได้ ({qmin!r}) — ยกเลิกการติดตั้ง")
    cq = _qgis_version_tuple(qgis_int)
    if cq is not None and qv > cq:
        raise _UpdateInstallError(
            f"รุ่น {zver} ต้องใช้ QGIS {qmin} ขึ้นไป แต่เครื่องนี้เป็น QGIS {'.'.join(map(str, cq))} — "
            "ยกเลิกการติดตั้ง (แจ้งผู้ดูแลให้อัปเดต QGIS)")
    if icon and icon not in files:
        raise _UpdateInstallError(f"ซิปไม่มีไฟล์ไอคอน {icon} ที่ metadata.txt อ้างถึง — ยกเลิกการติดตั้ง")
    trees = {}
    for rel, full in sorted(files.items()):
        if not rel.endswith(".py"):
            continue
        try:
            tree = _ast.parse(z.read(full), filename=full)
            compile(tree, full, "exec", dont_inherit=True)
        except (SyntaxError, ValueError) as e:
            raise _UpdateInstallError(
                f"ไฟล์ {rel} ในซิปมีข้อผิดพลาด ({e.__class__.__name__} บรรทัด {getattr(e, 'lineno', '?')}) — ยกเลิกการติดตั้ง")
        trees[rel] = tree
    if not any(isinstance(n, _ast.FunctionDef) and n.name == "classFactory" for n in trees["__init__.py"].body):
        raise _UpdateInstallError("__init__.py ในซิปไม่มี classFactory — QGIS โหลดปลั๊กอินไม่ได้ · ยกเลิกการติดตั้ง")
    miss = _missing_relative_imports(trees, files)
    if miss:
        raise _UpdateInstallError("ซิปขาดไฟล์ที่โค้ดเรียกใช้: " + ", ".join(sorted(miss)) + " — ยกเลิกการติดตั้ง")
    return zver


def _install_update_zip(zip_path, plugins_dir, name, new_version, cur_version, qgis_int=None):
    """ตรวจ zip -> แตกลงโฟลเดอร์ชั่วคราว -> ย้ายรุ่นเดิมไปเก็บ (ns3k_checker_backup/<ชื่อ>_prev) -> ย้ายรุ่นใหม่เข้าที่"""
    P = _upd_paths(plugins_dir, name)
    here, prev = P["here"], P["prev"]
    _upd_check_disk(here, new_version, cur_version)
    tmp = None
    try:
        try:
            z = zipfile.ZipFile(zip_path)
        except Exception as e:
            raise _UpdateInstallError(f"ไฟล์อัปเดตเสียหาย (zip ไม่สมบูรณ์ · {e.__class__.__name__}) — ยกเลิกการติดตั้ง")
        with z:
            zver = _check_update_zip(z, name, new_version, cur_version, qgis_int)
            try:
                os.makedirs(P["bak"], exist_ok=True)
                tmp = tempfile.mkdtemp(prefix="upd_", dir=P["bak"])
                z.extractall(tmp)
            except OSError as e:
                raise _UpdateInstallError(f"แตกไฟล์รุ่นใหม่ลงเครื่องไม่ได้ — {_os_reason(e)} · ยกเลิกการติดตั้ง") from e
        src = os.path.join(tmp, name)
        if not os.path.isfile(os.path.join(src, "__init__.py")):
            raise _UpdateInstallError("ซิปแตกออกมาไม่ครบ (ไม่พบ __init__.py) — ยกเลิกการติดตั้ง")
        if os.path.lexists(prev):
            _rmtree_quiet(prev)
            if os.path.lexists(prev):
                raise _UpdateInstallError(f"ลบสำเนารุ่นก่อนหน้า ({prev}) ไม่ได้ — ยกเลิกการติดตั้ง (ปิด QGIS แล้วลองใหม่)")
        try:
            _rename_retry(here, prev)
        except OSError as e:
            raise _UpdateInstallError(f"ย้ายรุ่นเดิมออกไปเก็บไม่ได้ — {_os_reason(e)} · ยกเลิกการติดตั้ง") from e
        try:
            _rename_retry(src, here)
        except Exception as e:
            try:
                _rename_retry(prev, here)
            except Exception:
                raise _UpdateInstallError(
                    f"ติดตั้งไม่สำเร็จ และย้ายรุ่นเดิมกลับไม่ได้ — สำเนารุ่นเดิมอยู่ที่ {prev} · กรุณาปิด QGIS แล้วแจ้งผู้ดูแล",
                    intact=False)
            _why = _os_reason(e) if isinstance(e, OSError) else e.__class__.__name__
            raise _UpdateInstallError(f"ย้ายรุ่นใหม่เข้าที่ไม่ได้ ({_why}) — คืนรุ่นเดิมแล้ว")
    finally:
        if tmp:
            _rmtree_quiet(tmp)
    return zver


def _rollback_failed_update(plugins_dir, name):
    """รุ่นใหม่โหลดไม่ขึ้น ⇒ ย้ายรุ่นใหม่ไปเก็บ (<ชื่อ>_failed) แล้วคืนสำเนารุ่นเดิมเข้าที่ · คืน (สำเร็จ?, รายละเอียด)"""
    P = _upd_paths(plugins_dir, name)
    here, failed, prev = P["here"], P["failed"], P["prev"]
    if not os.path.isdir(prev):
        return False, f"ไม่พบสำเนารุ่นเดิม ({prev})"
    try:
        os.makedirs(P["bak"], exist_ok=True)
        if os.path.lexists(failed):
            _rmtree_quiet(failed)
        if os.path.lexists(here):
            _rename_retry(here, failed)
        _rename_retry(prev, here)
        return True, failed
    except Exception as e:
        if not os.path.lexists(here) and os.path.isdir(failed):
            try:
                _rename_retry(failed, here)
            except Exception:
                pass
        return False, f"{e.__class__.__name__}: {e} · สำเนารุ่นเดิมอยู่ที่ {prev}"


# =======================================================================
# QShortcut/QAction ที่ปลั๊กอินสร้างบนหน้าต่างหลักของ QGIS
# =======================================================================
def _qobj_dispose(o):
    """ทิ้ง QShortcut/QAction ของปลั๊กอินให้หมดจริง: ปิด · ถอดจาก QgsShortcutsManager · ตัด signal · ตัดจากหน้าต่างหลัก · ลบ
    (setParent(None)+deleteLater เฉย ๆ ⇒ ระหว่างรอลบยังมีสองตัวคีย์เดียวกัน = Qt ไม่ยิงทั้งคู่)"""
    if o is None:
        return
    try:
        from qgis.gui import QgsGui
        _mgr = QgsGui.shortcutsManager()
    except Exception:
        _mgr = None
    try:
        if isinstance(o, QShortcut):
            o.setEnabled(False)
            sigs = (o.activated, o.activatedAmbiguously)
            _unreg = getattr(_mgr, "unregisterShortcut", None)
        else:
            sigs = (o.triggered,)
            _unreg = getattr(_mgr, "unregisterAction", None)
        if _unreg is not None:
            try:
                _unreg(o)
            except Exception:
                pass
        for sig in sigs:
            try:
                sig.disconnect()
            except Exception:
                pass
        o.setParent(None)
        o.deleteLater()
    except Exception:
        pass


def _debris_clear(iface, keep=None):
    """รุ่นใหม่ล้มกลาง initGui ⇒ QGIS ทิ้ง instance นั้นโดยไม่เรียก unload ⇒ ไอคอน/QShortcut ค้างบนหน้าต่างหลัก
    ⇒ ก่อนเปิดรุ่นเดิมกลับมา เอาของที่ติดป้าย _ns3k_owner ออก (ยกเว้นของ instance ที่ยังเปิดอยู่ = keep)"""
    n = 0
    try:
        mw = iface.mainWindow()
    except Exception:
        mw = None
    if mw is None:
        return n
    for cls in (QShortcut, QAction):
        try:
            objs = mw.findChildren(cls)
        except Exception:
            objs = []
        for o in objs:
            try:
                tok = o.property(_OWN_PROP)
            except Exception:
                continue
            if not tok or (keep is not None and tok == keep):
                continue
            if cls is QAction:
                for rm in (lambda: iface.removeToolBarIcon(o), lambda: iface.removePluginMenu(MENU, o)):
                    try:
                        rm()
                    except Exception:
                        pass
            _qobj_dispose(o)
            n += 1
    return n


class _FnWorker(QThread):
    """รัน callable (งานเน็ต/ไฟล์ที่ blocking) ใน thread แยก — done(ผลลัพธ์) / fail(exception)"""
    done = pyqtSignal(object)
    fail = pyqtSignal(object)

    def __init__(self, fn):
        super().__init__()
        self._fn = fn

    def run(self):
        try:
            self.done.emit(self._fn())
        except Exception as e:
            self.fail.emit(e)


class _UpdateDownloadWorker(QThread):
    """ดาวน์โหลด zip อัปเดตลงไฟล์ชั่วคราว (สตรีมเป็น chunk) · ลองทีละแหล่ง (หลัก → mirror) จนสำเร็จ"""
    progress = pyqtSignal(int, int)
    finished_ok = pyqtSignal(str)
    failed = pyqtSignal(object)         # exception ตัวสุดท้าย หรือ 'cancel'

    def __init__(self, urls, dest_path, user_agent):
        super().__init__()
        self.urls = list(urls)
        self.dest_path = dest_path
        self.user_agent = user_agent
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        last = None
        for url in self.urls:
            if self._cancel:
                self.failed.emit("cancel")
                return
            s = _new_session(self.user_agent)
            try:
                with s.get(url, timeout=(10, 60), stream=True) as r:
                    r.raise_for_status()
                    total = int(r.headers.get('content-length', 0) or 0)
                    done = 0
                    with open(self.dest_path, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=65536):
                            if self._cancel:
                                self.failed.emit("cancel")
                                return
                            if chunk:
                                f.write(chunk)
                                done += len(chunk)
                                self.progress.emit(done, total)
                self.finished_ok.emit(self.dest_path)
                return
            except Exception as e:
                last = e
            finally:
                try:
                    s.close()
                except Exception:
                    pass
        self.failed.emit(last if last is not None else RuntimeError("ไม่มีแหล่งดาวน์โหลด"))


class UpdateMixin:
    """เมธอดระบบอัปเดต — คลาสที่สืบทอดต้องมี: iface · dlg · version · _alive · _net_workers · _updating · _auto_checked ·
    _run_net() · _gesture_busy() · _dol_busy_now()"""

    def _mirror_urls(self, key):
        """URL สำรองที่ตั้งไว้ใน QSettings NS3KChecker/<key> (คั่นด้วย , หรือ ;) — ว่าง = ไม่มี"""
        raw = QSettings().value("NS3KChecker/" + key, "", str) or ""
        return [u.strip() for u in raw.replace(";", ",").split(",") if u.strip()]

    def _version_urls(self):
        return [PRIMARY_VERSION_URL] + self._mirror_urls("MirrorVersionUrls")

    def _zip_urls(self):
        return [PRIMARY_ZIP_URL] + self._mirror_urls("MirrorZipUrls")

    def _ua(self):
        return f"NS3K_Checker/{self.version}"

    def _msg_parent(self):
        """parent ของกล่องข้อความ — หน้าต่างปลั๊กอินถ้าเปิดอยู่ (ไม่งั้นกล่องไปซ่อนหลังหน้าต่างที่ปิด = ดูเหมือนค้าง)"""
        try:
            if self.dlg is not None and self.dlg.isVisible():
                return self.dlg
        except RuntimeError:
            pass
        return self.iface.mainWindow()

    def _track_worker(self, w):
        """เก็บ reference ของ QThread ไว้จนจบจริง แล้วปล่อยตอน finished เท่านั้น
        (ลบจาก slot ผลลัพธ์ = อาจลบก่อน thread จบ ⇒ "QThread: Destroyed while thread is still running" = QGIS ดับ)"""
        self._net_workers.append(w)

        def _release(_w=w):
            try:
                self._net_workers.remove(_w)
            except ValueError:
                pass
            _w.deleteLater()
        w.finished.connect(_release)
        return w

    def _modal_open(self):
        try:
            return QApplication.activeModalWidget() is not None
        except Exception:
            return False

    def _maybe_auto_check_update(self):
        """เช็คเวอร์ชันใหม่อัตโนมัติครั้งเดียวต่อ session แบบเงียบ — เจอของใหม่เท่านั้นถึงถาม · เน็ตไม่ถึง = เงียบ (ลง Log)"""
        if self._auto_checked or not self._alive:
            return
        self._auto_checked = True
        urls, ua = self._version_urls(), self._ua()
        w = self._track_worker(_FnWorker(lambda: _fetch_version_text(urls, ua)))

        def _ok(new_version, _tries=0):
            if not self._alive:
                return
            try:
                nv = _parse_version(new_version)
                if not nv or nv <= _parse_version(self.version):
                    return
                if self._updating:
                    return
                # มีกล่อง modal เปิดค้าง / กำลังกดเมาส์ ⇒ รอก่อน (กล่องถามที่เด้งกลางท่าทำเครื่องมือค้าง)
                if self._modal_open() or self._gesture_busy():
                    if _tries < 240:         # 0.5 วิ × 240 = 2 นาที แล้วเลิก (กด 🚀 เองได้เสมอ)
                        QTimer.singleShot(500, lambda: _ok(new_version, _tries + 1))
                    return
                self._updating = True
                self.prompt_update(new_version)
            except Exception:
                self._updating = False
                _log_exc("ตรวจอัปเดตอัตโนมัติ: ถามติดตั้งรุ่นใหม่ไม่สำเร็จ")
        w.done.connect(_ok)
        w.fail.connect(lambda e: _log_info("ตรวจอัปเดตอัตโนมัติไม่สำเร็จ — " + _upd_net_text(e)))
        w.start()

    def update_plugin(self):
        """ปุ่ม 🚀 Check Update — เช็คเวอร์ชันใน thread แยก แล้วเข้าโฟลว์ยืนยัน+ติดตั้งร่วมกับ auto-check"""
        if self._updating:
            return
        self._updating = True
        urls, ua = self._version_urls(), self._ua()

        def _got(new_version):
            if _parse_version(new_version) > _parse_version(self.version):
                self.prompt_update(new_version)
            else:
                self._updating = False
                QMessageBox.information(self._msg_parent(), "อัปเดต",
                                        f"คุณกำลังใช้งานเวอร์ชันล่าสุดแล้ว (v{self.version})")

        def _err(e):
            self._updating = False
            _log_err("ตรวจสอบอัปเดตไม่สำเร็จ", e)
            QMessageBox.warning(self._msg_parent(), "ตรวจสอบอัปเดต",
                                f"ไม่สามารถตรวจสอบอัปเดตได้ — {_upd_net_text(e)}\n"
                                f"ใช้รุ่นปัจจุบัน ({self.version}) ต่อได้ตามปกติ ลองกด 🚀 ใหม่ภายหลัง\n({LOG_HINT})")

        self._run_net("กำลังตรวจสอบเวอร์ชันใหม่...", lambda: _fetch_version_text(urls, ua), _got, _err)

    def prompt_update(self, new_version):
        """ถามยืนยัน -> ดาวน์โหลด -> ติดตั้ง -> โหลดรุ่นใหม่ · ผู้เรียกตั้ง _updating = True ไว้แล้ว — ทุกทางออกต้องคืนเป็น False"""
        here = os.path.dirname(os.path.abspath(__file__))
        try:
            _upd_check_disk(here, new_version, self.version)
        except _UpdateInstallError as e:
            self._updating = False
            QMessageBox.information(self._msg_parent(), "อัปเดต", _reason_text(e))
            return
        reply = QMessageBox.question(
            self._msg_parent(), "พบเวอร์ชันใหม่",
            f"NS3K Checker เวอร์ชันใหม่ ({new_version}) พร้อมใช้งาน (ใช้อยู่ {self.version})\nต้องการอัปเดตทันทีหรือไม่?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply != QMessageBox.Yes or not self._alive:
            self._updating = False
            return
        self._start_download(new_version)

    def _start_download(self, new_version):
        progress = QProgressDialog(f"กำลังดาวน์โหลดเวอร์ชัน {new_version}...", "ยกเลิก", 0, 0, self._msg_parent())
        progress.setWindowTitle("อัปเดตปลั๊กอิน")
        progress.setWindowModality(Qt.WindowModal)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.setMinimumDuration(0)
        progress.show()
        try:
            fd, dest = tempfile.mkstemp(prefix="NS3K_Checker_upd_", suffix=".zip")
            os.close(fd)
        except OSError as e:
            progress.close()
            progress.deleteLater()
            self._updating = False
            _log_err("สร้างไฟล์ชั่วคราวสำหรับดาวน์โหลดไม่ได้", e)
            QMessageBox.critical(self._msg_parent(), "ดาวน์โหลดอัปเดต",
                                 f"สร้างไฟล์ชั่วคราวสำหรับดาวน์โหลดไม่ได้ — {_os_reason(e)}")
            return
        w = self._track_worker(_UpdateDownloadWorker(self._zip_urls(), dest, self._ua()))

        def _rm_dest():
            try:
                os.remove(dest)
            except Exception:
                pass

        def _close():
            # ตัด canceled ก่อนปิด — QProgressDialog.close() ยิง canceled (จะกลายเป็นสั่งยกเลิก worker ที่จบแล้ว)
            try:
                progress.canceled.disconnect()
            except Exception:
                pass
            try:
                progress.close()
                progress.deleteLater()
            except Exception:
                pass

        def _prog(done, total):
            if total > 0:
                progress.setMaximum(total)
                progress.setValue(min(done, total))

        def _ok(path):
            _close()
            if not self._alive:
                _rm_dest()
                return
            self._install_downloaded(path, new_version)

        def _fail(e):
            _close()
            _rm_dest()
            if not self._alive:
                return
            self._updating = False
            if isinstance(e, str) and e == "cancel":
                return
            _log_err("ดาวน์โหลดรุ่นใหม่ไม่สำเร็จ", e)
            QMessageBox.critical(self._msg_parent(), "ดาวน์โหลดอัปเดต",
                                 f"ดาวน์โหลดรุ่นใหม่ไม่สำเร็จ — {_upd_net_text(e)}\n"
                                 f"ยังใช้รุ่นเดิม ({self.version}) ได้ตามปกติ · ตรวจการเชื่อมต่อแล้วกด 🚀 อีกครั้ง\n({LOG_HINT})")
        w.progress.connect(_prog)
        w.finished_ok.connect(_ok)
        w.failed.connect(_fail)
        progress.canceled.connect(w.cancel)
        w.start()

    def _install_downloaded(self, path, new_version):
        """ติดตั้ง zip ที่ดาวน์โหลดแล้วใน thread แยก (แตกไฟล์ · compile ตรวจ · ย้ายโฟลเดอร์) แล้วโหลดรุ่นใหม่ให้เอง"""
        here = os.path.dirname(os.path.abspath(__file__))
        plugins_dir, name, cur = os.path.dirname(here), os.path.basename(here), self.version

        def _install():
            try:
                return _install_update_zip(path, plugins_dir, name, new_version, cur)
            finally:
                try:
                    os.remove(path)
                except Exception:
                    pass

        def _ok(zver):
            self._updating = False
            why = self._reload_blocker()
            if why:
                QMessageBox.information(self._msg_parent(), "อัปเดตสำเร็จ",
                                        f"อัปเดตเป็นเวอร์ชัน {zver} เรียบร้อยแล้ว\n\n{why}\n"
                                        "กรุณาปิด QGIS แล้วเปิดใหม่เพื่อใช้รุ่นใหม่")
                return
            QMessageBox.information(self._msg_parent(), "อัปเดตสำเร็จ",
                                    f"อัปเดตเป็นเวอร์ชัน {zver} เรียบร้อยแล้ว\n\n"
                                    "กด OK เพื่อโหลดปลั๊กอินรุ่นใหม่ทันที (ไม่ต้องปิด QGIS)")
            self._schedule_self_reload(zver)

        def _err(e):
            self._updating = False
            if isinstance(e, _UpdateInstallError) and e.already:
                QMessageBox.information(self._msg_parent(), "อัปเดต", _reason_text(e))
                return
            _log_err("ติดตั้งอัปเดตไม่สำเร็จ", e)
            intact = getattr(e, "intact", True)
            QMessageBox.critical(self._msg_parent(), "ติดตั้งอัปเดตไม่สำเร็จ",
                                 f"ติดตั้งรุ่น {new_version} ไม่สำเร็จ"
                                 + (f" — ยังใช้รุ่นเดิม ({self.version}) ได้ตามปกติ" if intact else "")
                                 + f"\n\n{_reason_text(e)}")

        self._run_net(f"กำลังติดตั้งเวอร์ชัน {new_version}...", _install, _ok, _err)

    def _reload_blocker(self):
        """เหตุที่ "ยังไม่ควร" โหลดปลั๊กอินใหม่ตอนนี้ หรือ '' ถ้าปลอดภัย
        ① QGIS ไม่มี qgis.utils.reloadPlugin ② กำลังค้นระบบกรมอยู่ ③ มี thread เน็ตยังวิ่ง (QThread ถูกทำลายระหว่างวิ่ง = QGIS ดับ)"""
        try:
            import qgis.utils as _qu
            if not hasattr(_qu, "reloadPlugin"):
                return "QGIS รุ่นนี้โหลดปลั๊กอินใหม่เองไม่ได้"
        except Exception:
            return "QGIS รุ่นนี้โหลดปลั๊กอินใหม่เองไม่ได้"
        if self._dol_busy_now():
            return "ตอนนี้กำลังค้นข้อมูลจากระบบกรมอยู่"
        for w in list(self._net_workers):
            try:
                running = w.isRunning()
            except Exception:
                continue
            if running:
                try:
                    if w.wait(300):
                        continue
                except Exception:
                    pass
                return "ตอนนี้ยังมีงานดึงข้อมูลจากเน็ตค้างอยู่"
        return ""

    def _schedule_self_reload(self, zver):
        """สั่ง QGIS โหลดปลั๊กอินนี้ใหม่ — เลื่อนไปทำหลังกล่องข้อความปิดแล้ว
        🔑 ห้ามเรียก reloadPlugin ตรงจาก callback ของตัวเอง: unload() จะรื้ออินสแตนซ์ที่ยังอยู่บน stack
        🔑 _do ห้ามอ้าง `self` — อินสแตนซ์เดิมจะถูกทิ้งระหว่าง reload
        · ตัดสินผลจากสถานะจริง (active_plugins + ตัวปลั๊กอินเป็นตัวใหม่) · รุ่นใหม่โหลดไม่ขึ้น ⇒ คืนรุ่นเดิมแล้วเปิดกลับมา"""
        here = os.path.dirname(os.path.abspath(__file__))
        name = os.path.basename(here)
        plugins_dir = os.path.dirname(here)
        _iface = self.iface

        def _say(text, level=1):
            try:
                _iface.messageBar().pushMessage("อัปเดต NS3K Checker", text, level=level, duration=0)
            except Exception:
                pass

        def _do(_tries=0):
            try:
                import qgis.utils as _qu
                try:
                    _busy = (QApplication.activeModalWidget() is not None
                             or QApplication.activePopupWidget() is not None
                             or QApplication.mouseButtons() != Qt.NoButton)
                except Exception:
                    _busy = False
                if _busy:
                    if _tries < 1200:                        # 0.5 วิ × 1200 = 10 นาที
                        QTimer.singleShot(500, lambda: _do(_tries + 1))
                    else:
                        _say(f"ติดตั้ง {zver} แล้ว แต่ยังโหลดใหม่ไม่ได้ (มีหน้าต่างเปิดค้าง) — กรุณาปิด QGIS และเปิดใหม่")
                    return
                _old_obj = (getattr(_qu, "plugins", None) or {}).get(name)
                why = ""
                try:
                    if _old_obj is not None and hasattr(_old_obj, "_reload_blocker"):
                        why = _old_obj._reload_blocker() or ""
                except Exception:
                    why = ""
                if why:
                    _old_obj = None
                    _say(f"ติดตั้ง {zver} แล้ว แต่ยังไม่โหลดใหม่ — {why} · กรุณาปิด QGIS และเปิดใหม่")
                    return
                try:
                    _reopen = bool(_old_obj is not None and _old_obj.dlg is not None and _old_obj.dlg.isVisible())
                except Exception:
                    _reopen = False
                was_active = name in (getattr(_qu, "active_plugins", None) or [])
                _ret = _qu.reloadPlugin(name)
                _new_obj = (getattr(_qu, "plugins", None) or {}).get(name)
                _now_active = name in (getattr(_qu, "active_plugins", None) or [])
                _ok = _now_active and _new_obj is not None and _new_obj is not _old_obj
                _old_obj = None
                if _ok:
                    if _reopen and hasattr(_new_obj, "open_dialog"):
                        QTimer.singleShot(0, _new_obj.open_dialog)
                    return
                _log_info("โหลดปลั๊กอินใหม่หลังอัปเดต %s ไม่สำเร็จ — reloadPlugin คืน %r · ก่อนหน้าเปิดอยู่ %s · "
                          "ตอนนี้เปิดอยู่ %s" % (zver, _ret, was_active, _now_active))
                if not was_active or _now_active:
                    _say(f"ติดตั้ง {zver} แล้ว แต่โหลดใหม่เองไม่สำเร็จ — กรุณาปิด QGIS แล้วเปิดใหม่")
                    return
                back, detail = _rollback_failed_update(plugins_dir, name)
                try:
                    _debris = _debris_clear(_iface)
                except Exception:
                    _debris = -1
                detail = "%s · เก็บของค้างของรุ่นที่ล้ม %s ชิ้น" % (detail, _debris)
                started = False
                if back:
                    try:
                        _qu._unloadPluginModules(name)
                    except Exception:
                        pass
                    _ld = _st = None
                    try:
                        _ld = _qu.loadPlugin(name)
                        if _ld is not False:
                            _st = _qu.startPlugin(name)
                    except Exception as _e:
                        _st = type(_e).__name__
                    started = name in (getattr(_qu, "active_plugins", None) or [])
                    detail = "%s · loadPlugin คืน %r · startPlugin คืน %r" % (detail, _ld, _st)
                _log_info("อัปเดต %s โหลดไม่ขึ้น — คืนรุ่นเดิม: %s · เปิดรุ่นเดิม: %s · %s" % (zver, back, started, detail),
                          Qgis.Critical)
                if back and started:
                    _say(f"รุ่น {zver} โหลดไม่ขึ้น — คืนรุ่นเดิมให้แล้ว ใช้งานต่อได้ (แจ้งผู้ดูแล)", level=1)
                elif back:
                    _say(f"รุ่น {zver} โหลดไม่ขึ้น — คืนไฟล์รุ่นเดิมแล้ว กรุณาปิด QGIS แล้วเปิดใหม่ (แจ้งผู้ดูแล)", level=2)
                else:
                    _say(f"รุ่น {zver} โหลดไม่ขึ้น และคืนรุ่นเดิมไม่ได้ — กรุณาปิด QGIS แล้วแจ้งผู้ดูแล ({LOG_HINT})", level=2)
            except Exception as e:
                _log_info("reloadPlugin ล้ม — %r" % (e,), Qgis.Warning)
                _say(f"ติดตั้ง {zver} แล้ว แต่โหลดใหม่เองไม่สำเร็จ — กรุณาปิด QGIS แล้วเปิดใหม่")
        QTimer.singleShot(300, _do)
