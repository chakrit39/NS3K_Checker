# -*- coding: utf-8 -*-
def classFactory(iface):
    from .main import NS3KChecker
    return NS3KChecker(iface)
