# -*- coding: utf-8 -*-
"""
NS3K Checker — QGIS plugin ตรวจ นส.3ก ↔ โฉนด (หน้าต่างแบบ Multi-Layer Edit Pro) · แทน NS3K Match Checker
- 🔗 ตรวจสอบการจับคู่: คลิกแปลง นส.3ก -> ระบายสีโฉนดที่จับคู่ (อ่าน MATCH_SEQS ที่ pipeline คำนวณไว้) ทั้งกลุ่มแปลงที่ติดกัน
- 🔍 ค้นหาภาพลักษณ์ / 📐 หลักฐานการรังวัด: คลิกแปลงในชั้น UTM -> เปิดเอกสารจากระบบกรม (ยกจาก MLEP)
- 🔎 ไปที่แปลง นส.3ก ตามลำดับที่รูปแปลง (MAP_SEQ)
- อัปเดตตัวเองจาก GitHub (chakrit39/NS3K_Checker) + คีย์ลัดตั้งเองได้ (ค่าตั้งต้น Alt+1–4)
ต่อยอดจาก Multi-Layer Edit Pro (ชาคฤตย์ จันทรสุกศรี กองเทคโนโลยีทำแผนที่ กรมที่ดิน)
"""
import os
import re
from collections import Counter
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QColor
from qgis.core import (QgsCoordinateTransform, QgsFeatureRequest, QgsGeometry, QgsPointXY, QgsProject, QgsRectangle,
                       QgsVectorLayer, QgsVectorLayerFeatureSource, QgsWkbTypes)
from qgis.gui import QgsRubberBand

from .dol_ui import DolMixin
from .map_tools import ClickTool, PickTool, is_remote
from .shortcuts import ShortcutsMixin
from .updater import MENU, UpdateMixin, _FnWorker, _OWN_PROP, _read_version
from .util import _log_exc, _seq_str, _txt, _zone_crs, _zone_of

COL_NS3K = QColor(0, 120, 255)        # นส.3ก ที่คลิก
COL_NEIGH = QColor(140, 140, 190)     # นส.3ก แปลงข้างเคียง (ติดกัน)
COL_MATCH = QColor(0, 200, 0)         # โฉนดที่จับคู่
COL_CONFLICT = QColor(230, 20, 20)    # โฉนดที่จับซ้ำ (นส.3ก หลายแปลงจับโฉนดเดียวกัน = ผิด)
COL_GOTO = QColor(255, 200, 0)        # แปลงที่ไปถึงด้วย 🔎

_NS3K_NAME = re.compile(r"น\.?\s*ส\.?\s*3\s*ก|ns3k", re.I)
_UTM_NAME = re.compile(r"utm|โฉนด|chanote", re.I)
_UTM_KEYS = {"UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"}
_SEQ_FIELDS = ("MAP_SEQ", "MAP_PARCEL_SEQ")


def _remote_url(layer):
    """URL ชั้น ArcGIS ของกรม ถ้าชั้นนี้ดึงจากเซิร์ฟเวอร์ (arcgisfeatureserver) · ชั้นในเครื่อง = None"""
    if layer is None or not is_remote(layer):
        return None
    try:
        from qgis.core import QgsDataSourceUri
        return QgsDataSourceUri(layer.source()).param("url") or None
    except Exception:
        return None


class NS3KChecker(UpdateMixin, ShortcutsMixin, DolMixin):
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.version = _read_version()
        self.action = None
        self.dlg = None
        self.ns3k_cb = None
        self.utm_cb = None
        self.goto_ed = None
        self.status = None
        self.sc_hint = None
        self._buttons = {}
        self.tool = None
        self.rubbers = []
        self._goto_rb = None
        self._shortcuts = []
        self._net_workers = []
        self._alive = True
        self._updating = False
        self._auto_checked = False
        self._qgis_ready = False
        self._iso_layer = None      # ชั้น นส.3ก ที่ถูก isolate (ซ่อนแปลงอื่น)
        self._iso_orig = None       # subsetString เดิม ไว้คืนค่า
        self._match_gen = 0
        self._proj_conns = []
        self._refresh_timer = None

    # ======================= GUI =======================
    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        act = QtWidgets.QAction(QtGui.QIcon(icon_path), "NS3K Checker", self.iface.mainWindow())
        act.setObjectName("NS3KChecker_open")
        act.setToolTip("NS3K Checker — ตรวจ นส.3ก ↔ โฉนด · ค้นหาภาพลักษณ์ / หลักฐานการรังวัด")
        act.setProperty(_OWN_PROP, self._own_tok())
        act.triggered.connect(self.open_dialog)
        self.iface.addToolBarIcon(act)
        self.iface.addPluginToMenu(MENU, act)
        self.action = act
        self._apply_default_shortcuts()
        self._load_shortcuts()
        try:
            self.iface.initializationCompleted.connect(self._on_qgis_ready)
        except Exception:
            pass
        try:
            if self.iface.mainWindow().isVisible():         # เปิดปลั๊กอินกลาง session (QGIS เปิดเสร็จไปแล้ว)
                QTimer.singleShot(0, self._on_qgis_ready)
        except Exception:
            pass
        QTimer.singleShot(4000, self._maybe_auto_check_update)

    def unload(self):
        self._alive = False
        try:
            self.iface.initializationCompleted.disconnect(self._on_qgis_ready)
        except Exception:
            pass
        try:
            if isinstance(self.canvas.mapTool(), (PickTool, ClickTool)):
                self.iface.actionPan().trigger()
        except Exception:
            pass
        self._restore_ns3k()
        self._clear_rubbers()
        self._clear_goto()
        self._dol_clear_highlight()
        for sig, slot in self._proj_conns:
            try:
                sig.disconnect(slot)
            except Exception:
                pass
        self._proj_conns = []
        from .updater import _qobj_dispose
        for sc in self._shortcuts:
            _qobj_dispose(sc)
        self._shortcuts = []
        if self.action is not None:
            try:
                self.iface.removeToolBarIcon(self.action)
                self.iface.removePluginMenu(MENU, self.action)
            except Exception:
                pass
            _qobj_dispose(self.action)
            self.action = None
        if self.dlg is not None:
            try:
                self.dlg.close()
                self.dlg.deleteLater()
            except Exception:
                pass
            self.dlg = None

    # ---------- หน้าต่างหลัก (แบบ MLEP) ----------
    def open_dialog(self):
        if self.dlg is None:
            self.create_dialog()
        self.refresh_layers()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()

    run = open_dialog

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        self.dlg.setWindowIcon(QtGui.QIcon(os.path.join(os.path.dirname(__file__), "icon.png")))
        self.dlg.setWindowTitle(f"NS3K Checker {self.version}")
        self.dlg.setMinimumWidth(370)
        self._dlg_keys = self._main_key_filter()
        self.dlg.installEventFilter(self._dlg_keys)
        root = QtWidgets.QVBoxLayout(self.dlg)
        root.setSpacing(6)

        def mkbtn(text, slot, style="", tip="", h=34):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            b.setFixedHeight(h)
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(lambda *_a, _s=slot: _s())
            b.setAutoDefault(False)      # Enter ตอนโฟกัสอยู่ห้ามกดปุ่มซ้ำ
            b.setDefault(False)
            return b

        # ---------- ชั้นข้อมูล ----------
        grp = QtWidgets.QGroupBox("ชั้นข้อมูล")
        grp.setStyleSheet("QGroupBox::title{background:transparent;}")
        gl = QtWidgets.QGridLayout(grp)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(1, 1)
        self.ns3k_cb = QtWidgets.QComboBox()
        self.utm_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("นส.3ก:"), 0, 0)
        gl.addWidget(self.ns3k_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("UTM:"), 1, 0)
        gl.addWidget(self.utm_cb, 1, 1)
        br = mkbtn("🔄", self.refresh_layers, tip="โหลดรายชื่อชั้นข้อมูลใหม่ (เลือกชั้น นส.3ก / ชั้น UTM อัตโนมัติ)")
        br.setFixedWidth(36)
        gl.addWidget(br, 0, 2, 2, 1)
        self.goto_ed = QtWidgets.QLineEdit()
        self.goto_ed.setPlaceholderText("ลำดับที่รูปแปลง นส.3ก (MAP_SEQ)")
        self.goto_ed.returnPressed.connect(self.goto_ns3k)
        gl.addWidget(QtWidgets.QLabel("ไปที่:"), 2, 0)
        gl.addWidget(self.goto_ed, 2, 1)
        bg = mkbtn("🔎", self.goto_ns3k, tip="ซูมไปที่แปลง นส.3ก ตามลำดับที่รูปแปลงที่พิมพ์ (Enter)")
        bg.setFixedWidth(36)
        gl.addWidget(bg, 2, 2)
        root.addWidget(grp)

        # ---------- ปุ่มหลัก ----------
        self._buttons["match"] = mkbtn(
            "🔗 ตรวจสอบการจับคู่", self.start_match,
            "background-color:#e8f5e9; font-weight:bold; color:#1b5e20; padding:8px;",
            "คลิกแปลง นส.3ก → ระบายสีโฉนดที่จับคู่ทั้งกลุ่มแปลงที่ติดกัน\nEsc = คืนแปลงครบ (คลิกแปลงถัดไปได้เลย)", h=38)
        root.addWidget(self._buttons["match"])
        r = QtWidgets.QHBoxLayout()
        self._buttons["image"] = mkbtn(
            "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image'),
            "background-color:#fff3e0; font-weight:bold; padding:8px 4px; color:#e65100;",
            "คลิกแปลงในชั้น UTM — เปิดภาพสแกนโฉนดของแปลงนั้นจากระบบกรม")
        self._buttons["survey"] = mkbtn(
            "📐 หลักฐานการรังวัด", lambda: self.start_dol_search('survey'),
            "background-color:#e3f2fd; font-weight:bold; padding:8px 4px; color:#0d47a1;",
            "คลิกแปลงในชั้น UTM — เปิดหลักฐานการรังวัดของแปลงนั้นจากระบบกรม (ต้องเข้าสู่ระบบกรมก่อน)")
        _w = max(self._buttons[k].sizeHint().width() for k in ("image", "survey"))
        for k in ("image", "survey"):
            self._buttons[k].setMinimumWidth(_w)
            r.addWidget(self._buttons[k], 1)
        root.addLayout(r)
        self._buttons["clear"] = mkbtn("❌ ล้างไฮไลต์", self.clear, tip="ล้างสี/ไฮไลต์ทั้งหมด และคืนแปลง นส.3ก ที่ถูกซ่อน")
        root.addWidget(self._buttons["clear"])

        # ---------- สถานะ ----------
        self.status = QtWidgets.QLabel("พร้อมใช้งาน — กด \"ตรวจสอบการจับคู่\" แล้วคลิกแปลง นส.3ก หรือ "
                                       "\"ค้นหาภาพลักษณ์\" แล้วคลิกแปลงในชั้น UTM")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color:#222; padding:6px; background:#f5f5f5; border:1px solid #ddd; border-radius:3px;")
        self.status.setMinimumHeight(46)
        root.addWidget(self.status)
        f8 = QtGui.QFont()
        f8.setPointSize(8)
        lg = QtWidgets.QLabel("🟩 โฉนดที่จับคู่   🟥 โฉนดจับซ้ำ   🟦 นส.3ก ที่คลิก   🟪 นส.3ก ข้างเคียง")
        lg.setStyleSheet("color:#666;")
        lg.setFont(f8)
        root.addWidget(lg)
        self.sc_hint = QtWidgets.QLabel("")
        self.sc_hint.setStyleSheet("color:#666;")
        self.sc_hint.setFont(f8)
        self.sc_hint.setWordWrap(True)
        root.addWidget(self.sc_hint)

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        rf = QtWidgets.QHBoxLayout()
        rf.addWidget(mkbtn("⌨ ตั้งค่า Shortcut", self.open_shortcut_settings, tip="ตั้งปุ่มลัดของเครื่องมือแต่ละตัวเอง"), 1)
        rf.addWidget(mkbtn("🚀 Check Update", self.update_plugin,
                           tip="ตรวจว่ามีปลั๊กอินรุ่นใหม่ไหม — ถ้ามีจะติดตั้งให้ แล้วโหลดรุ่นใหม่ให้เองโดยไม่ต้องปิด-เปิด QGIS"), 1)
        root.addLayout(rf)
        author = QtWidgets.QLabel(f"v{self.version} · ต่อยอดจาก Multi-Layer Edit Pro\n"
                                  "ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        author.setAlignment(Qt.AlignCenter)
        author.setFont(f8)
        root.addWidget(author)
        self._apply_sc_hints()

        # รีเฟรชรายชื่อชั้นอัตโนมัติเมื่อโปรเจกต์เพิ่ม/ลบชั้น (รวบหลายสัญญาณเป็นครั้งเดียว)
        self._refresh_timer = QTimer(self.dlg)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.setInterval(250)
        self._refresh_timer.timeout.connect(self.refresh_layers)
        proj = QgsProject.instance()
        for sig in (proj.layersAdded, proj.layersRemoved):
            slot = lambda *_a: self._refresh_timer.start() if self._alive else None      # noqa: E731
            try:
                sig.connect(slot)
                self._proj_conns.append((sig, slot))
            except Exception:
                pass
        try:
            proj.layersWillBeRemoved.connect(self._on_layers_will_be_removed)
            self._proj_conns.append((proj.layersWillBeRemoved, self._on_layers_will_be_removed))
        except Exception:
            pass

    def _main_key_filter(self):
        """Esc = เลิกเครื่องมือของปลั๊กอินที่ค้างบนแคนวาส (ไม่ปิดแผง) · Enter = กินทิ้ง
        (ช่อง "ไปที่" ทำงานผ่าน returnPressed ของตัวเองแล้ว — Enter ที่ช่องนั้นปล่อยต่อขึ้นมาถึงแผง ห้ามเรียกซ้ำ)"""
        plugin = self

        class _MainKeys(QtCore.QObject):
            def eventFilter(self, obj, ev):
                try:
                    if ev.type() == QtCore.QEvent.KeyPress:
                        k = ev.key()
                        if k == Qt.Key_Escape:
                            if isinstance(plugin.canvas.mapTool(), (PickTool, ClickTool)):
                                plugin.iface.actionSelect().trigger()
                            return True
                        if k in (Qt.Key_Return, Qt.Key_Enter):
                            return True
                except Exception:
                    pass
                return False
        return _MainKeys(self.dlg)

    def _shortcut_actions(self):
        """รายการที่ตั้งคีย์ลัดได้: (id, ป้าย, callable)"""
        return [
            ("match", "🔗 ตรวจสอบการจับคู่", self.start_match),
            ("image", "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image')),
            ("survey", "📐 หลักฐานการรังวัด", lambda: self.start_dol_search('survey')),
            ("clear", "❌ ล้างไฮไลต์", self.clear),
            ("panel", "🪟 เปิดหน้าต่าง NS3K Checker", self.open_dialog),
        ]

    def _sc_fired(self, slot):
        """กดคีย์ลัด = ทางเดียวกับคลิกปุ่ม · ยังไม่เคยเปิดหน้าต่าง ⇒ เปิดให้ก่อน (สถานะ/ชั้นข้อมูลอยู่ในหน้าต่าง)"""
        if not self._alive:
            return
        try:
            if self.dlg is None or not self.dlg.isVisible():
                self.open_dialog()
            slot()
        except Exception:
            _log_exc("คีย์ลัด: ทำงานไม่สำเร็จ")

    def _apply_sc_hints(self):
        """ป้ายคีย์ลัดบนปุ่ม (tooltip) + บรรทัดสรุปคีย์ลัดในหน้าต่าง"""
        if self.dlg is None:
            return
        parts = []
        for aid, label, _s in self._shortcut_actions():
            key = self._sc_value(aid)
            b = self._buttons.get(aid)
            if b is not None:
                tip = b.toolTip().split("\n⌨")[0]
                b.setToolTip(tip + (f"\n⌨ คีย์ลัด: {key}" if key else ""))
            if key and aid in ("match", "image", "survey", "clear"):
                parts.append(f"{key} {label.split(' ', 1)[1]}")
        if self.sc_hint is not None:
            self.sc_hint.setText(("⌨ " + " · ".join(parts)) if parts else "⌨ ยังไม่ได้ตั้งคีย์ลัด")

    # ======================= ชั้นข้อมูล =======================
    def _vector_polys(self):
        out = []
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == QgsWkbTypes.PolygonGeometry:
                    out.append(lyr)
            except Exception:
                continue
        return out

    @staticmethod
    def _fset(lyr):
        try:
            return {f.name().upper() for f in lyr.fields()}
        except Exception:
            return set()

    def _score_ns3k(self, lyr):
        fs = self._fset(lyr)
        if "STATUS" in fs and ("MATCH_SEQS" in fs or "MATCH_SEQ" in fs):
            return 3
        if _NS3K_NAME.search(lyr.name()):
            return 2
        if "UTMMAP1" in fs and "UTMMAP3" not in fs and fs & set(_SEQ_FIELDS):   # ชั้น นส.3ก ของกรมไม่มี UTMMAP3
            return 1
        return 0

    def _score_utm(self, lyr):
        fs = self._fset(lyr)
        if "MATCH_SEQ" in fs or "STATUS" in fs or _NS3K_NAME.search(lyr.name()):
            return 0
        keys = _UTM_KEYS <= fs and ("LANDNO" in fs or "LAND_NO" in fs)
        named = bool(_UTM_NAME.search(lyr.name()))
        return 3 if (keys and named) else 2 if keys else 1 if named else 0

    def _best(self, score):
        best, bs = None, 0
        for lyr in self._vector_polys():
            s = score(lyr)
            if s > bs:
                best, bs = lyr, s
        return best

    def refresh_layers(self):
        if self.dlg is None or not self._alive:
            return
        for cb, score in ((self.ns3k_cb, self._score_ns3k), (self.utm_cb, self._score_utm)):
            det = self._best(score)
            cb.blockSignals(True)
            cur = cb.currentData()
            cb.clear()
            sel = -1
            polys = self._vector_polys()
            for i, lyr in enumerate(polys):
                cb.addItem(lyr.name(), lyr.id())
                if cur and lyr.id() == cur:
                    sel = i
            if sel < 0 and det is not None:
                sel = cb.findData(det.id())
            cb.setCurrentIndex(max(sel, 0) if polys else -1)
            cb.blockSignals(False)

    def _sel_layer(self, cb, score):
        if self.dlg is not None and cb is not None and cb.currentData():
            lyr = QgsProject.instance().mapLayer(cb.currentData())
            if isinstance(lyr, QgsVectorLayer):
                return lyr
        return self._best(score)

    def _sel_ns3k(self):
        return self._sel_layer(self.ns3k_cb, self._score_ns3k)

    def _sel_utm(self):
        return self._sel_layer(self.utm_cb, self._score_utm)

    def _on_layers_will_be_removed(self, ids):
        try:
            if self._iso_layer is not None and self._iso_layer.id() in ids:
                self._restore_ns3k()
        except RuntimeError:
            self._iso_layer, self._iso_orig = None, None

    # ======================= ตัวช่วย =======================
    def _set_status(self, text):
        if self.status is not None:
            try:
                self.status.setText(text)
            except RuntimeError:
                pass

    def _msg(self, text, level=0, dur=6):
        self.iface.messageBar().pushMessage("NS3K Checker", text, level=level, duration=dur)

    def _warn(self, text):
        self._set_status("⚠ " + text)
        self._msg(text, 1)

    def _ask(self, icon, title, text, buttons=None, default=None):
        """QMessageBox ผูกกับหน้าต่างหลักของ QGIS แล้วยกขึ้นหน้าสุด (กล่อง modal ที่ถูกบัง = ดูเหมือนโปรแกรมค้าง)"""
        if buttons is None:
            buttons = (QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                       if icon == QtWidgets.QMessageBox.Question else QtWidgets.QMessageBox.Ok)
        box = QtWidgets.QMessageBox(icon, title, text, buttons, self.iface.mainWindow())
        if default is not None:
            box.setDefaultButton(default)
        try:
            box.setWindowModality(Qt.ApplicationModal)
            box.show()
            box.raise_()
            box.activateWindow()
        except Exception:
            pass
        try:
            return box.exec_()
        finally:
            try:
                box.deleteLater()
            except Exception:
                pass

    def _gesture_busy(self):
        try:
            return QtWidgets.QApplication.mouseButtons() != Qt.NoButton
        except Exception:
            return False

    def _run_net(self, msg, fn, on_done, on_fail, req=None):
        """รัน fn (blocking network) ใน QThread + กล่องรอ · on_done/on_fail ถูกเรียกบน main thread
        req = คำขอ DOL ที่งานนี้เป็นขั้นหนึ่ง: กล่องรอมีปุ่ม "ยกเลิก" · ผลของคำขอที่ถูกยกเลิก/เก่าแล้วถูกทิ้ง"""
        busy = QtWidgets.QProgressDialog(msg, None, 0, 0, self._msg_parent())
        busy.setWindowTitle("NS3K Checker")
        busy.setCancelButton(None)
        busy.setWindowModality(Qt.WindowModal)
        busy.setMinimumDuration(0)
        if req is not None:
            self._dol_wait_arm(busy, req)
        busy.show()
        w = self._track_worker(_FnWorker(fn))

        def _cleanup():
            try:
                busy.close()
                busy.deleteLater()
            except Exception:
                pass

        def _live():
            # ตัดสินก่อนปิดกล่อง: close() ยิง canceled ⇒ ถ้ายังนับว่ารออยู่จะกลายเป็น "ยกเลิก"
            return True if req is None else self._dol_step_done(req)

        def _ok(res):
            live = _live()
            _cleanup()
            if live and self._alive:
                on_done(res)

        def _err(e):
            live = _live()
            _cleanup()
            if live and self._alive:
                on_fail(e)
        w.done.connect(_ok)
        w.fail.connect(_err)
        w.start()

    def _hl(self, geom, layer_or_crs, color, width=2, fill=60, dash=False):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(color)
        c = QColor(color)
        c.setAlpha(fill)
        rb.setFillColor(c)
        rb.setWidth(width)
        if dash:
            rb.setLineStyle(Qt.DashLine)
        rb.setToGeometry(geom, layer_or_crs)
        self.rubbers.append(rb)

    def _clear_rubbers(self):
        for rb in self.rubbers:
            try:
                self.canvas.scene().removeItem(rb)
            except Exception:
                pass
        self.rubbers = []

    def _clear_goto(self):
        if self._goto_rb is not None:
            try:
                self.canvas.scene().removeItem(self._goto_rb)
            except Exception:
                pass
            self._goto_rb = None

    @staticmethod
    def _seq_field(layer):
        names = {f.name().upper(): f.name() for f in layer.fields()}
        for k in _SEQ_FIELDS:
            if k in names:
                return names[k]
        return None

    def _seq_expr(self, layer, seqs):
        """นิพจน์กรองแปลงตามเลขแปลงในแผนที่ — ช่องตัวเลข (ชั้นของกรม) ไม่ใส่เครื่องหมายคำพูด"""
        fld = self._seq_field(layer)
        if not fld or not seqs:
            return None
        f = layer.fields().field(fld)
        if f.isNumeric():
            vals = [s for s in seqs if str(s).isdigit()]
            inlist = ",".join(vals)
        else:
            inlist = ",".join("'%s'" % str(s).replace("'", "''") for s in seqs)
        if not inlist:
            return None
        return '"%s" IN (%s)' % (fld, inlist)

    def _isolate_ns3k(self, layer, seqs):
        """ซ่อนแปลง นส.3ก อื่น เหลือเฉพาะ seqs — คืนค่าได้ (_restore_ns3k)"""
        seqs = [str(s) for s in (seqs or []) if s]
        expr = self._seq_expr(layer, seqs)
        if not expr:
            return
        if self._iso_layer is None:
            self._iso_layer = layer
            self._iso_orig = layer.subsetString()
        try:
            layer.setSubsetString(expr)
        except Exception:
            pass

    def _restore_ns3k(self):
        if self._iso_layer is not None:
            try:
                self._iso_layer.setSubsetString(self._iso_orig or "")
            except Exception:
                pass
            self._iso_layer = None
            self._iso_orig = None

    def clear(self):
        self._match_gen += 1
        self._restore_ns3k()
        self._clear_rubbers()
        self._clear_goto()
        self._dol_clear_highlight()
        ch = self._sel_utm()
        if ch is not None:
            try:
                ch.removeSelection()
            except Exception:
                pass
        self._set_status("ล้างไฮไลต์แล้ว — แสดงแปลง นส.3ก ครบแล้ว")

    def _cancel(self):
        # Esc ในโหมดตรวจจับคู่: คืนแปลง นส.3ก ครบ + ล้างไฮไลต์ แต่ "คงเครื่องมือไว้" -> คลิกแปลงถัดไปได้เลย
        self.clear()
        self._set_status("คืนแปลง นส.3ก ครบแล้ว — คลิกแปลงถัดไปได้เลย (ยังอยู่ในโหมดตรวจจับคู่)")

    def _feature_at(self, layer, point):
        try:
            p = QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(), layer.crs(),
                                       QgsProject.instance()).transform(point)
        except Exception:
            p = point
        tol = self.canvas.mapUnitsPerPixel() * 4
        rect = QgsRectangle(p.x() - tol, p.y() - tol, p.x() + tol, p.y() + tol)
        pg = QgsGeometry.fromPointXY(QgsPointXY(p))
        fb = None
        for f in layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            if g.contains(pg):
                return f
            if fb is None:
                fb = f
        return fb

    # ======================= 🔗 ตรวจสอบการจับคู่ =======================
    def start_match(self):
        ns3k = self._sel_ns3k()
        if ns3k is None:
            self._warn("ไม่พบชั้น นส.3ก — เลือกชั้นที่ช่อง \"นส.3ก\" ในหน้าต่าง NS3K Checker")
            return
        fs = self._fset(ns3k)
        if "MATCH_SEQS" not in fs and "MATCH_SEQ" not in fs:
            self._ask(QtWidgets.QMessageBox.Information, "ไม่มีผลจับคู่",
                      f"ชั้น '{ns3k.name()}' ไม่มีผลการจับคู่ (ช่อง MATCH_SEQS) — ปุ่มนี้ใช้กับชั้น นส.3ก จาก pipeline "
                      "(โปรเจคแบบผสม)\n\nปุ่ม 🔍 ค้นหาภาพลักษณ์ / 📐 หลักฐานการรังวัด ยังใช้ได้ตามปกติ")
            return
        self.tool = ClickTool(self.canvas, self._on_match_click, on_cancel=self._cancel, on_deactivate=self._restore_ns3k)
        self.canvas.setMapTool(self.tool)
        self._set_status("🔗 คลิกแปลง นส.3ก บนแผนที่... (Esc = คืนทุกแปลง แล้วคลิกแปลงถัดไปได้เลย)")
        self._msg("คลิกแปลง นส.3ก เพื่อดูโฉนดที่จับคู่ · Esc = คืนทุกแปลง (คลิกต่อได้เลย)", 0)

    @staticmethod
    def _match_list(feat, fs):
        """seq โฉนดที่จับคู่ (อ่าน MATCH_SEQS ที่คำนวณไว้ — ไม่คำนวณใหม่; fallback MATCH_SEQ)"""
        seqs = []
        if "MATCH_SEQS" in fs and _txt(feat["MATCH_SEQS"]):
            seqs = [_seq_str(s) for s in _txt(feat["MATCH_SEQS"]).split(",")]
        if not seqs and "MATCH_SEQ" in fs and _txt(feat["MATCH_SEQ"]):
            seqs = [_seq_str(feat["MATCH_SEQ"])]
        return [s for s in seqs if s]

    def _touching_group(self, layer, f, fs, seq_fld):
        """กลุ่ม นส.3ก ที่ติดกัน (f + แปลงที่ touch/ใกล้ f) -> list ของ (feat, seq, match_list)"""
        g = f.geometry()
        bb = g.boundingBox()
        bb.grow(2.0)
        out, seen = [], set()
        for nf in layer.getFeatures(QgsFeatureRequest().setFilterRect(bb)):
            if nf.id() in seen:
                continue
            ng = nf.geometry()
            if not ng or ng.isEmpty():
                continue
            if nf.id() == f.id() or ng.distance(g) < 0.5 or ng.intersects(g):
                seen.add(nf.id())
                out.append((nf, _seq_str(nf[seq_fld]) if seq_fld else "", self._match_list(nf, fs)))
        return out

    def _on_match_click(self, point):
        ns3k = self._sel_ns3k()
        if ns3k is None:
            return
        f = self._feature_at(ns3k, point)
        if not f:
            self._set_status("ไม่พบแปลง นส.3ก ตรงจุดที่คลิก")
            return
        self._match_gen += 1
        gen = self._match_gen
        self._clear_rubbers()
        self._restore_ns3k()
        fs = {n: n for n in (fl.name() for fl in ns3k.fields())}
        fsu = {n.upper(): n for n in fs}
        fs_names = set(fs)
        seq_fld = self._seq_field(ns3k)
        a_seq = _seq_str(f[seq_fld]) if seq_fld else ""
        a_status = _txt(f[fsu["STATUS"]]) if "STATUS" in fsu else ""
        a_match = self._match_list(f, fs_names)
        if not a_match:
            self._hl(f.geometry(), ns3k, COL_NS3K, width=3, fill=0)
            self.canvas.refresh()
            self._ask(QtWidgets.QMessageBox.Warning, "จับคู่โฉนดไม่ได้",
                      f"แปลง นส.3ก นี้จับคู่โฉนดไม่ได้\n\nลำดับที่รูปแปลง: {a_seq or '-'}\nสถานะ: {a_status or 'ไม่ทราบ'}")
            self._set_status(f"⚠ จับคู่โฉนดไม่ได้ — {a_status} (ไม่ซ่อนแปลงอื่น)")
            return
        # กลุ่ม นส.3ก ที่ติดกัน + นับโฉนดจับซ้ำ (นส.3ก ไม่ควรจับคู่โฉนดเดียวกัน)
        group = self._touching_group(ns3k, f, fs_names, seq_fld)
        cnt = Counter()
        for _f, _s, ml in group:
            for s in set(ml):
                cnt[s] += 1
        dup = {s for s, c in cnt.items() if c >= 2}
        want = set()
        for _f, _s, ml in group:
            want.update(ml)
        self._isolate_ns3k(ns3k, [gs for _f, gs, _m in group if gs])
        for feat, gs, _m in group:
            self._hl(feat.geometry(), ns3k, COL_NS3K if gs == a_seq else COL_NEIGH,
                     width=3 if gs == a_seq else 2, fill=0)
        self.canvas.refresh()
        chanote = self._sel_utm()
        if chanote is None:
            self._set_status(f"กลุ่ม นส.3ก {len(group)} แปลง — ไม่พบชั้น UTM ให้ระบายสีโฉนด")
            return
        ch_fld = self._seq_field(chanote)
        if not ch_fld:
            self._set_status("ชั้น UTM ไม่มีช่องเลขแปลง (MAP_SEQ / MAP_PARCEL_SEQ) — ระบายสีโฉนดไม่ได้")
            return
        self._set_status(f"กำลังโหลดโฉนดที่จับคู่ {len(want)} แปลง...")
        zone = _zone_of(chanote)
        # ชั้นของกรมผ่านเน็ต ⇒ ถามเซิร์ฟเวอร์ตรงด้วยเลขแปลง (มีดัชนี ~1 วิ) — ดึงผ่านชั้นของ QGIS ช้ามาก (~14 วิ)
        # ชั้นในเครื่อง (GPKG) ⇒ ดึงรอบกลุ่มแล้วกรองตามเลขแปลงเอง · ที่ไม่อยู่ในชั้น ⇒ ดึงจากแผนที่กรม (เส้นประ)
        remote_url = _remote_url(chanote)
        src = ch_idx = rect = None
        if not remote_url:
            rect = QgsRectangle(f.geometry().boundingBox())
            for feat, _gs, _m in group:
                rect.combineExtentWith(feat.geometry().boundingBox())
            try:
                if chanote.crs() != ns3k.crs():
                    rect = QgsCoordinateTransform(ns3k.crs(), chanote.crs(), QgsProject.instance()).transformBoundingBox(rect)
            except Exception:
                pass
            rect.grow(400.0)
            src = QgsVectorLayerFeatureSource(chanote)
            ch_idx = chanote.fields().indexOf(ch_fld)

        def _fetch():
            out = []
            if src is not None:
                req = QgsFeatureRequest().setFilterRect(rect).setSubsetOfAttributes([ch_idx])
                for cf in src.getFeatures(req):
                    cs = _seq_str(cf.attribute(ch_idx))
                    if cs in want:
                        out.append((cf.id(), cs, QgsGeometry(cf.geometry())))
            extra = []
            missing = want - {cs for _i, cs, _g in out}
            if missing:
                from . import dol_api
                for s, d in dol_api.fetch_parcels_by_seq(missing, zone=zone, first_url=remote_url).items():
                    wkt = dol_api.esri_rings_wkt(d.get("rings"))
                    g = QgsGeometry.fromWkt(wkt) if wkt else None
                    if g is not None and not g.isEmpty():
                        extra.append((s, g, bool(remote_url) and d.get("src") == remote_url.rstrip("/")))
            return out, extra

        def _done(res):
            if gen != self._match_gen or not self._alive:
                return                       # คลิกแปลงอื่น/ล้างไปแล้ว — ทิ้งผลเก่า
            items, extra = res
            ids = []
            for fid, cs, geom in items:
                is_dup = cs in dup
                self._hl(geom, chanote, COL_CONFLICT if is_dup else COL_MATCH,
                         width=3 if is_dup else 2, fill=115 if is_dup else 85)
                ids.append(fid)
            zcrs = _zone_crs(zone)
            n_out = 0
            for cs, geom, in_layer in extra:
                is_dup = cs in dup
                if in_layer:
                    self._hl(geom, zcrs, COL_CONFLICT if is_dup else COL_MATCH,
                             width=3 if is_dup else 2, fill=115 if is_dup else 85)
                else:
                    n_out += 1
                    self._hl(geom, zcrs, COL_CONFLICT if is_dup else COL_MATCH, width=2, fill=60, dash=True)
            if src is not None:
                try:
                    chanote.removeSelection()
                    chanote.selectByIds(ids)
                except Exception:
                    pass
            self.canvas.refresh()
            n_ch = len(items) + len(extra)
            miss = len(want) - len({cs for _i, cs, _g in items} | {cs for cs, _g, _l in extra})
            tail = (f" · {n_out} แปลงอยู่นอกชั้น UTM (เส้นประ = ดึงจากแผนที่กรม)" if n_out else "") + \
                   (f" · ไม่พบในแผนที่กรม {miss} แปลง" if miss > 0 else "")
            if dup:
                self._set_status(f"⚠ พบโฉนดจับซ้ำ {len(dup)} แปลง (สีแดง)!\n"
                                 f"กลุ่ม นส.3ก {len(group)} แปลง(ติดกัน) ↔ โฉนด {n_ch} แปลง — นส.3ก จับคู่โฉนดเดียวกัน ตรวจสอบ"
                                 + tail)
            else:
                self._set_status(f"✅ ไม่มีโฉนดจับซ้ำ · {a_status}\n"
                                 f"กลุ่ม นส.3ก {len(group)} แปลง(ติดกัน) ↔ โฉนด {n_ch} แปลง (คนละโฉนด)" + tail)

        def _fail(e):
            if gen != self._match_gen or not self._alive:
                return
            _log_exc("ตรวจจับคู่: โหลดโฉนดไม่สำเร็จ")
            self._set_status("⚠ โหลดโฉนดจากชั้น UTM ไม่สำเร็จ (เครือข่ายกรม?) — ลองคลิกใหม่")
        w = self._track_worker(_FnWorker(_fetch))
        w.done.connect(_done)
        w.fail.connect(_fail)
        w.start()

    # ======================= 🔎 ไปที่แปลง นส.3ก =======================
    def goto_ns3k(self):
        if self.goto_ed is None:
            return
        txt = re.sub(r"\D", "", self.goto_ed.text() or "")
        if not txt:
            self._set_status("พิมพ์ลำดับที่รูปแปลง (MAP_SEQ) ของ นส.3ก ก่อน แล้วกด Enter")
            return
        ns3k = self._sel_ns3k()
        if ns3k is None:
            self._warn("ไม่พบชั้น นส.3ก")
            return
        expr = self._seq_expr(ns3k, [txt])
        if not expr:
            self._warn(f"ชั้น '{ns3k.name()}' ไม่มีช่องเลขแปลง (MAP_SEQ / MAP_PARCEL_SEQ)")
            return
        if self._iso_layer is ns3k:
            self._restore_ns3k()
            self._clear_rubbers()
        url = _remote_url(ns3k)
        if url:
            # ชั้นของกรมผ่านเน็ต ⇒ ถามเซิร์ฟเวอร์ตรงด้วยเลขแปลง (~1 วิ) — กรองผ่านชั้นของ QGIS ช้า (~14 วิ)
            zone = _zone_of(ns3k)
            self._set_status(f"กำลังค้นแปลง นส.3ก {txt} จากแผนที่กรม...")

            def _q():
                from . import dol_api
                rows = dol_api.query_parcels(url, f"MAP_PARCEL_SEQ={int(txt)}", zone)
                return dol_api.esri_rings_wkt(rows[0][1]) if rows else ""

            def _ok(wkt):
                if not self._alive:
                    return
                g = QgsGeometry.fromWkt(wkt) if wkt else None
                if g is None or g.isEmpty():
                    self._set_status(f"ไม่พบแปลง นส.3ก ลำดับที่รูปแปลง {txt} ในแผนที่กรม")
                    return
                self._goto_show(g, _zone_crs(zone), txt, "")
            w = self._track_worker(_FnWorker(_q))
            w.done.connect(_ok)
            w.fail.connect(lambda e: self._alive and self._set_status(f"⚠ ค้นแปลง {txt} จากแผนที่กรมไม่สำเร็จ"))
            w.start()
            return
        try:
            f = next(ns3k.getFeatures(QgsFeatureRequest().setFilterExpression(expr).setLimit(1)), None)
        except Exception:
            f = None
        if f is None or not f.hasGeometry():
            self._set_status(f"ไม่พบแปลง นส.3ก ลำดับที่รูปแปลง {txt} ในชั้น '{ns3k.name()}'")
            return
        i = ns3k.fields().indexOf("STATUS")
        self._goto_show(QgsGeometry(f.geometry()), ns3k.crs(), txt, _txt(f[i]) if i >= 0 else "")

    def _goto_show(self, g, crs, txt, status):
        """ซูมไปที่แปลง + กรอบเหลือง + กะพริบ"""
        try:
            tr = QgsCoordinateTransform(crs, self.canvas.mapSettings().destinationCrs(), QgsProject.instance())
            bb = tr.transformBoundingBox(g.boundingBox())
        except Exception:
            bb = g.boundingBox()
        bb.scale(3.0)
        self.canvas.setExtent(bb)
        self.canvas.refresh()
        self._clear_goto()
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(COL_GOTO)
        rb.setFillColor(QColor(255, 200, 0, 40))
        rb.setWidth(3)
        rb.setToGeometry(g, crs)
        self._goto_rb = rb
        try:
            self.canvas.flashGeometries([g], crs)
        except Exception:
            pass
        self._set_status(f"🔎 แปลง นส.3ก {txt}" + (f" · {status}" if status else "")
                         + "\nกด 🔗 แล้วคลิกแปลงเพื่อดูโฉนดที่จับคู่ หรือ 🔍 / 📐 แล้วคลิกโฉนดเพื่อเปิดเอกสาร")
