# -*- coding: utf-8 -*-
"""เครื่องมือบนแผนที่ของ NS3K Checker
- PickTool  : คลิกเลือกแปลง (ไฮไลต์แปลงใต้เมาส์ก่อนคลิก · แปลงซ้อน = ให้เลือก · Esc = เลิก) แบบ PolygonPickTool ของ MLEP
              ชั้นจากเซิร์ฟเวอร์ (ArcGIS ของกรม) ⇒ ดึงรูปแปลงในกรอบจอมาเก็บใน thread แยก แล้วตอบ hover/คลิกจากของในเครื่อง
              (ถามเซิร์ฟเวอร์ทุกครั้งที่เลื่อนเมาส์ = QGIS กระตุก)
- ClickTool : คลิกจุด (ตรวจการจับคู่) · Esc = callback (คืนแปลงครบ แต่คงเครื่องมือไว้)"""
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (Qgis, QgsCoordinateTransform, QgsFeature, QgsFeatureRequest, QgsGeometry, QgsPointXY,
                       QgsProject, QgsRectangle, QgsSpatialIndex, QgsVectorLayerFeatureSource)
from qgis.gui import QgsMapTool
from .util import _log_exc, _sheet_str

_REMOTE = ("arcgisfeatureserver", "wfs", "oapif")
_CACHE_MAX_SIDE = 12000.0       # ด้านยาวสุดของกรอบที่ดึงมาเก็บ (เมตร) — เกินนี้ = ซูมออกไกล ไม่ดึง (ชั้น UTM ไม่แสดงอยู่แล้ว)


def is_remote(layer):
    try:
        return layer.providerType() in _REMOTE
    except Exception:
        return False


class _CacheWorker(QtCore.QThread):
    """ดึงรูปแปลง (ไม่เอา attribute) ในกรอบหนึ่งจาก QgsVectorLayerFeatureSource ใน thread แยก
    🔑 source ต้องสร้างบน main thread · worker ต้องถูกถือไว้จน finished (ดู PickTool._keep)"""
    loaded = QtCore.pyqtSignal(int, object)      # (รุ่นของคำขอ, [(fid, QgsGeometry)] | None)

    def __init__(self, source, rect, gen):
        super().__init__()
        self._source, self._rect, self._gen = source, QgsRectangle(rect), gen

    def run(self):
        out = []
        try:
            req = QgsFeatureRequest().setFilterRect(self._rect).setNoAttributes()
            for f in self._source.getFeatures(req):
                g = f.geometry()
                if g is not None and not g.isEmpty():
                    out.append((f.id(), QgsGeometry(g)))
        except Exception:
            out = None
        self.loaded.emit(self._gen, out)


class PickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) · คลิก = click_cb(feature เต็ม, layer) · hover_cb(feature|None, layer)"""
    HOVER_MS = 80

    def __init__(self, iface, layer, click_cb, hover_cb, keeper, msg_title="NS3K Checker"):
        super().__init__(iface.mapCanvas())
        self._iface = iface
        self._canvas = iface.mapCanvas()
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._keeper = keeper           # ลิสต์ของปลั๊กอินที่ถือ QThread ไว้จนจบจริง (tool ถูกทิ้งได้ก่อน worker จบ)
        self._msg_title = msg_title
        self._remote = is_remote(layer)
        self._last_fid = None
        self._picked = False
        self._hint = None
        self.setCursor(QtCore.Qt.CrossCursor)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != self._canvas.mapSettings().destinationCrs():
            try:
                self._xform = QgsCoordinateTransform(self._canvas.mapSettings().destinationCrs(), layer.crs(), proj)
            except Exception:
                self._xform = None
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(self.HOVER_MS)
        self._hover_timer.timeout.connect(self._hover_tick)
        # แคชรูปแปลงในกรอบจอ (เฉพาะชั้นจากเซิร์ฟเวอร์)
        self._gen = 0
        self._cache_rect = None
        self._cache_geom = {}
        self._cache_index = None
        self._cache_timer = QtCore.QTimer(self)
        self._cache_timer.setSingleShot(True)
        self._cache_timer.setInterval(300)
        self._cache_timer.timeout.connect(self._cache_refresh)

    # ---------- ข้อความแนะนำของเครื่องมือ (ลบเฉพาะของตัวเองตอนเลิกใช้) ----------
    def push_hint(self, text, level=0):
        bar = self._iface.messageBar()
        self._pop_hint()
        try:
            item = bar.createMessage(self._msg_title, text)
            bar.pushWidget(item, Qgis.MessageLevel(level), 0)
            self._hint = item
        except Exception:
            _log_exc("PickTool: แสดงข้อความแนะนำไม่ได้", once_key="pick_hint")
            self._hint = None

    def _pop_hint(self):
        if self._hint is not None:
            try:
                self._iface.messageBar().popWidget(self._hint)
            except Exception:
                pass
            self._hint = None

    # ---------- แคชรูปแปลงในกรอบจอ ----------
    def activate(self):
        super().activate()
        if self._remote:
            self._watch_extent(True)
            self._cache_refresh()

    def _on_extent(self):
        self._cache_timer.start()

    def _watch_extent(self, on):
        if on == getattr(self, "_watching", False):
            return
        try:
            if on:
                self._canvas.extentsChanged.connect(self._on_extent)
            else:
                self._canvas.extentsChanged.disconnect(self._on_extent)
            self._watching = on
        except Exception:
            pass

    def _view_rect(self):
        rect = QgsRectangle(self._canvas.extent())
        rect.scale(1.15)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                return None
        return rect

    def _cache_refresh(self):
        rect = self._view_rect()
        self._gen += 1
        if rect is None or max(rect.width(), rect.height()) > _CACHE_MAX_SIDE:
            self._cache_rect, self._cache_geom, self._cache_index = None, {}, None
            return
        if self._cache_rect is not None and self._cache_rect.contains(rect):
            return
        try:
            src = QgsVectorLayerFeatureSource(self._layer)
        except Exception:
            _log_exc("PickTool: สร้าง feature source ไม่ได้", once_key="pick_source")
            return
        w = _CacheWorker(src, rect, self._gen)
        self._keeper.append(w)

        def _release(_w=w):
            try:
                self._keeper.remove(_w)
            except ValueError:
                pass
            _w.deleteLater()
        w.finished.connect(_release)
        w.loaded.connect(lambda gen, items, _r=QgsRectangle(rect): self._cache_loaded(gen, items, _r))
        w.start()

    def _cache_loaded(self, gen, items, rect):
        if gen != self._gen or items is None:
            return
        idx = QgsSpatialIndex()
        geoms = {}
        for fid, g in items:
            f = QgsFeature(fid)
            f.setGeometry(g)
            idx.addFeature(f)
            geoms[fid] = g
        self._cache_rect, self._cache_geom, self._cache_index = rect, geoms, idx

    def _cache_hits(self, pt, rect):
        """fid ของแปลงในแคชที่ครอบจุด pt (พิกัดชั้น) · แคชยังไม่พร้อม/ไม่คลุมจุด = None"""
        if self._cache_index is None or self._cache_rect is None or not self._cache_rect.contains(pt):
            return None
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        out = []
        for fid in self._cache_index.intersects(rect):
            g = self._cache_geom.get(fid)
            if g is not None and g.intersects(gp):
                out.append(fid)
        return out

    # ---------- หาแปลงใต้เมาส์ ----------
    def _pt_rect(self, pos, px=3):
        map_pt = self.toMapCoordinates(pos)
        tol = self._canvas.mapUnitsPerPixel() * px
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol, map_pt.x() + tol, map_pt.y() + tol)
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                return None, None
        return pt, rect

    def _feature_at_pos(self, pos):
        """แปลงใต้ตำแหน่ง pixel (hover) — ชั้นจากเซิร์ฟเวอร์ตอบจากแคชเท่านั้น (ไม่ถามเซิร์ฟเวอร์ทุก tick)"""
        pt, rect = self._pt_rect(pos)
        if pt is None:
            return None
        if self._remote:
            hits = self._cache_hits(pt, rect)
            if not hits:
                return None
            f = QgsFeature(hits[0])
            f.setGeometry(self._cache_geom[hits[0]])
            return f
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        it = self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(200))
        try:
            for f in it:
                if f.geometry().intersects(gp):
                    return f
        finally:
            it.close()
        return None

    def _features_at_pos(self, pos):
        """ทุกแปลงที่ครอบจุดคลิก (พร้อม attribute) เรียงพื้นที่เล็ก->ใหญ่ · แปลงพิกัดไม่ได้ = None"""
        pt, rect = self._pt_rect(pos)
        if pt is None:
            return None
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        out = []
        hits = self._cache_hits(pt, rect) if self._remote else None
        if hits is not None:
            for fid in hits:
                f = self._layer.getFeature(fid)
                if f is not None and f.isValid():
                    out.append(f)
        else:
            for f in self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
                g = f.geometry()
                if g is not None and not g.isNull() and g.intersects(gp):
                    out.append(f)
        try:
            out.sort(key=lambda ff: ff.geometry().area())
        except Exception:
            pass
        return out

    def _choose_parcel(self, feats):
        """แปลงซ้อนกัน >1 -> popup ให้เลือกตามระวาง/เลขที่ดิน ; คืน None ถ้ายกเลิก"""
        base = []
        for f in feats:
            gv = lambda *n, _f=f: _sheet_str(_f, *n)      # noqa: E731
            base.append(f"ระวาง {gv('UTMMAP1')} {gv('UTMMAP2')} {gv('UTMMAP3')}-{gv('UTMMAP4') or '00'}"
                        f"  |  มาตราส่วน {gv('UTMSCALE')}  |  เลขที่ดิน {gv('LANDNO', 'LAND_NO')}")
        labels = ["%s  (#%d)" % (l, i + 1) if base.count(l) > 1 else l for i, l in enumerate(base)]
        item, ok = QtWidgets.QInputDialog.getItem(
            self._iface.mainWindow(), "เลือกแปลง (มีแปลงซ้อนกัน)",
            f"จุดที่คลิกมี {len(feats)} แปลงซ้อนกัน — เลือกแปลงที่ต้องการค้นหา:", labels, 0, False)
        if not ok:
            return None
        return feats[labels.index(item)]

    # ---------- event ----------
    def canvasMoveEvent(self, event):
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None:
            return
        try:
            feat = self._feature_at_pos(pos)
        except Exception:
            feat = None
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            # สลับไปเครื่องมือเลือกปกติ (unsetMapTool เฉย ๆ = แคนวาสไม่มีเครื่องมือเลย ดูเหมือนค้าง)
            self._iface.actionSelect().trigger()

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        feats = self._features_at_pos(event.pos())
        if feats is None:
            self._iface.messageBar().pushMessage(
                self._msg_title, "แปลงพิกัดจุดที่คลิกเป็นระบบพิกัดของชั้นข้อมูลไม่ได้ — ยังไม่ได้เลือกแปลง", level=2, duration=8)
            return
        if not feats:
            self._iface.messageBar().pushMessage(
                self._msg_title, f"ไม่พบแปลงในชั้น '{self._layer.name()}' ตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง",
                level=1, duration=6)
            return
        chosen = feats[0] if len(feats) == 1 else self._choose_parcel(feats)
        if chosen is None:
            return
        self._picked = True
        self._click_cb(chosen, self._layer)
        try:
            self._picked = self._canvas.mapTool() is not self
        except Exception:
            self._picked = False

    def deactivate(self):
        self._hover_timer.stop()
        self._cache_timer.stop()
        self._pending_pos = None
        self._gen += 1                       # ผลแคชที่กำลังมาถูกทิ้ง
        self._watch_extent(False)
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
        self._pop_hint()
        super().deactivate()


class ClickTool(QgsMapTool):
    """คลิกจุดบนแผนที่ -> on_click(จุดในพิกัดโปรเจกต์) · Esc -> on_cancel (คงเครื่องมือไว้) · เลิกใช้ -> on_deactivate"""

    def __init__(self, canvas, on_click, on_cancel=None, on_deactivate=None):
        super().__init__(canvas)
        self._on_click = on_click
        self._on_cancel = on_cancel
        self._on_deactivate = on_deactivate
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.LeftButton:
            self._on_click(self.toMapCoordinates(e.pos()))

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape and self._on_cancel:
            self._on_cancel()

    def deactivate(self):
        if self._on_deactivate:
            try:
                self._on_deactivate()
            except Exception:
                pass
        super().deactivate()
